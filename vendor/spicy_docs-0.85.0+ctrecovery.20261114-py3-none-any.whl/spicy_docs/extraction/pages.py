"""Lazy PDF rendering and image decoding; all optional imports stay at use sites."""

from __future__ import annotations

import io
import math
from collections import Counter
from contextlib import contextmanager
from importlib.metadata import version

from .font_glyphs import counts, map_line, unmapped_by_font
from .model import (
    RAW_RGB,
    Box,
    ExtractionError,
    NativeGeometryError,
    ProcessingIssue,
    Raster,
    Recognition,
    TableObservation,
    TextBlock,
)


def _raster(image, raw: bool, box: Box | None = None) -> Raster:
    """A Pillow RGB image as a raster: unencoded samples when ``raw``, else PNG."""
    if raw:
        return Raster(image.tobytes(), image.width, image.height, box or Box(), RAW_RGB)
    out = io.BytesIO()
    image.save(out, format="PNG")
    return Raster(out.getvalue(), image.width, image.height, box or Box())


def _display_box(page, rect_like, width: float, height: float) -> Box | None:
    """Normalize native coordinates after applying this page's display rotation.

    Native text uses the original page. Tables use the unrotated working copy,
    whose rotation matrix is the identity, so neither is rotated twice.
    ``None`` means the rect has no area on the displayed
    page (a table cell PyMuPDF reports no bounding box for, or geometry
    entirely outside the crop), not a zero-sized box.
    """
    import pymupdf

    rect = pymupdf.Rect(rect_like) * page.rotation_matrix
    rect &= page.rect
    if rect.is_empty:
        return None
    return Box(rect.x0 / width, rect.y0 / height, rect.x1 / width, rect.y1 / height)


def _pixel_bounds(box: Box, width: int, height: int) -> tuple[int, int, int, int]:
    return (
        math.floor(box.x0 * width),
        math.floor(box.y0 * height),
        math.ceil(box.x1 * width),
        math.ceil(box.y1 * height),
    )


def rounded(box: Box, image: Raster) -> Box:
    """The page region :func:`crop` would actually cut for ``box``: its bounds rounded outward to pixels."""
    x0, y0, x1, y1 = _pixel_bounds(box, image.width, image.height)
    return image.box.place(Box(x0 / image.width, y0 / image.height, x1 / image.width, y1 / image.height))


def crop(image: Raster, box: Box) -> Raster:
    """Crop to pixel-rounded bounds; the part keeps raw pixels raw, else is a PNG; its box is the rounded region."""
    from PIL import Image

    raw = image.media_type == RAW_RGB
    source = (
        Image.frombytes("RGB", (image.width, image.height), image.data) if raw else Image.open(io.BytesIO(image.data))
    )
    with source:
        part = source.crop(_pixel_bounds(box, source.width, source.height))
        return _raster(part, raw, rounded(box, image))


class DefaultReader:
    """Open PDFs through PyMuPDF and images through Pillow, loading each backend only when used.

    PDF pages expose their native text layer and render at ``dpi``; every render
    is refused above ``max_pixels``. Encrypted PDFs are refused here. The optional
    ``table_strategy`` selects PyMuPDF's maintained table detector; ``lines_strict``
    excludes filled background rectangles that can split real financial columns.

    ``raw_rgb=True`` renders unencoded ``RAW_RGB`` samples instead of a PNG, for a backend
    that reads pixels (``AppleVision``; the others need an encoded image). It skips the PNG
    encode, 52 ms of a 200-DPI page, but a retained observation then holds 3 bytes a pixel.
    """

    def __init__(
        self,
        *,
        dpi: int = 200,
        max_pixels: int = 20_000_000,
        table_strategy: str = "lines",
        raw_rgb: bool = False,
    ):
        if not 36 <= dpi <= 1200 or max_pixels < 1:
            raise ValueError("dpi must be 36..1200 and max_pixels must be positive")
        if table_strategy not in {"lines", "lines_strict", "text"}:
            raise ValueError("table_strategy must be lines, lines_strict or text")
        self.dpi, self.max_pixels = dpi, max_pixels
        self.table_strategy, self.raw_rgb = table_strategy, raw_rgb

    @contextmanager
    def open(self, source: bytes, media_type: str):
        if media_type == "application/pdf":
            import pymupdf

            with pymupdf.open(stream=source, filetype="pdf") as document:
                if document.needs_pass:
                    raise ExtractionError("encrypted PDF requires decryption before extraction")
                yield _PDF(document, self)
        else:
            from PIL import Image

            with Image.open(io.BytesIO(source)) as document:
                actual = Image.MIME.get(document.format)
                if actual != media_type:
                    raise ValueError(f"image bytes have media type {actual}, not {media_type}")
                yield _Images(document, self)

    def check_pixels(self, width: int, height: int):
        """Refuse a nonexistent or over-``max_pixels`` raster before it is allocated."""
        if width < 1 or height < 1 or width * height > self.max_pixels:
            raise ExtractionError("render exceeds max_pixels; reduce DPI or choose a larger explicit limit")


class _PDF:
    def __init__(self, document, reader):
        self.document, self.reader, self.page_count = document, reader, len(document)
        #: Font xref -> codes its ToUnicode map omits, so each font is parsed once per document, not per page.
        self.unmapped: dict[int, frozenset[int] | None] = {}

    def page(self, number):
        return _PDFPage(self.document[number - 1], number, self.reader, self.unmapped)


class _PDFPage:
    has_native_layer = True

    def __init__(self, page, number, reader, unmapped=None):
        self.page, self.number, self.reader = page, number, reader
        self.unmapped = {} if unmapped is None else unmapped
        self.geometry = {
            "kind": "pdf",
            "rotation": page.rotation,
            "cropbox": list(page.cropbox),
            "mediabox": list(page.mediabox),
            "display_rect": list(page.rect),
            "dpi": reader.dpi,
        }

    def native(self):
        """PyMuPDF's line-grouped text in reading order, one block per line.

        Text outside the displayed page is refused. GPO symbol-font glyphs are mapped by
        ``font_glyphs`` (the raw spans keep the literal glyph) and each mapping is a
        ``font-glyph-mapped`` issue, or ``font-glyph-unresolved`` where the table leaves it. A
        character whose code its font's ToUnicode map omits is an ``unmapped-glyph-code`` issue
        naming the line's index in ``blocks`` and carrying its box, which
        ``NativeWithRegions(unmapped_glyphs=True)`` sends to OCR. A font whose
        dictionary or map cannot be read is an ``unmapped-glyph-check-skipped`` issue; its text is
        extracted as it would be without the check.
        """
        import pymupdf

        # Image bytes are retained by the source, not duplicated into native text extraction.
        raw = self.page.get_text("dict", flags=pymupdf.TEXTFLAGS_DICT & ~pymupdf.TEXT_PRESERVE_IMAGES)
        unmapped, unreadable = unmapped_by_font(self.page.parent, self.page.get_fonts(), self.unmapped)
        blocks = []
        issues = [
            ProcessingIssue("unmapped-glyph-check-skipped", f"{name}: font dictionary or Unicode map unreadable")
            for name in unreadable
        ]
        tally = Counter()
        width, height = self.page.rect.width, self.page.rect.height
        for block in raw["blocks"]:
            for line in block.get("lines", []):
                text = map_line(line["spans"], tally, line["dir"])
                box = _display_box(self.page, line["bbox"], width, height)
                if box is None:
                    if text.strip():
                        displayed = pymupdf.Rect(line["bbox"]) * self.page.rotation_matrix
                        reason = "zero_area" if displayed.is_empty else "outside_page"
                        raise NativeGeometryError(reason, details={
                            "page": self.number, "line": line, "display_bbox": list(displayed),
                            "geometry": self.geometry,
                        })
                    continue
                issues.extend(_unmapped_issues(line["spans"], unmapped, len(blocks), box))
                blocks.append(TextBlock(text, box))
        for glyph in counts(self.number, tally):
            mapped = glyph.replacement is not None
            issues.append(
                ProcessingIssue(
                    "font-glyph-mapped" if mapped else "font-glyph-unresolved",
                    f"{glyph.rule}: {glyph.font} {glyph.original!r} -> "
                    f"{glyph.replacement if mapped else 'kept'!r} x{glyph.count}",
                )
            )
        return Recognition(
            "\n".join(b.text for b in blocks),
            {"backend": "pymupdf", "version": version("pymupdf"), "sort": False},
            raw,
            tuple(blocks),
            issues=tuple(issues),
        )

    def render(self):
        """Render the page at the reader's DPI, alpha-free RGB as PNG or raw samples, bounded by ``max_pixels``."""
        width = math.ceil(self.page.rect.width * self.reader.dpi / 72)
        height = math.ceil(self.page.rect.height * self.reader.dpi / 72)
        self.reader.check_pixels(width, height)
        pix = self.page.get_pixmap(dpi=self.reader.dpi, alpha=False)
        self.reader.check_pixels(pix.width, pix.height)
        if self.reader.raw_rgb:
            return Raster(pix.samples, pix.width, pix.height, media_type=RAW_RGB)
        return Raster(pix.tobytes("png"), pix.width, pix.height)

    def image_count(self):
        """How many raster images the page draws, inline and in forms included; resources it never draws are not."""
        return len(self.page.get_image_info())

    def find_tables(self):
        """PyMuPDF's ruled tables with cell text and normalized cell boxes.

        Detect on a single-page copy. The table finder changes rotated pages'
        crop geometry, so first make the visible crop the copy's media box and
        remove rotation while preserving its appearance. The original page,
        its native words and its render geometry remain unchanged.
        """
        import pymupdf

        width, height = self.page.rect.width, self.page.rect.height
        observations = []
        with pymupdf.open() as copied:
            copied.insert_pdf(self.page.parent, from_page=self.page.number, to_page=self.page.number)
            page = copied[0]
            if page.rotation:
                page.set_mediabox(page.cropbox)
                page.remove_rotation()
            for table in page.find_tables(strategy=self.reader.table_strategy).tables:
                box = _display_box(page, table.bbox, width, height)
                if box is None:
                    continue
                cells = tuple(tuple(row) for row in table.extract())
                cell_boxes = tuple(
                    tuple(_display_box(page, cell, width, height) if cell is not None else None for cell in row.cells)
                    for row in table.rows
                )
                observations.append(
                    TableObservation(self.number, box, table.row_count, table.col_count, cells, cell_boxes)
                )
        return tuple(observations)


def _unmapped_issues(spans, unmapped, index, box):
    """One ``unmapped-glyph-code`` issue per flagged (font, character) on a line, placed at the line's box."""
    if not unmapped:
        return ()
    seen = dict.fromkeys(
        (span["font"], char) for span in spans for char in span["text"] if ord(char) in unmapped.get(span["font"], ())
    )
    return tuple(
        ProcessingIssue(
            "unmapped-glyph-code",
            f"line {index}: {font} code 0x{ord(char):02X} has no Unicode map entry; extracted as {char!r}",
            box,
        )
        for font, char in seen
    )


class _Images:
    def __init__(self, document, reader):
        self.document, self.reader = document, reader
        self.page_count = getattr(document, "n_frames", 1)

    def page(self, number):
        from PIL import Image, ImageOps

        self.document.seek(number - 1)
        self.reader.check_pixels(self.document.width, self.document.height)
        geometry = {
            "kind": "image",
            "original_size": list(self.document.size),
            "exif_orientation": self.document.getexif().get(274, 1),
            "pillow_version": version("pillow"),
            "background": "white",
        }
        oriented = ImageOps.exif_transpose(self.document)
        if "A" in oriented.getbands() or "transparency" in oriented.info:
            rgba = oriented.convert("RGBA")
            oriented = Image.new("RGB", rgba.size, "white")
            oriented.paste(rgba, mask=rgba.getchannel("A"))
        else:
            oriented = oriented.convert("RGB")
        geometry["display_size"] = list(oriented.size)
        return _ImagePage(oriented, number, geometry, self.reader.raw_rgb)


class _ImagePage:
    has_native_layer = False

    def __init__(self, image, number, geometry, raw_rgb=False):
        self.image, self.number, self.geometry, self.raw_rgb = image, number, geometry, raw_rgb

    def native(self):
        """Refuse: an image carries no native text layer."""
        raise ExtractionError("image has no native text layer")

    def render(self):
        """The oriented frame at its own size, as a PNG or raw RGB samples."""
        return _raster(self.image, self.raw_rgb)

    def image_count(self):
        """One: the page is the image."""
        return 1

    def find_tables(self):
        """Empty, not an error: no table finder runs over image input."""
        return ()
