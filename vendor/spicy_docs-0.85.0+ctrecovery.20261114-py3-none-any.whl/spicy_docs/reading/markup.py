"""Ordered markup observations with original-byte text positions and no layout policy.

Also the three steps a source's own ``HTMLParser`` page reader repeats: decode
one bounded page, feed it, and join a field's text parts under a length bound.
Each raises the source's own error type.
"""

from __future__ import annotations

import codecs
import re
from dataclasses import dataclass
from email.message import Message
from html import unescape
from html.parser import HTMLParser
from typing import Literal
from xml.parsers import expat

from spicy_docs.transport.source_acquirer import check_payload, limit_byte_bound

from .xml import _configure_xml_parser, _feed_xml, _validate_xml_input

HTML_VOID_TAGS = frozenset(
    {
        "area",
        "base",
        "br",
        "col",
        "embed",
        "hr",
        "img",
        "input",
        "link",
        "meta",
        "param",
        "source",
        "track",
        "wbr",
    }
)
_HTML_FEED_CHARACTERS = 64 * 1024
#: Both readers' default event bound. A flat walk that builds no tree may pass it
#: as ``max_depth`` too: the HTML reader is linear in events at any depth.
MAX_EVENTS = 1_000_000


class MarkupReadError(ValueError):
    """Markup is malformed, undecodable, or outside the selected input bounds."""


@dataclass(frozen=True, slots=True)
class MarkupEvent:
    """A parser observation; only text events carry complete original-byte spans.

    XML names retain their prefix; HTML names follow HTMLParser's lowercase
    spelling. Namespace declarations remain separate from ordinary attributes.
    Start/end positions are anchors, including synthetic XML empty-element ends.
    ``is_literal`` compares decoded UTF-8 text with its original source bytes.
    """

    kind: Literal["start", "empty", "end", "text", "comment", "pi", "declaration"]
    byte_start: int
    name: str | None = None
    attributes: tuple[tuple[str, str | None], ...] = ()
    text: str | None = None
    byte_end: int | None = None
    is_literal: bool = False
    namespace_declarations: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True, slots=True)
class MarkupRead:
    events: tuple[MarkupEvent, ...]
    element_count: int
    root_name: str | None
    root_expanded_name: str | None
    source_encoding: str | None = None
    encoding_basis: str | None = None


class _Events:
    def __init__(self, body: bytes, max_events: int) -> None:
        if type(max_events) is not int or max_events <= 0:
            raise MarkupReadError("max_events must be a positive integer")
        self.body = body
        self.max_events = max_events
        self.events: list[MarkupEvent] = []
        self.element_count = 0
        self.root_name: str | None = None
        self.root_expanded_name: str | None = None
        self._literal_parts: list[str] = []
        self._literal_start = self._literal_end = 0
        self._literal_utf8 = True

    def _append(self, event: MarkupEvent) -> None:
        if len(self.events) >= self.max_events:
            raise MarkupReadError("markup exceeds max_events")
        self.events.append(event)

    def flush(self) -> None:
        if self._literal_parts:
            self._append(
                MarkupEvent(
                    "text",
                    self._literal_start,
                    text="".join(self._literal_parts),
                    byte_end=self._literal_end,
                    is_literal=self._literal_utf8,
                )
            )
            self._literal_parts.clear()

    def add(self, event: MarkupEvent) -> None:
        self.flush()
        self._append(event)
        if event.kind in {"start", "empty"}:
            self.element_count += 1
            if self.root_name is None:
                self.root_name = event.name

    def text(self, text: str, start: int, end: int, *, source_encoding: str = "utf-8") -> None:
        if not text:
            if end > start:
                self.add(MarkupEvent("text", start, text="", byte_end=end))
            return
        literal = self.body[start:end] == text.encode("utf-8")
        try:
            source_literal = literal or self.body[start:end] == text.encode(source_encoding)
        except UnicodeEncodeError:
            source_literal = False  # A numeric reference can exceed the declared source encoding.
        if source_literal:
            if self._literal_parts and start != self._literal_end:
                self.flush()
            if not self._literal_parts:
                if len(self.events) >= self.max_events:
                    raise MarkupReadError("markup exceeds max_events")
                self._literal_start = start
                self._literal_utf8 = literal
            else:
                self._literal_utf8 = self._literal_utf8 and literal
            self._literal_parts.append(text)
            self._literal_end = end
        else:
            self.add(MarkupEvent("text", start, text=text, byte_end=end))

    def result(self, *, source_encoding: str | None = None, encoding_basis: str | None = None) -> MarkupRead:
        self.flush()
        return MarkupRead(
            tuple(self.events),
            self.element_count,
            self.root_name,
            self.root_expanded_name,
            source_encoding,
            encoding_basis,
        )


def _xml_name(name: str) -> tuple[str, str]:
    """Resolve Expat's namespace triplet into the source QName and expanded name."""
    parts = name.split("}")
    if len(parts) == 1:
        return name, name
    uri, local, *prefix = parts
    return (f"{prefix[0]}:{local}" if prefix else local), f"{{{uri}}}{local}"


def read_xml_events(
    body: bytes,
    *,
    max_bytes: int = 64 * 1024**2,
    max_events: int = MAX_EVENTS,
    max_depth: int = 256,
    allow_external_doctype: bool = False,
    allow_empty_internal_subset: bool = False,
) -> MarkupRead:
    """Read complete namespace-valid XML with literal text and original-byte spans.

    Declared entities refuse under the shared XML safety rules. An inert external
    DOCTYPE requires an explicit choice and never loads its resource. XML encoding
    DOCTYPE may also have a whitespace-only internal subset when explicitly
    allowed; declarations, parameter entities and other subset content refuse.
    Encoding declarations remain effective; byte positions always address the original
    input, not a UTF-8 re-encoding. No external resource is read.
    """
    _validate_xml_input(body, max_bytes=max_bytes, error_type=MarkupReadError, label="XML markup")
    if type(allow_external_doctype) is not bool:
        raise MarkupReadError("allow_external_doctype must be a boolean")
    if type(allow_empty_internal_subset) is not bool:
        raise MarkupReadError("allow_empty_internal_subset must be a boolean")
    events = _Events(body, max_events)
    parser = expat.ParserCreate(namespace_separator="}")
    parser.namespace_prefixes = True
    pending: tuple[str, int] | None = None
    namespaces: list[tuple[str, str]] = []
    # Expat recognizes both BOM and zero-byte signatures before a declaration.
    encoding = (
        "utf-16-le"
        if body.startswith((b"\xff\xfe", b"<\0"))
        else "utf-16-be"
        if body.startswith((b"\xfe\xff", b"\0<"))
        else "utf-8"
    )

    def close_text() -> None:
        nonlocal pending
        if pending is not None:
            text, start = pending
            pending = None
            events.text(text, start, parser.CurrentByteIndex, source_encoding=encoding)

    def start(name: str, attributes: dict[str, str]) -> None:
        close_text()
        qualified, expanded = _xml_name(name)
        if events.root_name is None:
            events.root_expanded_name = expanded
        events.add(
            MarkupEvent(
                "start",
                parser.CurrentByteIndex,
                name=qualified,
                attributes=tuple((_xml_name(key)[0], value) for key, value in attributes.items()),
                namespace_declarations=tuple(namespaces),
            )
        )
        namespaces.clear()

    def end(name: str) -> None:
        close_text()
        events.add(MarkupEvent("end", parser.CurrentByteIndex, name=_xml_name(name)[0]))

    def data(text: str) -> None:
        nonlocal pending
        close_text()
        pending = text, parser.CurrentByteIndex

    def other(kind: Literal["comment", "pi", "declaration"], text: str, name: str | None = None) -> None:
        close_text()
        events.add(MarkupEvent(kind, parser.CurrentByteIndex, name=name, text=text))

    def declaration(version: str, declared_encoding: str | None, standalone: int) -> None:
        nonlocal encoding
        close_text()
        attributes: list[tuple[str, str | None]] = [("version", version)]
        if declared_encoding is not None:
            attributes.append(("encoding", declared_encoding))
            if not encoding.startswith("utf-16-"):
                encoding = declared_encoding
        if standalone != -1:
            attributes.append(("standalone", "yes" if standalone else "no"))
        events.add(MarkupEvent("declaration", parser.CurrentByteIndex, name="xml", attributes=tuple(attributes)))

    def doctype(name: str, system_id: str | None, public_id: str | None) -> None:
        close_text()
        attributes: list[tuple[str, str | None]] = [("name", name)]
        if system_id is not None:
            attributes.append(("system", system_id))
        if public_id is not None:
            attributes.append(("public", public_id))
        events.add(MarkupEvent("declaration", parser.CurrentByteIndex, name="doctype", attributes=tuple(attributes)))

    _configure_xml_parser(
        parser,
        start=start,
        end=end,
        data=data,
        error_type=MarkupReadError,
        label="XML markup",
        max_depth=max_depth,
        allow_external_doctype=allow_external_doctype,
        empty_internal_subset=(
            lambda start, end: re.fullmatch(r"\[[ \t\r\n]*\]", body[start:end].decode(encoding)) is not None
        )
        if allow_empty_internal_subset
        else None,
        doctype=doctype,
    )
    parser.StartNamespaceDeclHandler = lambda prefix, uri: namespaces.append((prefix or "", uri or ""))
    parser.CommentHandler = lambda text: other("comment", text)
    parser.ProcessingInstructionHandler = lambda name, text: other("pi", text, name)
    parser.XmlDeclHandler = declaration
    # Delimiters close a run even when no semantic element event occurs.
    parser.StartCdataSectionHandler = close_text
    parser.EndCdataSectionHandler = close_text
    try:
        _feed_xml(body, parser, error_type=MarkupReadError, label="XML markup")
    except LookupError as error:
        raise MarkupReadError("XML markup declares an unsupported encoding") from error
    close_text()
    return events.result()


def html_charset(media_type: str) -> tuple[str, ...]:
    """All stated charset parameters, including duplicates so conflicts stay visible."""
    message = Message()
    message["content-type"] = media_type
    return tuple(value for name, value in (message.get_params() or [])[1:] if name.lower() == "charset")


def _html_charsets(attributes: list[tuple[str, str | None]]) -> tuple[str, ...]:
    declared = [value or "" for name, value in attributes if name == "charset"]
    if any(name == "http-equiv" and (value or "").lower() == "content-type" for name, value in attributes):
        for name, value in attributes:
            if name == "content":
                declared.extend(html_charset(value or ""))
    return tuple(declared)


def _html_encoding(label: str) -> str:
    try:
        name = codecs.lookup(label.strip()).name
    except LookupError as error:
        raise MarkupReadError(f"HTML markup declares an unsupported encoding: {label!r}") from error
    supported = {"utf-8": "utf-8", "cp1252": "windows-1252", "iso8859-1": "iso-8859-1", "ascii": "ascii"}
    if name not in supported:
        raise MarkupReadError(f"HTML markup declares an unsupported encoding: {label!r}")
    return supported[name]


class _HtmlDeclarations(HTMLParser):
    """Read declarations in the bounded HTML encoding prefix, ignoring comments and scripts."""

    def __init__(self) -> None:
        super().__init__()
        self.charsets: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "meta":
            self.charsets.extend(_html_charsets(attrs))


def _decode_html(body: bytes, *, encoding_policy: str, declared_charsets: tuple[str, ...]) -> tuple[str, str, str, int]:
    if encoding_policy == "utf-8":
        if declared_charsets:
            raise MarkupReadError("declared_charsets requires the declared-or-windows-1252 encoding policy")
        try:
            return body.decode("utf-8"), "utf-8", "utf-8", 0
        except UnicodeDecodeError as error:
            raise MarkupReadError("HTML markup must be UTF-8") from error
    if encoding_policy != "declared-or-windows-1252":
        raise MarkupReadError("unsupported HTML encoding_policy")
    if not isinstance(declared_charsets, tuple) or any(not isinstance(value, str) for value in declared_charsets):
        raise MarkupReadError("declared_charsets must be a tuple of strings")
    if body.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE, codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE)):
        raise MarkupReadError("HTML markup declares an unsupported encoding by its byte-order mark")
    declarations = _HtmlDeclarations()
    # Encoding declarations belong in HTML's first 1024 bytes. Latin-1 keeps
    # this ASCII-compatible probe one character per original byte. The actual
    # reader also checks later declarations against the selected encoding.
    try:
        declarations.feed(body[:1024].decode("iso-8859-1"))
    except (AssertionError, ValueError) as error:
        raise MarkupReadError(f"HTML encoding declarations cannot be parsed: {error}") from error
    names = {_html_encoding(label) for label in (*declared_charsets, *declarations.charsets)}
    bom = body.startswith(codecs.BOM_UTF8)
    if bom:
        names.add("utf-8")
    if len(names) > 1:
        raise MarkupReadError("HTML markup has conflicting encoding declarations")
    encoding = next(iter(names), "utf-8")
    basis = "utf-8-bom" if bom else "declared" if names else "utf-8"
    offset = len(codecs.BOM_UTF8) if bom else 0
    try:
        return body[offset:].decode(encoding), encoding, basis, offset
    except UnicodeDecodeError as error:
        if names:
            raise MarkupReadError(f"HTML markup is not the declared {encoding}") from error
    try:
        return body.decode("windows-1252"), "windows-1252", "windows-1252-fallback", 0
    except UnicodeDecodeError as error:
        raise MarkupReadError("HTML markup is neither UTF-8 nor Windows-1252") from error


class _HtmlEvents(HTMLParser):
    def __init__(
        self,
        body: bytes,
        text: str,
        *,
        max_events: int,
        max_depth: int,
        encoding: str = "utf-8",
        byte_offset: int = 0,
        check_charsets: bool = False,
    ) -> None:
        super().__init__(convert_charrefs=False)
        if type(max_depth) is not int or max_depth <= 0:
            raise MarkupReadError("max_depth must be a positive integer")
        self.events = _Events(body, max_events)
        self.text = text
        self.encoding = encoding
        self.check_charsets = check_charsets
        self.max_depth = max_depth
        # Open non-void tags, and each name's indexes into that stack. HTMLParser
        # infers no closing tag, so an unclosed tag (GovInfo's literal
        # ``<bullet>`` inside a ``<pre>`` body) stays open until an ancestor
        # closes. The index finds an end tag's match without scanning the
        # stack, so a read stays linear in events at any depth.
        self.stack: list[str] = []
        self._open: dict[str, list[int]] = {}
        self._line = 1
        self._column = self._character = 0
        self._byte = byte_offset

    def position(self) -> tuple[int, int]:
        # HTMLParser counts only LF as a line boundary. Advance once through the
        # source instead of allocating one Python integer per source character.
        line, column = self.getpos()
        character = self._character
        if line == self._line:
            character += column - self._column
        else:
            for _ in range(line - self._line):
                character = self.text.index("\n", character) + 1
            character += column
        self._byte += len(self.text[self._character : character].encode(self.encoding))
        self._line, self._column, self._character = line, column, character
        return self._byte, character

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self._check_charset(tag, attrs)
        if tag not in HTML_VOID_TAGS:
            if len(self.stack) >= self.max_depth:
                raise MarkupReadError("HTML markup exceeds the supported nesting depth")
            self._open.setdefault(tag, []).append(len(self.stack))
            self.stack.append(tag)
        self.events.add(MarkupEvent("start", self.position()[0], name=tag, attributes=tuple(attrs)))

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self._check_charset(tag, attrs)
        if len(self.stack) >= self.max_depth:
            raise MarkupReadError("HTML markup exceeds the supported nesting depth")
        self.events.add(MarkupEvent("empty", self.position()[0], name=tag, attributes=tuple(attrs)))

    def _check_charset(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if (
            self.check_charsets
            and tag == "meta"
            and any(_html_encoding(label) != self.encoding for label in _html_charsets(attrs))
        ):
            raise MarkupReadError("HTML markup has conflicting or late encoding declarations")

    def handle_endtag(self, tag: str) -> None:
        self.events.add(MarkupEvent("end", self.position()[0], name=tag))
        # Close the innermost open ``tag`` and everything opened inside it.
        # Each popped entry is the last index of its own name, and every entry
        # is pushed and popped once, so the whole read is linear.
        if opened := self._open.get(tag):
            index = opened[-1]
            for name in reversed(self.stack[index:]):
                self._open[name].pop()
            del self.stack[index:]

    def handle_data(self, data: str) -> None:
        start, _ = self.position()
        # HTMLParser can deliver a final unterminated reference as data on close.
        # Match convert_charrefs=True there, while keeping script/style data raw.
        decoded = data if self.cdata_elem else unescape(data)
        self.events.text(decoded, start, start + len(data.encode(self.encoding)), source_encoding=self.encoding)

    def _reference(self, name: str) -> None:
        start, character = self.position()
        end = character + len(name) + 1
        if self.text[end : end + 1] == ";":
            end += 1
        raw = self.text[character:end]
        self.events.text(unescape(raw), start, start + len(raw.encode(self.encoding)), source_encoding=self.encoding)

    def handle_entityref(self, name: str) -> None:
        self._reference(name)

    def handle_charref(self, name: str) -> None:
        self._reference("#" + name)

    def handle_comment(self, data: str) -> None:
        self.events.add(MarkupEvent("comment", self.position()[0], text=data))

    def handle_pi(self, data: str) -> None:
        self.events.add(MarkupEvent("pi", self.position()[0], text=data))

    def handle_decl(self, decl: str) -> None:
        self.events.add(MarkupEvent("declaration", self.position()[0], text=decl))

    def unknown_decl(self, data: str) -> None:
        self.events.add(MarkupEvent("declaration", self.position()[0], text=data))


def read_html_events(
    body: bytes,
    *,
    max_bytes: int = 64 * 1024**2,
    max_events: int = MAX_EVENTS,
    max_depth: int = 256,
    encoding_policy: Literal["utf-8", "declared-or-windows-1252"] = "utf-8",
    declared_charsets: tuple[str, ...] = (),
) -> MarkupRead:
    """Read HTML using HTMLParser's tolerant grammar, without suppressing text.

    Unknown tags and duplicate attributes survive. This is a source parser, not
    browser DOM construction: it does not infer missing tags or layout breaks.
    The default remains strict UTF-8. The explicit compatibility policy honors
    UTF-8, Windows-1252, ISO-8859-1 or ASCII declarations, then tries undeclared
    UTF-8 before Windows-1252. Conflicts and undecodable bytes refuse, never
    replacement-decode. ``source_encoding`` and ``encoding_basis`` explain the
    choice; every span still addresses the original bytes. Transport charset
    parameters, when retained, belong in ``declared_charsets``.
    """
    _validate_xml_input(body, max_bytes=max_bytes, error_type=MarkupReadError, label="HTML markup", allow_empty=True)
    text, encoding, basis, offset = _decode_html(
        body, encoding_policy=encoding_policy, declared_charsets=declared_charsets
    )
    parser = _HtmlEvents(
        body,
        text,
        max_events=max_events,
        max_depth=max_depth,
        encoding=encoding,
        byte_offset=offset,
        check_charsets=encoding_policy != "utf-8",
    )
    try:
        for offset in range(0, len(text), _HTML_FEED_CHARACTERS):
            parser.feed(text[offset : offset + _HTML_FEED_CHARACTERS])
        parser.close()
    except (AssertionError, ValueError) as error:
        if isinstance(error, MarkupReadError):
            raise
        raise MarkupReadError(f"HTML markup cannot be parsed: {error}") from error
    return parser.events.result(source_encoding=encoding, encoding_basis=basis)


def decode_html_page(body: object, max_bytes: object, *, label: str, cap: int, error_type: type[ValueError]) -> str:
    """One page's exact bytes as the UTF-8 its publisher declares: nonempty, within a bound no greater than ``cap``."""
    limit = limit_byte_bound(max_bytes, name=f"{label} byte bound", cap=cap, error_type=error_type)
    exact = check_payload(body, limit, label=label, error_type=error_type, allow_empty=False)
    try:
        return exact.decode("utf-8")
    except UnicodeDecodeError as error:
        raise error_type(f"{label} is not the UTF-8 the publisher declares") from error


def feed_html(parser: HTMLParser, text: str, *, label: str, error_type: type[Exception]) -> None:
    """Feed and close one page; a parser failure is the source's own refusal, never an empty page."""
    try:
        parser.feed(text)
        parser.close()
    except error_type:
        raise
    except Exception as error:  # pragma: no cover - HTMLParser is lenient by design
        raise error_type(f"{label} HTML could not be parsed") from error


def joined_text(parts: object, *, label: str, bound: int, error_type: type[ValueError]) -> str:
    """A field's text parts joined with whitespace collapsed; a string is one part, anything else none."""
    if isinstance(parts, str):
        parts = [parts]
    elif not isinstance(parts, list):
        parts = []
    value = " ".join("".join(parts).split())
    if len(value) > bound:
        raise error_type(f"{label} exceeds its length bound")
    return value
