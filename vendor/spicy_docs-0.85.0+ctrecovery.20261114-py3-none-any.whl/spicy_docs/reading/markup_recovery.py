"""Explicit inspection candidates for retained markup with reviewed compatibility issues.

Ordinary readers never call these helpers. The caller chooses an encoding or
the narrow literal-entity policy and retains the original beside the candidate.
Successful syntax is not source completeness or permission to select its text.
"""

from __future__ import annotations

import codecs
import re
from dataclasses import dataclass
from email.message import Message
from hashlib import sha256
from html.parser import HTMLParser
from typing import Literal, NoReturn
from xml.parsers import expat

from .markup import MAX_EVENTS, read_html_events, read_xml_events
from .xml import _validate_xml_input


@dataclass(frozen=True, slots=True)
class MarkupSourceChange:
    """An exact original-byte span and its replacement before UTF-8 serialization."""

    byte_start: int
    byte_end: int
    original: bytes
    replacement: bytes
    reason: str


@dataclass(frozen=True, slots=True)
class MarkupRecoveryCandidate:
    source_sha256: str
    source_bytes: int
    policy: str
    status: Literal["candidate", "refused"]
    reason: str
    source_encoding: str | None = None
    candidate_body: bytes | None = None
    candidate_sha256: str | None = None
    candidate_bytes: int = 0
    changes: tuple[MarkupSourceChange, ...] = ()
    diagnostics: tuple[str, ...] = ()
    byte_positions_address: Literal["candidate"] = "candidate"
    qualification: str = "not_qualified_for_selection"


class _Refused(ValueError):
    pass


def _bounds(body: bytes, max_bytes: int, **limits: int) -> None:
    _validate_xml_input(body, max_bytes=max_bytes, error_type=ValueError, label="markup recovery input")
    for name, value in limits.items():
        if type(value) is not int or value <= 0:
            raise ValueError(f"{name} must be a positive integer")


def _identity(body: bytes, policy: str, encoding: str | None = None) -> dict:
    return {
        "source_sha256": sha256(body).hexdigest(),
        "source_bytes": len(body),
        "policy": policy,
        "source_encoding": encoding,
    }


def _result(identity: dict, candidate: bytes, changes: list[MarkupSourceChange]) -> MarkupRecoveryCandidate:
    return MarkupRecoveryCandidate(
        **identity,
        status="candidate",
        reason="explicit_policy_candidate_requires_source_review",
        candidate_body=candidate,
        candidate_sha256=sha256(candidate).hexdigest(),
        candidate_bytes=len(candidate),
        changes=tuple(changes),
    )


def _refusal(identity: dict, error: Exception) -> MarkupRecoveryCandidate:
    return MarkupRecoveryCandidate(**identity, status="refused", reason=str(error), diagnostics=(type(error).__name__,))


class _EncodingDeclarations(HTMLParser):
    def __init__(self, text: str, encoding: str, limit: int) -> None:
        super().__init__(convert_charrefs=False)
        self.text, self.encoding, self.limit = text, encoding, limit
        self.changes: list[MarkupSourceChange] = []
        self.spans: list[tuple[int, int]] = []
        self._line = 1
        self._line_start = self._character = self._byte = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag != "meta":
            return
        charset = any(name == "charset" for name, _ in attrs)
        if any(name == "http-equiv" and (value or "").lower() == "content-type" for name, value in attrs):
            for name, value in attrs:
                if name == "content":
                    message = Message()
                    message["content-type"] = value or ""
                    charset |= any(name.lower() == "charset" for name, _ in (message.get_params() or [])[1:])
        if not charset:
            return
        if len(self.changes) >= self.limit:
            raise _Refused("HTML encoding declaration limit exceeded")
        line, column = self.getpos()
        while self._line < line:
            self._line_start = self.text.index("\n", self._line_start) + 1
            self._line += 1
        start = self._line_start + column
        self._byte += len(self.text[self._character : start].encode(self.encoding))
        self._character = start
        raw = self.get_starttag_text()
        assert raw is not None
        original = raw.encode(self.encoding)
        self.spans.append((start, start + len(raw)))
        self.changes.append(
            MarkupSourceChange(
                self._byte,
                self._byte + len(original),
                original,
                b'<meta charset="utf-8">',
                "encoding declaration replaced under explicit caller choice",
            )
        )

    handle_startendtag = handle_starttag


def recover_html_encoding_candidate(
    body: bytes,
    *,
    source_encoding: Literal["utf-8", "windows-1252"],
    max_bytes: int = 64 << 20,
    max_candidate_bytes: int = 64 << 20,
    max_declarations: int = 32,
    max_events: int = MAX_EVENTS,
    max_depth: int = 256,
) -> MarkupRecoveryCandidate:
    """Strictly decode a caller-chosen encoding, retaining every declaration edit.

    This never guesses an encoding or replaces undecodable bytes. It transcodes
    the complete body to UTF-8 and replaces only actual encoding ``meta`` tags;
    comments and script text remain untouched. Original declaration tags and
    byte spans survive in ``changes``. Other original bytes remain in the
    caller's retained source; candidate positions never address that source.
    """
    _bounds(
        body,
        max_bytes,
        max_candidate_bytes=max_candidate_bytes,
        max_declarations=max_declarations,
        max_events=max_events,
        max_depth=max_depth,
    )
    if source_encoding not in ("utf-8", "windows-1252"):
        raise ValueError("source_encoding must be an explicit utf-8 or windows-1252 choice")
    identity = _identity(body, "explicit-html-encoding-candidate-v1", source_encoding)
    try:
        if source_encoding != "utf-8" and body.startswith(codecs.BOM_UTF8):
            raise _Refused("chosen encoding conflicts with UTF-8 byte-order mark")
        if body.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE, codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE)):
            raise _Refused("unsupported HTML byte-order mark")
        text = body.decode(source_encoding)
        parser = _EncodingDeclarations(text, source_encoding, max_declarations)
        for offset in range(0, len(text), 64 * 1024):
            parser.feed(text[offset : offset + 64 * 1024])
        parser.close()
        parts, cursor, total = [], 0, 0
        for start, end in (*parser.spans, (len(text), len(text))):
            part = text[cursor:start].encode("utf-8")
            replacement = b'<meta charset="utf-8">' if start != len(text) else b""
            total += len(part) + len(replacement)
            if total > max_candidate_bytes:
                raise _Refused("candidate exceeds byte bound")
            parts.extend((part, replacement))
            cursor = end
        candidate = b"".join(parts)
        read_html_events(candidate, max_bytes=max_candidate_bytes, max_events=max_events, max_depth=max_depth)
        return _result(identity, candidate, parser.changes)
    except (ValueError, AssertionError) as error:
        return _refusal(identity, error)


class _HeaderComplete(Exception):
    pass


_LITERAL_DECLARATION = re.compile(
    rb"""\s*<!ENTITY\s+([A-Za-z_][A-Za-z0-9_.-]*)\s+(?:"([^"<>&%\x00-\x1f]*)"|'([^'<>&%\x00-\x1f]*)')\s*>"""
)


def _entity_header(
    body: bytes, max_declaration_bytes: int, max_definitions: int, max_literal_bytes: int
) -> tuple[int, int, dict[str, bytes]]:
    parser = expat.ParserCreate()
    parser.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)
    positions: dict[str, int] = {}

    def refuse(*_args: object) -> NoReturn:
        raise _Refused("external, parameter or unsupported XML declarations are forbidden")

    def xml_declaration(_version: str, encoding: str | None, _standalone: int) -> None:
        if encoding is not None and encoding.lower().replace("_", "-") != "utf-8":
            raise _Refused("literal entity recovery requires UTF-8 XML")

    def declaration(
        _name: str,
        parameter: int,
        value: str | None,
        _base: str | None,
        system: str | None,
        public: str | None,
        notation: str | None,
    ) -> None:
        if parameter or system or public or notation or value is None or any(c in value for c in "&<%>"):
            refuse()
        if len(value.encode("utf-8")) > max_literal_bytes:
            raise _Refused("XML literal definition exceeds byte bound")

    def doctype(_name: str, _system: str | None, _public: str | None, internal: bool) -> None:
        if not internal:
            raise _Refused("no internal literal definitions")
        positions["subset"] = parser.CurrentByteIndex
        positions["start"] = body.rfind(b"<!DOCTYPE", 0, parser.CurrentByteIndex + 1)

    def end_doctype() -> None:
        positions["end"] = parser.CurrentByteIndex + 1
        raise _HeaderComplete

    parser.XmlDeclHandler = xml_declaration
    parser.StartDoctypeDeclHandler = doctype
    parser.EndDoctypeDeclHandler = end_doctype
    parser.EntityDeclHandler = declaration
    parser.ExternalEntityRefHandler = refuse
    parser.StartElementHandler = refuse
    try:
        parser.Parse(body[:max_declaration_bytes], False)
    except _HeaderComplete:
        pass
    else:
        raise _Refused("XML declaration prefix is absent, incomplete or exceeds byte bound")
    start, end, subset_start = positions["start"], positions["end"], positions["subset"]
    if start < 0 or body[subset_start : subset_start + 1] != b"[" or body[end - 2 : end] != b"]>":
        raise _Refused("unsupported XML internal subset syntax")
    subset, cursor, definitions = body[subset_start + 1 : end - 2], 0, {}
    while subset[cursor:].strip():
        match = _LITERAL_DECLARATION.match(subset, cursor)
        if match is None:
            raise _Refused("internal subset is not plain literal definitions only")
        name = match[1].decode("ascii")
        value = match[2] if match[2] is not None else match[3]
        if name in definitions or name in {"amp", "lt", "gt", "apos", "quot"}:
            raise _Refused("duplicate or predefined XML entity name")
        if (
            not value
            or len(value) > max_literal_bytes
            or any(ord(c) < 32 or 127 <= ord(c) < 160 for c in value.decode("utf-8"))
        ):
            raise _Refused("XML literal definition is empty, contains controls or exceeds byte bound")
        definitions[name] = value
        if len(definitions) > max_definitions:
            raise _Refused("XML literal definition count exceeded")
        cursor = match.end()
    if not definitions:
        raise _Refused("no internal literal definitions")
    return start, end, definitions


def recover_xml_literal_candidate(
    body: bytes,
    *,
    max_bytes: int = 64 << 20,
    max_candidate_bytes: int = 64 << 20,
    max_declaration_bytes: int = 16 * 1024,
    max_definitions: int = 8,
    max_literal_bytes: int = 256,
    max_references: int = 64,
    max_events: int = MAX_EVENTS,
    max_depth: int = 256,
) -> MarkupRecoveryCandidate:
    """Materialize bounded plain internal literals into a separate UTF-8 candidate.

    External/parameter/recursive entities, additional DTD declarations, markup
    in values, and references in attributes/comments/CDATA refuse. No resource
    is loaded. Expat's default handler exposes text references without expanding
    them; definition and total reference bounds apply before the full parse.
    The inert DOCTYPE is removed and its exact original span is retained. A
    final strict shared reread must pass, without relaxing ordinary XML policy.
    """
    _bounds(
        body,
        max_bytes,
        max_candidate_bytes=max_candidate_bytes,
        max_declaration_bytes=max_declaration_bytes,
        max_definitions=max_definitions,
        max_literal_bytes=max_literal_bytes,
        max_references=max_references,
        max_events=max_events,
        max_depth=max_depth,
    )
    identity = _identity(body, "bounded-literal-xml-candidate-v1", "utf-8")
    try:
        body.decode("utf-8")
        start, end, definitions = _entity_header(body, max_declaration_bytes, max_definitions, max_literal_bytes)
        references = re.compile(rb"&(" + b"|".join(re.escape(k.encode()) for k in definitions) + rb");")
        expected = []
        for match in references.finditer(body):
            if start <= match.start() < end:
                continue
            if len(expected) >= max_references:
                raise _Refused("XML literal reference count exceeded")
            expected.append((match.start(), match.end(), match[1].decode()))
        size = len(body) - (end - start) + sum(len(definitions[name]) - (b - a) for a, b, name in expected)
        if size > max_candidate_bytes:
            raise _Refused("candidate exceeds byte bound")
        parser = expat.ParserCreate()
        parser.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)
        observed: list[tuple[int, int, str]] = []
        depth = events = 0

        def tick(*_args: object) -> None:
            nonlocal events
            events += 1
            if events > max_events:
                raise _Refused("XML source exceeds event bound")

        def on_start(*_args: object) -> None:
            nonlocal depth
            tick()
            depth += 1
            if depth > max_depth:
                raise _Refused("XML source exceeds depth bound")

        def on_end(*_args: object) -> None:
            nonlocal depth
            tick()
            depth -= 1

        def on_default(value: str) -> None:
            tick()
            match = references.fullmatch(value.encode("utf-8"))
            if match:
                at = parser.CurrentByteIndex
                observed.append((at, at + len(value), match[1].decode()))

        def refuse(*_args: object) -> NoReturn:
            raise _Refused("external or unresolved XML entity reference")

        def on_skipped(name: str, parameter: int) -> None:
            tick()
            if parameter or name not in definitions:
                refuse()
            at = parser.CurrentByteIndex
            token = ("&" + name + ";").encode("ascii")
            if body[at : at + len(token)] != token:
                refuse()
            observed.append((at, at + len(token), name))

        parser.DefaultHandler = on_default
        parser.StartElementHandler = on_start
        parser.EndElementHandler = on_end
        parser.CharacterDataHandler = tick
        parser.ExternalEntityRefHandler = refuse
        parser.SkippedEntityHandler = on_skipped
        for offset in range(0, len(body), 64 * 1024):
            parser.Parse(body[offset : offset + 64 * 1024], False)
        parser.Parse(b"", True)
        if observed != expected:
            raise _Refused("literal references outside ordinary element text are unsupported")
        changes = [
            MarkupSourceChange(
                start, end, body[start:end], b"", "inert DOCTYPE retained in evidence and removed from candidate"
            )
        ]
        changes.extend(
            MarkupSourceChange(a, b, body[a:b], definitions[name], f"plain literal {name}") for a, b, name in observed
        )
        changes.sort(key=lambda c: c.byte_start)
        pieces, cursor = [], 0
        for change in changes:
            pieces.extend((body[cursor : change.byte_start], change.replacement))
            cursor = change.byte_end
        candidate = b"".join((*pieces, body[cursor:]))
        read_xml_events(candidate, max_bytes=max_candidate_bytes, max_events=max_events, max_depth=max_depth)
        return _result(identity, candidate, changes)
    except (ValueError, expat.ExpatError) as error:
        return _refusal(identity, error)
