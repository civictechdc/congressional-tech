"""Bounded, unqualified XML recovery candidates over retained original bytes.

The ordinary readers stay strict. This opt-in path uses the maintained lxml
recovery parser only after a syntax failure, then rereads its serialized output
through the strict shared reader. Recovered markup can make retained text
inspectable; it cannot prove that missing or discarded source content survived.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Literal
from xml.parsers import expat

from .markup import MAX_EVENTS, MarkupReadError, read_xml_events
from .xml import _validate_xml_input


@dataclass(frozen=True, slots=True)
class XmlRecoveryDiagnostic:
    """A libxml2 diagnostic; line/column refer to the original input's XML text."""

    level: str
    domain: str
    code: str
    line: int
    column: int
    message: str


@dataclass(frozen=True, slots=True)
class XmlRecoveryCandidate:
    """Original identity and a separate candidate, never an accepted replacement.

    Any altered candidate is ``partial`` even if its serialization is now valid
    XML: recovery may close missing tags, discard incomplete attributes, drop
    nodes, or lose text. Inspect the original, candidate and resulting text before
    a downstream decision. Candidate byte positions address ``candidate_body``;
    they must never be applied to the original body. The caller retains both.
    """

    source_sha256: str
    source_bytes: int
    status: Literal["unchanged", "partial", "refused"]
    reason: str
    source_error: str | None = None
    candidate_body: bytes | None = None
    candidate_sha256: str | None = None
    candidate_bytes: int = 0
    diagnostics: tuple[XmlRecoveryDiagnostic, ...] = ()
    transformations: tuple[str, ...] = ()
    lxml_version: str | None = None
    libxml_version: str | None = None
    byte_positions_address: Literal["original", "candidate"] = "candidate"
    qualification: str = "not_qualified_for_selection"


def recover_xml_candidate(
    body: bytes,
    *,
    max_bytes: int = 64 << 20,
    max_candidate_bytes: int = 64 << 20,
    max_events: int = MAX_EVENTS,
    max_depth: int = 256,
) -> XmlRecoveryCandidate:
    """Attempt one bounded syntax recovery without fetching resources or expanding entities.

    Requires the existing ``reconstruct`` extra only for a malformed input.
    Safety/encoding/bound refusals are not repair targets. A valid original is
    returned unchanged. An altered output passes the ordinary XML reader, but
    stays explicitly partial because valid syntax does not prove completeness.
    No source bytes are modified and no production reader invokes this helper
    automatically. There are no original-byte spans for rewritten bytes.
    """
    _validate_xml_input(body, max_bytes=max_bytes, error_type=ValueError, label="XML recovery input")
    for name, value in (
        ("max_candidate_bytes", max_candidate_bytes),
        ("max_events", max_events),
        ("max_depth", max_depth),
    ):
        if type(value) is not int or value <= 0:
            raise ValueError(f"{name} must be a positive integer")
    identity = {"source_sha256": sha256(body).hexdigest(), "source_bytes": len(body)}
    reader_options = {
        "max_bytes": max_bytes,
        "max_events": max_events,
        "max_depth": max_depth,
        "allow_external_doctype": True,
        "allow_empty_internal_subset": True,
    }
    try:
        read_xml_events(body, **reader_options)
    except MarkupReadError as error:
        source_error = str(error)
        if not isinstance(error.__cause__, expat.ExpatError):
            return XmlRecoveryCandidate(
                **identity,
                status="refused",
                reason="source_safety_encoding_or_limit_refusal",
                source_error=source_error,
            )
    else:
        return XmlRecoveryCandidate(
            **identity,
            status="unchanged",
            reason="original_is_well_formed",
            candidate_body=body,
            candidate_sha256=identity["source_sha256"],
            candidate_bytes=len(body),
            byte_positions_address="original",
        )
    try:
        from lxml import etree
    except ImportError:
        return XmlRecoveryCandidate(
            **identity, status="refused", reason="reconstruct_extra_unavailable", source_error=source_error
        )

    class NoExternalResource(etree.Resolver):
        def resolve(self, url, public_id, context):
            raise ValueError("XML recovery external resources are forbidden")

    parser = etree.XMLParser(
        recover=True,
        resolve_entities=False,
        load_dtd=False,
        no_network=True,
        dtd_validation=False,
        attribute_defaults=False,
        huge_tree=False,
        strip_cdata=False,
    )
    parser.resolvers.add(NoExternalResource())
    versions = {
        "lxml_version": ".".join(map(str, etree.LXML_VERSION)),
        "libxml_version": ".".join(map(str, etree.LIBXML_VERSION)),
    }
    try:
        root = etree.fromstring(body, parser)
    except (etree.XMLSyntaxError, ValueError, OSError):
        root = None
    diagnostics = tuple(
        XmlRecoveryDiagnostic(
            entry.level_name, entry.domain_name, entry.type_name, entry.line, entry.column, entry.message
        )
        for entry in parser.error_log
    )
    evidence = dict(**identity, source_error=source_error, diagnostics=diagnostics, **versions)
    if root is None:
        return XmlRecoveryCandidate(**evidence, status="refused", reason="no_recoverable_document")
    tree = root.getroottree()
    if tree.docinfo.internalDTD is not None and any(tree.docinfo.internalDTD.iterentities()):
        return XmlRecoveryCandidate(
            **evidence, status="refused", reason="recovered_document_contains_entity_declarations"
        )
    candidate = etree.tostring(tree, encoding="utf-8", xml_declaration=True)
    if len(candidate) > max_candidate_bytes:
        return XmlRecoveryCandidate(**evidence, status="refused", reason="candidate_exceeds_byte_bound")
    try:
        read_xml_events(candidate, **(reader_options | {"max_bytes": max_candidate_bytes}))
    except MarkupReadError:
        return XmlRecoveryCandidate(
            **evidence,
            status="refused",
            reason="candidate_fails_strict_reread",
            candidate_body=candidate,
            candidate_sha256=sha256(candidate).hexdigest(),
            candidate_bytes=len(candidate),
        )
    return XmlRecoveryCandidate(
        **evidence,
        status="partial",
        reason="recovery_cannot_establish_content_completeness",
        candidate_body=candidate,
        candidate_sha256=sha256(candidate).hexdigest(),
        candidate_bytes=len(candidate),
        transformations=(
            "lxml recover=True over original bytes; see parser diagnostics",
            "serialized recovered document as UTF-8 with XML declaration",
            "strict shared XML reread of candidate passed; source completeness remains unresolved",
        ),
    )
