"""Read retained House Bills for the Week Atom feeds as schedule/discovery facts.

This is an offline reader. Dates describe feed observations and scheduled weeks,
never passage or votes. Every entry occurrence survives, even when IDs or weekly
URLs repeat. Exact entry byte spans and hashes retain revision evidence.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date
from hashlib import sha256
from urllib.parse import parse_qs, urljoin, urlsplit
from xml.etree.ElementTree import Element

from spicy_docs.reading.atom import ATOM, XML_BASE, read_atom_feed
from spicy_docs.reading.markup import MarkupReadError, read_html_events
from spicy_docs.reading.rss import child_text, single_child

FEED_URL = "https://docs.house.gov/BillsThisWeek-RSS.xml"
MAX_BYTES = 64 << 20
PARSER_VERSION = "house-floor-feed/002"


class HouseFloorFeedError(ValueError):
    """The retained bytes do not establish the supported House floor feed."""


@dataclass(frozen=True, slots=True)
class FloorLink:
    index: int
    href: str
    resolved_url: str | None
    text: str
    rel: str
    media_type: str | None
    basis: str
    base_url: str
    repair_url: str | None = None
    repair_basis: str | None = None


@dataclass(frozen=True, slots=True)
class FloorEntry:
    index: int
    entry_id: str
    title: str
    published: str | None
    updated: str
    weekly_url: str
    week_date: str
    content_html: str
    content_sha256: str
    entry_sha256: str
    source_start: int
    source_end: int
    links: tuple[FloorLink, ...]


@dataclass(frozen=True, slots=True)
class HouseFloorFeed:
    source_sha256: str
    source_bytes: int
    feed_id: str
    title: str
    subtitle: str | None
    updated: str
    author: str | None
    links: tuple[FloorLink, ...]
    entries: tuple[FloorEntry, ...]


def _one(element: Element, name: str, *, required: bool = False) -> str | None:
    value = child_text(element, ATOM + name, error_type=HouseFloorFeedError, label="House floor feed")
    if required and value is None:
        raise HouseFloorFeedError(f"House floor feed requires {name}")
    return value


def _required(element: Element, name: str) -> str:
    value = _one(element, name, required=True)
    assert value is not None
    return value


def _base(element: Element, inherited: str) -> str:
    return urljoin(inherited, element.get(XML_BASE, ""))


def _http_url(href: str, base: str) -> str | None:
    try:
        resolved = urljoin(base, href)
        parts = urlsplit(resolved)
        if parts.scheme in {"http", "https"} and parts.hostname and parts.username is None:
            return resolved
    except ValueError:
        pass
    return None


def _atom_links(element: Element, base: str) -> list[FloorLink]:
    links = []
    for child in element.findall(ATOM + "link"):
        href = child.get("href")
        if href is None or not href.strip():
            raise HouseFloorFeedError("House floor feed link lacks href")
        child_base = _base(child, base)
        links.append(
            FloorLink(
                len(links),
                href,
                _http_url(href, child_base),
                child.get("title", ""),
                child.get("rel", "alternate"),
                child.get("type"),
                "atom_link",
                child_base,
            )
        )
    return links


def _content_links(content: str, base: str, start: int) -> list[FloorLink]:
    """Keep anchor occurrences and their labels using the maintained HTML reader."""
    anchors, opened = [], []
    try:
        document = read_html_events(content.encode(), max_bytes=MAX_BYTES)
    except MarkupReadError as error:
        raise HouseFloorFeedError("House floor entry HTML exceeds the supported shape") from error
    for event in document.events:
        if event.kind in {"start", "empty"} and event.name == "a":
            values = [value for key, value in event.attributes if key == "href"]
            if len(values) > 1:
                raise HouseFloorFeedError("House floor entry repeats a link href attribute")
            attrs = dict(event.attributes)
            anchor = (
                (values[0], [], attrs.get("type"), attrs.get("rel") or "") if values and values[0] is not None else None
            )
            if anchor is not None:
                anchors.append(anchor)
            if event.kind == "start":
                opened.append(anchor)
        elif event.kind == "text":
            for anchor in opened:
                if anchor is not None:
                    anchor[1].append(event.text or "")
        elif event.kind == "end" and event.name == "a" and opened:
            opened.pop()
    if opened:
        raise HouseFloorFeedError("House floor entry has an unclosed link")
    return [
        FloorLink(
            start + index,
            href,
            _http_url(href, base),
            " ".join("".join(parts).split()),
            rel,
            media_type,
            "content_anchor",
            base,
        )
        for index, (href, parts, media_type, rel) in enumerate(anchors)
    ]


def parse_house_floor_feed(body: bytes, *, max_bytes: int = MAX_BYTES, max_entries: int = 10_000) -> HouseFloorFeed:
    """Read one complete retained feed; never fetch linked documents or collapse revisions.

    House content is the HTML fragment from the weekly alternate page. Relative
    fragment links use that page unless the publisher supplies xml:base. Literal
    hrefs and the chosen base remain beside each resolved URL.
    """
    document = read_atom_feed(
        body, max_bytes=max_bytes, max_entries=max_entries, error_type=HouseFloorFeedError, label="House floor feed"
    )
    root = document.root
    title = _required(root, "title")
    root_base = _base(root, FEED_URL)
    feed_links = _atom_links(root, root_base)
    if not all(term in title for term in ("Majority Leader", "Committee on Rules")) or not any(
        link.rel == "alternate"
        and urlsplit(link.resolved_url or "").hostname == "docs.house.gov"
        and urlsplit(link.resolved_url or "").path in {"", "/"}
        for link in feed_links
    ):
        raise HouseFloorFeedError("Atom title and alternate link do not identify the House floor feed")
    author = single_child(root, ATOM + "author", error_type=HouseFloorFeedError, label="House floor feed")
    entries = []
    for index, element in enumerate(document.entries):
        entry_base = _base(element, root_base)
        links = _atom_links(element, entry_base)
        weekly = [
            link.resolved_url
            for link in links
            if link.rel == "alternate"
            and link.resolved_url
            and urlsplit(link.resolved_url).hostname == "docs.house.gov"
            and urlsplit(link.resolved_url).path.lower() == "/floor/default.aspx"
        ]
        if len(weekly) != 1:
            raise HouseFloorFeedError("House floor entry requires one weekly alternate page")
        weekly_url = weekly[0]
        assert weekly_url is not None
        dates = parse_qs(urlsplit(weekly_url).query).get("date", [])
        try:
            if len(dates) != 1 or date.fromisoformat(dates[0]).isoformat() != dates[0]:
                raise ValueError
        except ValueError:
            raise HouseFloorFeedError("House floor weekly page lacks one ISO calendar date") from None
        content = single_child(element, ATOM + "content", error_type=HouseFloorFeedError, label="House floor entry")
        if content is None or content.get("type") != "html" or content.get("src") is not None or len(content):
            raise HouseFloorFeedError("House floor entry requires inline HTML content")
        content_html = content.text or ""
        explicit_base = any(XML_BASE in node.attrib for node in (root, element, content))
        content_base = _base(content, entry_base) if explicit_base else weekly_url
        links.extend(_content_links(content_html, content_base, len(links)))
        begin, end = document.entry_spans[element]
        entries.append(
            FloorEntry(
                index,
                _required(element, "id"),
                _required(element, "title"),
                _one(element, "published"),
                _required(element, "updated"),
                weekly_url,
                dates[0],
                content_html,
                "sha256:" + sha256(content_html.encode()).hexdigest(),
                "sha256:" + sha256(body[begin:end]).hexdigest(),
                begin,
                end,
                tuple(links),
            )
        )
    # A retained House entry spells an absolute GovInfo target with one extra
    # leading slash. Offer a repair only when this same complete feed contains
    # that exact absolute spelling elsewhere. Keep href and its ordinary URL
    # resolution unchanged; consumers can inspect the separate repair evidence.
    stated = {
        link.href
        for entry in entries
        for link in entry.links
        if link.href == link.resolved_url and link.resolved_url is not None
    }
    entries = [
        replace(
            entry,
            links=tuple(
                replace(link, repair_url=link.href[1:], repair_basis="remove_leading_slash_exact_target_stated_in_feed")
                if link.href.startswith(("/https://", "/http://")) and link.href[1:] in stated
                else link
                for link in entry.links
            ),
        )
        for entry in entries
    ]
    return HouseFloorFeed(
        "sha256:" + sha256(body).hexdigest(),
        len(body),
        _required(root, "id"),
        title,
        _one(root, "subtitle"),
        _required(root, "updated"),
        _one(author, "name") if author is not None else None,
        tuple(feed_links),
        tuple(entries),
    )
