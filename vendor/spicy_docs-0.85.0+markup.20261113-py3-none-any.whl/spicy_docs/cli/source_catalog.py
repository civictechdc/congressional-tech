"""Explicit metadata replay and refresh; no automatic source crawl."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from spicy_docs.reading.json_input import load_bounded_json
from spicy_docs.sources.source_catalog import (
    DATAGOV_MAX_BYTES,
    KINDS,
    MAX_METADATA_BYTES,
    parse_metadata,
    refresh_metadata,
)
from spicy_docs.sources.usaspending import MONTHLY_FILES_MAX_BYTES
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.credentials import failure_reason, read_api_key, scrub_record


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("replay", "refresh"))
    parser.add_argument("--kind", required=True, choices=KINDS)
    parser.add_argument("--namespace", required=True)
    parser.add_argument("--url", required=True)
    parser.add_argument("--capture", required=True, type=Path, help="Retained input or new capture destination")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--observed-at", help="Original capture time (required for replay)")
    parser.add_argument("--sha256", help="Decoded payload pin (required for replay)")
    parser.add_argument("--content-type")
    parser.add_argument("--bucket")
    parser.add_argument("--prefix")
    parser.add_argument("--request-body", type=Path, help="Exact retained canonical monthly-files POST request")
    parser.add_argument("--receipt", type=Path, help="Retained monthly-files POST or Data.gov GET capture receipt")
    parser.add_argument("--api-key-file", type=Path, help="Environment file for explicit Data.gov refresh")
    parser.add_argument("--api-key-name", default="DATA_GOV_API_KEY")
    args = parser.parse_args(argv)
    options = {"bucket": args.bucket, "prefix": args.prefix}
    if args.kind == "usaspending-monthly-files" and args.operation != "replay":
        parser.error("monthly files supports offline replay only; use its explicit POST source reader")
    if args.operation == "replay":
        if not args.observed_at or not args.sha256:
            parser.error("replay requires original --observed-at and --sha256")
        with gzip.open(args.capture, "rb") if args.capture.suffix == ".gz" else args.capture.open("rb") as stream:
            limit = {
                "usaspending-monthly-files": MONTHLY_FILES_MAX_BYTES,
                "datagov-v4": DATAGOV_MAX_BYTES,
            }.get(args.kind, MAX_METADATA_BYTES)
            body = stream.read(limit + 1)
        if args.kind == "datagov-v4":
            if not args.receipt:
                parser.error("Data.gov replay requires --receipt with complete HTTP capture metadata")
            with args.receipt.open("rb") as stream:
                receipt = load_bounded_json(
                    stream.read(16 * 1024 + 1),
                    source="Data.gov receipt",
                    error_type=ValueError,
                    number_policy="integer",
                    max_bytes=16 * 1024,
                )
            if (
                not isinstance(receipt, dict)
                or receipt.get("complete") is not True
                or not isinstance(receipt.get("sha256"), str)
                or receipt.get("sha256", "").removeprefix("sha256:") != args.sha256.removeprefix("sha256:")
                or isinstance(receipt.get("bytes"), bool)
                or receipt.get("bytes") != len(body)
            ):
                raise ValueError("Data.gov receipt differs from retained response pins or is incomplete")
            options["retained_capture"] = CapturedBodyResponse(
                requested_url=receipt["url"],
                resolved_url=receipt["resolved_url"],
                status_code=receipt["status_code"],
                content_type=receipt["content_type"],
                observed_at=receipt["observed_at"],
                method=receipt["method"],
                content_encoding=receipt["content_encoding"],
                body=body,
            )
        if args.kind == "usaspending-monthly-files":
            if not args.request_body or not args.receipt:
                parser.error("monthly files replay requires --request-body and --receipt")

            def bounded_file(path):
                with path.open("rb") as stream:
                    return stream.read(16 * 1024 + 1)

            request = bounded_file(args.request_body)
            receipt = load_bounded_json(
                bounded_file(args.receipt),
                source="monthly files receipt",
                error_type=ValueError,
                number_policy="integer",
                max_bytes=16 * 1024,
            )
            selected = load_bounded_json(
                request,
                source="monthly files request",
                error_type=ValueError,
                number_policy="integer",
                max_bytes=16 * 1024,
            )
            if not isinstance(receipt, dict) or not isinstance(selected, dict):
                raise ValueError("monthly files receipt and request must be objects")
            if (
                receipt.get("request_body_sha256") != "sha256:" + hashlib.sha256(request).hexdigest()
                or receipt.get("sha256") != args.sha256
                or isinstance(receipt.get("bytes"), bool)
                or receipt.get("bytes") != len(body)
            ):
                raise ValueError("monthly files receipt differs from retained request/response pins")
            capture = CapturedBodyResponse(
                requested_url=receipt["requested_url"],
                resolved_url=receipt["resolved_url"],
                status_code=receipt["status_code"],
                content_type=receipt["content_type"],
                observed_at=receipt["observed_at"],
                body=body,
                method=receipt["method"],
                content_encoding=receipt["content_encoding"],
                request_body=request,
            )
            options.update(retained_capture=capture, request_body=selected)
        result = parse_metadata(
            body,
            kind=args.kind,
            namespace=args.namespace,
            capture_url=args.url,
            observed_at=args.observed_at,
            sha256=args.sha256,
            content_type=args.content_type,
            **options,
        )
    else:
        # A requested refresh is distinct from replay; never replace retained evidence.
        if args.capture.exists() or args.capture.with_suffix(args.capture.suffix + ".json").exists():
            parser.error("refresh capture destination already exists; replay it or select a new destination")
        from httpx import HTTPError

        from spicy_docs.transport.capture import BoundedHttpCapture
        from spicy_docs.transport.credentials import CredentialRefusedError

        api_key = None
        if args.kind == "datagov-v4":
            if not args.api_key_file:
                parser.error("Data.gov refresh requires --api-key-file")
            api_key = read_api_key(args.api_key_file, args.api_key_name)
        client = BoundedHttpCapture(
            max_requests=1,
            timeout_seconds=30,
            min_request_interval_seconds=0,
            user_agent="SpicyDocs metadata discovery",
            error_type=ValueError,
            transport=None,
            clock=lambda: datetime.now(UTC),
            retain_refusal_bodies=args.kind != "datagov-v4",
        )
        try:
            capture, result = refresh_metadata(
                client, args.url, kind=args.kind, namespace=args.namespace, api_key=api_key, **options
            )
        except (ValueError, ConnectionError, CredentialRefusedError, HTTPError) as error:
            from spicy_docs.reading.refusals import retain_refused_response

            args.output.parent.mkdir(parents=True, exist_ok=True)
            refusal = retain_refused_response(
                error, store=args.capture.parent / "refused-metadata", max_bytes=MAX_METADATA_BYTES
            )
            receipt = scrub_record(
                {
                    "url": args.url,
                    "status": "acquisition-failed",
                    "message": failure_reason(error, api_key or ""),
                    "refusal": refusal,
                    "observed_at": datetime.now(UTC).isoformat(),
                },
                api_key or "",
            )
            args.output.write_text(json.dumps(receipt, indent=2) + "\n")
            return 1
        finally:
            client.close()
        args.capture.parent.mkdir(parents=True, exist_ok=True)
        with args.capture.open("xb") as stream:
            stream.write(capture.body)
        receipt = {
            "url": capture.requested_url,
            "observed_at": capture.observed_at,
            "sha256": capture.sha256,
            "content_type": capture.content_type,
            "status_code": capture.status_code,
            "bytes": capture.byte_size,
            "resolved_url": capture.resolved_url,
            "method": capture.method,
            "content_encoding": capture.content_encoding,
            "complete": True,
        }
        args.capture.with_suffix(args.capture.suffix + ".json").write_text(json.dumps(receipt, indent=2) + "\n")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    return 1 if result["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
