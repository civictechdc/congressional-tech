"""Gemini image recognition with an injected client and retained conversations."""

from __future__ import annotations

import base64
import copy
import hashlib
import re
from collections.abc import Mapping
from itertools import pairwise
from typing import Any, Protocol

from spicy_docs.transport.credentials import CredentialRefusedError

from ._structured import _outcome_validator, _strict_json
from .model import Box, ExtractionError, ProcessingIssue, Raster, Recognition, TextBlock
from .prompts import FINAL, OVERVIEW, SUMMARY, TRANSCRIBE
from .remote import RemoteClient

DEFAULT_STRIPS = (Box(0, 0, 1, 0.4), Box(0, 0.3, 1, 0.7), Box(0, 0.6, 1, 1))


class GenerationClient(Protocol):
    def generate(self, model: str, body: dict[str, Any]) -> dict[str, Any]: ...


class GeminiClient(RemoteClient):
    """Bounded Gemini transport with explicit asynchronous batch operations."""

    provider = "Gemini"
    base_url = "https://generativelanguage.googleapis.com/v1beta/"

    def _headers(self):
        return {"x-goog-api-key": self._key}

    def generate(self, model, body):
        if not re.fullmatch(r"[A-Za-z0-9._-]+", model):
            raise ValueError("model must be a Gemini model name")
        return self._request("POST", f"models/{model}:generateContent", body)

    def submit_batch(self, model, body):
        """Submit one prepared inline batch; never retry a possibly accepted POST."""
        if not re.fullmatch(r"[A-Za-z0-9._-]+", model):
            raise ValueError("model must be a Gemini model name")
        return self._request("POST", f"models/{model}:batchGenerateContent", body)

    def get_batch(self, name):
        """Read an existing batch operation without submitting more requests."""
        if not re.fullmatch(r"batches/[A-Za-z0-9_-]+", name):
            raise ValueError("batch name must be batches/<id>")
        return self._request("GET", name)

    def cancel_batch(self, name):
        """Request cancellation; later status still determines the outcome."""
        if not re.fullmatch(r"batches/[A-Za-z0-9_-]+", name):
            raise ValueError("batch name must be batches/<id>")
        return self._request("POST", name + ":cancel", {})


def json_generation_config(
    generation: Mapping[str, Any] | None = None,
    *,
    schema: Mapping[str, Any] | None = None,
    response_mime_type: str = "application/json",
) -> dict[str, Any]:
    """``generationConfig`` asking for JSON, constrained by ``schema`` when one is given.

    One home for the two keys, because they belong together: a
    ``responseJsonSchema`` sent without ``responseMimeType`` is not a JSON request
    at all. Page recognition and the interpretation package's ``ModelCall`` adapter
    both build their request through here.
    """
    config = dict(generation or {})
    config["responseMimeType"] = response_mime_type
    if schema is not None:
        config["responseJsonSchema"] = schema
    return config


def generation_request(history, generation, schema=None, service_tier=None):
    """The same request body for online recognition and deferred batch work."""
    config = copy.deepcopy(generation)
    if schema is not None:
        config = json_generation_config(config, schema=schema)
    body = {"contents": copy.deepcopy(history), "generationConfig": config}
    if service_tier is not None:
        body["serviceTier"] = service_tier
    return body


def _message(image, text, additional_images=()):
    return {
        "role": "user",
        "parts": [
            *[
                {"inlineData": {"mimeType": source.media_type, "data": base64.b64encode(source.data).decode()}}
                for source in (image, *additional_images)
            ],
            {"text": text},
        ],
    }


def _answer(raw):
    if not isinstance(raw, dict):
        raise ExtractionError("Gemini response must be an object", details=raw)
    candidates = raw.get("candidates", [])
    if (
        not isinstance(candidates, list)
        or len(candidates) != 1
        or not isinstance(candidates[0], dict)
        or candidates[0].get("finishReason") != "STOP"
    ):
        raise ExtractionError("Gemini response was blocked, ambiguous or incomplete", details=raw)
    content = candidates[0].get("content", {})
    if not isinstance(content, dict):
        raise ExtractionError("Gemini returned invalid model content", details=raw)
    parts = content.get("parts", [])
    if not isinstance(parts, list) or not all(isinstance(p, dict) for p in parts):
        raise ExtractionError("Gemini returned invalid content parts", details=raw)
    texts = [p["text"] for p in parts if isinstance(p.get("text"), str) and not p.get("thought")]
    if content.get("role") != "model" or not texts:
        raise ExtractionError("Gemini returned no transcription part", details=raw)
    return "".join(texts), content


def _validated_outcome(text, validator):
    from jsonschema import ValidationError
    from referencing.exceptions import Unresolvable

    try:
        outcome = _strict_json(text)
        validator.validate(outcome)
    except (ValueError, ValidationError):
        raise ExtractionError("Gemini page outcome is invalid JSON or does not match outcome_schema") from None
    except (Unresolvable, RecursionError):
        raise ExtractionError("Gemini page outcome schema could not be evaluated") from None
    return outcome


def read_structured_response(response, outcome_schema):
    """Validate an already retained response without transport or recognition.

    Uses the live response's completion and schema checks. This establishes
    response validity only; source readers and independent review own accuracy.
    """
    _, validator = _outcome_validator(outcome_schema)
    text, _ = _answer(response)
    return text, _validated_outcome(text, validator)


class Gemini:
    def __init__(
        self,
        client: GenerationClient,
        *,
        model="gemini-3.8-flash",
        mode="single",
        generation: dict[str, Any] | None = None,
        prompt=None,
        outcome_schema: Mapping[str, Any] | None = None,
        overview_prompt=OVERVIEW,
        summary_prompt=SUMMARY,
        final_prompt=FINAL,
        strips=DEFAULT_STRIPS,
        service_tier=None,
    ):
        if service_tier not in {None, "standard", "flex"}:
            raise ValueError("service_tier must be standard or flex")
        self.service_tier = service_tier
        if mode not in {"single", "multiturn", "structured"}:
            raise ValueError("Gemini mode must be single, multiturn or structured")
        if mode == "structured":
            if not isinstance(prompt, str) or not prompt.strip() or outcome_schema is None:
                raise ValueError("structured mode requires an explicit prompt and outcome_schema")
            self.outcome_schema, self._validator = _outcome_validator(outcome_schema)
        elif outcome_schema is not None:
            raise ValueError("outcome_schema requires structured mode")
        else:
            self.outcome_schema, self._validator = None, None
        prompt = TRANSCRIBE if prompt is None else prompt
        if not 1 <= len(strips) <= 8 or any(b.x0 != 0 or b.x1 != 1 for b in strips):
            raise ValueError("provide one to eight full-width strips")
        if strips[0].y0 != 0 or strips[-1].y1 != 1 or any(a.y0 >= b.y0 or a.y1 < b.y0 for a, b in pairwise(strips)):
            raise ValueError("strips must cover the page from top to bottom without gaps")
        self.client, self.model, self.mode, self.prompt = client, model, mode, prompt
        self.prompts = {"overview": overview_prompt, "summary": summary_prompt, "final": final_prompt}
        self.strips = tuple(strips)
        self.generation: dict[str, Any] = {
            "maxOutputTokens": 8192,
            "thinkingConfig": {"thinkingLevel": "low"},
            **copy.deepcopy(generation or {}),
        }
        if self.outcome_schema is not None:
            if "responseSchema" in self.generation:
                raise ValueError("structured mode uses outcome_schema, not generation responseSchema")
            self.generation = json_generation_config(self.generation, schema=copy.deepcopy(self.outcome_schema))
        if not 1 <= self.generation["maxOutputTokens"] <= 32768 or self.generation.get("candidateCount", 1) != 1:
            raise ValueError("require one candidate and 1..32768 maxOutputTokens")

    def prepare_request(self, image: Raster) -> dict:
        """Prepare an independent full-page request without calling a provider.

        Multiturn recognition depends on earlier responses and cannot be
        submitted as independent page requests.
        """
        if self.mode not in {"single", "structured"}:
            raise ValueError("batch preparation requires single or structured mode")
        return generation_request(
            [_message(image, self.prompt)], self.generation, self.outcome_schema, self.service_tier
        )

    def recognize(self, image: Raster, *, additional_images: tuple[Raster, ...] = ()) -> Recognition:
        """Read one image, with up to seven related source images in structured mode.

        The caller defines their relationship in the prompt. Additional images
        are source evidence, not output geometry or an automatic page join.
        """
        from jsonschema import Draft202012Validator, ValidationError

        from .pages import crop

        if not isinstance(additional_images, (tuple, list)) or len(additional_images) > 7:
            raise ValueError("additional_images must be a bounded sequence of at most seven Raster images")
        if additional_images and self.mode != "structured":
            raise ValueError("additional_images requires structured mode")
        if any(
            not isinstance(source, Raster)
            or not isinstance(source.data, bytes)
            or not source.data
            or not isinstance(source.width, int)
            or not isinstance(source.height, int)
            or source.width < 1
            or source.height < 1
            or not isinstance(source.box, Box)
            or not isinstance(source.media_type, str)
            or not source.media_type.startswith("image/")
            for source in additional_images
        ):
            raise ValueError("additional_images must contain nonempty Raster images with valid dimensions and regions")
        additional_images = tuple(additional_images)
        calls = []
        settings = {
            "backend": "gemini",
            "model": self.model,
            "mode": self.mode,
            "generation": copy.deepcopy(self.generation),
            "prompts": {self.mode: self.prompt} if self.mode in {"single", "structured"} else dict(self.prompts),
        }

        if self.service_tier is not None:
            settings["service_tier"] = self.service_tier
        if self.outcome_schema is not None:
            settings["outcome_schema"] = copy.deepcopy(self.outcome_schema)
        if additional_images:
            settings["input_images"] = [
                {
                    "sha256": hashlib.sha256(source.data).hexdigest(),
                    "media_type": source.media_type,
                    "pixels": [source.width, source.height],
                    "box": [source.box.x0, source.box.y0, source.box.x1, source.box.y1],
                }
                for source in (image, *additional_images)
            ]

        def call(stage, history, schema=None):
            body = generation_request(history, self.generation, schema, self.service_tier)
            record = {"stage": stage, "request": copy.deepcopy(body)}
            calls.append(record)
            raw = self.client.generate(self.model, body)
            record["response"] = copy.deepcopy(raw)
            if getattr(self.client, "last_metadata", None):
                record["transport"] = copy.deepcopy(self.client.last_metadata)
            return _answer(raw)

        try:
            if self.mode == "structured":
                text, _ = call(
                    "structured-page", [_message(image, self.prompt, additional_images)], self.outcome_schema
                )
                assert self._validator is not None
                outcome = _validated_outcome(text, self._validator)
                return Recognition(
                    text, settings, {"calls": calls, "outcome": outcome}, images=(image, *additional_images)
                )
            if self.mode == "single":
                text, _ = call("full", [_message(image, self.prompt)])
                return Recognition(text, settings, {"calls": calls}, images=(image,))
            images = (image, *(crop(image, box) for box in self.strips))
            # Crop rounding can change the exact region; use actual bounds in result metadata.
            regions = {"P": Box()}
            w, h = image.box.x1 - image.box.x0, image.box.y1 - image.box.y0
            for i, strip in enumerate(images[1:], 1):
                regions[f"S{i}"] = Box(
                    (strip.box.x0 - image.box.x0) / w,
                    (strip.box.y0 - image.box.y0) / h,
                    (strip.box.x1 - image.box.x0) / w,
                    (strip.box.y1 - image.box.y0) / h,
                )
            schema = {
                "type": "object",
                "properties": {
                    "blocks": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "region_id": {"type": "string", "enum": list(regions)},
                                "text": {"type": "string"},
                            },
                            "required": ["region_id", "text"],
                            "additionalProperties": False,
                        },
                    },
                    "uncertainties": {"type": "array", "items": {"type": "string"}},
                },
                "required": ["blocks", "uncertainties"],
                "additionalProperties": False,
            }
            history = [_message(image, self.prompts["overview"])]
            _, content = call("overview", history)
            for i, strip in enumerate(images[1:], 1):
                # Keep raw model Content, including opaque continuation signatures.
                history = [*history, copy.deepcopy(content), _message(strip, f"Image S{i}. {self.prompts['summary']}")]
                _, content = call(f"S{i}", history)
            history = [*history, copy.deepcopy(content), _message(image, self.prompts["final"])]
            text, _ = call("final", history, schema)
            try:
                final = _strict_json(text)
                Draft202012Validator(schema).validate(final)
            except (ValueError, ValidationError):
                raise ExtractionError("Gemini final transcription has invalid structure or source references") from None
            blocks = tuple(TextBlock(b["text"], inspected_region=regions[b["region_id"]]) for b in final["blocks"])
            return Recognition(
                "\n".join(b.text for b in blocks),
                settings,
                {"calls": calls, "final": final},
                blocks,
                images,
                issues=tuple(ProcessingIssue("provider-uncertainty", message) for message in final["uncertainties"]),
            )
        except ExtractionError as exc:
            raise ExtractionError(
                str(exc), details={"configuration": settings, "calls": calls, "failure": exc.details}
            ) from None
        except CredentialRefusedError as exc:
            exc.details = {"configuration": settings, "calls": calls, "failure": getattr(exc, "details", None)}
            raise
