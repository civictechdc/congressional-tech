"""Optional PDF/image extraction; importing this API loads no model or renderer."""

from .api import DocumentExtractor, FullPage, NativeOrOcr, NativeText, NativeWithRegions, control_characters
from .body_text import BodyText, BodyTextError, RenditionCleanup, body_text, rendition_text
from .derivation import BODY_TEXT_DERIVATION_VERSION, derivation_code_digest
from .docling import Docling, DoclingSettings, DoclingVlmSettings
from .model import (
    RAW_RGB,
    Box,
    DocumentReader,
    ExtractionError,
    Extractor,
    ImageBackend,
    Observation,
    Page,
    PageContent,
    PageResult,
    PageStrategy,
    ProcessingIssue,
    Raster,
    Recognition,
    TableCell,
    TableObservation,
    TextBlock,
)
from .pages import DefaultReader

__all__ = [
    "BODY_TEXT_DERIVATION_VERSION",
    "RAW_RGB",
    "BodyText",
    "BodyTextError",
    "Box",
    "DefaultReader",
    "Docling",
    "DoclingSettings",
    "DoclingVlmSettings",
    "DocumentExtractor",
    "DocumentReader",
    "ExtractionError",
    "Extractor",
    "FullPage",
    "ImageBackend",
    "NativeOrOcr",
    "NativeText",
    "NativeWithRegions",
    "Observation",
    "Page",
    "PageContent",
    "PageResult",
    "PageStrategy",
    "ProcessingIssue",
    "Raster",
    "Recognition",
    "RenditionCleanup",
    "TableCell",
    "TableObservation",
    "TextBlock",
    "body_text",
    "control_characters",
    "derivation_code_digest",
    "rendition_text",
]
