"""Strict JSON and local-only schema checks shared by remote recognizers."""

import json
import math
from collections.abc import Mapping


def _unique_fields(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("JSON repeats an object key")
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError("JSON contains a non-finite number")


def _finite_float(value):
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("JSON number exceeds finite precision")
    return number


def _strict_json(text):
    try:
        return json.loads(
            text, object_pairs_hook=_unique_fields, parse_constant=_invalid_constant, parse_float=_finite_float
        )
    except RecursionError:
        raise ValueError("JSON nesting exceeds the decoder bound") from None


def _outcome_validator(schema):
    """Validate caller shape before a paid call; schemas never fetch remote resources."""
    from jsonschema import Draft202012Validator
    from referencing import Registry, Resource
    from referencing.exceptions import NoSuchResource, Unresolvable
    from referencing.jsonschema import DRAFT202012

    if not isinstance(schema, Mapping):
        raise TypeError("outcome_schema must be a JSON schema object")
    try:
        selected = _strict_json(json.dumps(dict(schema), allow_nan=False))
    except (TypeError, ValueError):
        raise ValueError("outcome_schema must contain JSON values") from None
    Draft202012Validator.check_schema(selected)

    def refuse_resource(uri):
        raise NoSuchResource(ref=uri)

    resource = Resource(selected, DRAFT202012)
    registry = Registry(retrieve=refuse_resource).with_resource("urn:spicy-docs:outcome", resource)

    def references(current, resolver):
        if isinstance(current.contents, dict):
            for key in ("$ref", "$dynamicRef"):
                if key in current.contents:
                    ref = current.contents[key]
                    if not isinstance(ref, str) or not ref.startswith("#"):
                        raise ValueError("outcome_schema references must be local to the schema")
                    resolver.lookup(ref)
        for child in current.subresources():
            references(child, resolver.in_subresource(child))

    try:
        references(resource, registry.resolver("urn:spicy-docs:outcome").in_subresource(resource))
    except (Unresolvable, RecursionError):
        raise ValueError("outcome_schema has an unresolved local reference") from None
    return selected, Draft202012Validator(selected, registry=registry)
