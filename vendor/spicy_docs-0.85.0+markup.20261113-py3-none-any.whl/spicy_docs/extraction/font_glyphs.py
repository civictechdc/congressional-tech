"""Font-keyed fixes for GPO symbol-font glyphs and detection of codes a font's Unicode map omits.

GPO set signs, brackets, fractions and marks in its own symbol fonts (``BGsddV01`` and siblings) whose
glyph names, and often their ToUnicode maps, are wrong: every extractor reads a printed minus as ``¥``.
The fix is keyed on the font, never on the character alone, because the same ``¥`` from any other font
is real (or an OCR layer's misread ½): a text-level rule would corrupt those. Fonts are matched on
PyMuPDF's span font name, which already has the subset prefix (``AFDLNI+``) stripped. The table holds
the font whether or not it carries a ToUnicode map: measured over the 414 retained GPO PDFs with a
GPO symbol font, ``BGsddV01`` emits ``¥`` 6,279 times without a map and 1,075 times with one.

Every entry was checked against rendered originals (the evidence and per-entry counts are in
``tests/fixtures/gpo_symbol_font/README.md``). ``None`` as a replacement leaves the glyph as
extracted and records it as unresolved; ``""`` removes it (an ornament with no text meaning). Cost: one dict lookup per span; per-character work only
inside a span set in a listed font.

:func:`unmapped_codes` is the second, independent check: a code a simple font's widths say is drawn
but its ToUnicode map omits, which MuPDF then emits as the code itself (a Calibri "ti" ligature
printed as ``#``). PyMuPDF has no flag for that, so it is read from the font dictionary. It runs in
every ``native()`` call rather than behind an option because it costs one ``get_fonts`` per page and one
parse per font object per document (about 0.3 s of 21.6 s over 1,727 pages), and it adds an issue only
where it fires (one line in 515 measured PDFs), so an unaffected page's output is unchanged.
"""

from __future__ import annotations

import re
from collections import Counter
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

#: Rule ids are part of the retained record; rename one only with a derivation version move.
MINUS = "gpo-sdd-minus"
UNDERSCORE = "gpo-sdd-underscore"

#: font -> extracted character -> (printed character, rule); ``None`` keeps the glyph, flagged; ``""`` drops it.
FONT_GLYPHS: Mapping[str, Mapping[str, tuple[str | None, str]]] = {
    "BGsddV01": {
        "¥": ("-", MINUS),  # ¥: printed minus; ASCII by the owner's decision
        "ø": ("[", "gpo-sdd-bold-bracket"),  # ø: black bracket, matter to be omitted
        "¿": ("]", "gpo-sdd-bold-bracket"),  # ¿
        "ƒ": ("[", "gpo-sdd-italic-bracket"),  # ƒ
        "≈": ("]", "gpo-sdd-italic-bracket"),  # ≈
        "∂": ("+", "gpo-sdd-plus"),  # ∂: "Medicare+Choice", "(+ ~ $60,000,000)"
        "d": ("¾", "gpo-sdd-fraction"),  # ¾
        "o": ("⅔", "gpo-sdd-fraction"),  # ⅔
        "»": ("◦", "gpo-sdd-sub-bullet"),  # »: open sub-bullet ◦
        "Æ": ("○", "gpo-sdd-end-mark"),  # Æ: end-of-document circle ○
        "Ø": (None, "gpo-sdd-unresolved"),  # Ø: renders blank before table amounts
        "◊": (None, "gpo-sdd-unresolved"),  # ◊: one bill page
    },
    "AGsddV01": {
        "B": ("⅓", "gpo-sdd-fraction"),  # ⅓
        "(": ("", "gpo-sdd-ornament"),  # "(": hearing-cover ornament, dropped by the owner's decision
    },
    "CGsddV01": {
        "Ö": ("€", "gpo-sdd-euro"),  # Ö
        "÷": ("€", "gpo-sdd-euro"),  # ÷
        "#": ("æ", "gpo-sdd-ligature"),  # æ, "Dædalus"
    },
}


@dataclass(frozen=True, slots=True)
class FontGlyphCount:
    """How often one page's text had one glyph of one font mapped (or flagged, ``replacement`` None)."""

    page: int
    font: str
    original: str
    replacement: str | None
    rule: str
    count: int


def _underscore(spans: Sequence[Mapping[str, Any]], k: int, direction: Sequence[float]) -> bool:
    """Whether GPO drew the ``¥`` span ``spans[k]`` as an underscore rather than a minus.

    GPO composes its underscore from the same glyph as its minus, set at about 0.71 of the text size
    and dropped below the text's baseline. So it is one exactly when every adjacent span in a text
    font is larger (by more than a fifth) and sits on a higher baseline. Measured over all 7,354
    ``BGsddV01`` ``¥`` in the retained GPO corpus: 182 match and every one prints as ``_`` (URLs, file
    names, ``STAT_UNUSED``); every other one is full size on the text's baseline or raised as an
    exponent, and prints as a minus. Read from the publisher's drawing, so it needs no guess about
    what a URL looks like (``guidelines_—book.pdf``, ``vvsg_%20vol`` and a wrapped ``_Mission`` included).
    """
    span, (cos, sin) = spans[k], direction
    neighbours = [n for n in (spans[k - 1] if k else None, spans[k + 1] if k + 1 < len(spans) else None) if n]
    neighbours = [n for n in neighbours if n["font"] not in FONT_GLYPHS]
    if not neighbours:
        return False
    x, y = span["origin"]
    return all(
        span["size"] < 0.8 * n["size"] and (y - n["origin"][1]) * cos - (x - n["origin"][0]) * sin > 0
        for n in neighbours
    )


def map_line(
    spans: Sequence[Mapping[str, Any]],
    tally: Counter[tuple[str, str, str | None, str]],
    direction: Sequence[float] = (1.0, 0.0),
    *,
    mappings: Mapping[str, Mapping[str, tuple[str | None, str]]] = FONT_GLYPHS,
) -> str:
    """One native line's text with listed-font glyphs mapped, counting each mapping into ``tally``.

    ``spans`` are PyMuPDF ``dict`` spans of one line and ``direction`` its ``dir``; they are read,
    never changed, so the raw output keeps the literal glyph. A line with no span in a listed font is
    the plain join. A source reader may supply separately reviewed ``mappings``
    after verifying its exact original and embedded-font identities.
    """
    text = "".join(span["text"] for span in spans)
    if not any(span["font"] in mappings for span in spans):
        return text
    out = list(text)
    position = 0
    for k, span in enumerate(spans):
        table = mappings.get(span["font"])
        if table:
            for i, char in enumerate(span["text"], position):
                entry = table.get(char)
                if entry is None:
                    continue
                replacement, rule = entry
                if rule == MINUS and _underscore(spans, k, direction):
                    replacement, rule = "_", UNDERSCORE
                if replacement is not None:
                    out[i] = replacement
                tally[(span["font"], char, replacement, rule)] += 1
        position += len(span["text"])
    return "".join(out)


def counts(page: int, tally: Counter[tuple[str, str, str | None, str]]) -> tuple[FontGlyphCount, ...]:
    """``tally`` as sorted per-page records."""
    return tuple(FontGlyphCount(page, *key, count) for key, count in sorted(tally.items(), key=lambda kv: str(kv[0])))


def page_counts(page: int, raw: Mapping[str, Any]) -> tuple[FontGlyphCount, ...]:
    """The glyph records of one PyMuPDF ``dict`` page, recomputed from its retained spans."""
    tally: Counter[tuple[str, str, str | None, str]] = Counter()
    for block in raw.get("blocks", ()):
        for line in block.get("lines", ()):
            map_line(line["spans"], tally, line["dir"])
    return counts(page, tally)


# ---------------------------------------------------------------------------
# Codes a simple font draws but its ToUnicode map omits.
# ---------------------------------------------------------------------------

_SIMPLE_FONTS = frozenset({"/Type1", "/MMType1", "/TrueType", "/Type3"})
_BLOCK = re.compile(rb"begin(bfchar|bfrange)(.*?)end\1", re.DOTALL)
_HEX = re.compile(rb"<([0-9A-Fa-f]*)>|\[|\]")
_NUMBER = re.compile(r"-?\d+(?:\.\d+)?")


def _resolved(document: Any, xref: int, key: str) -> str:
    """A font key's value as PDF source text, following one indirect reference."""
    kind, value = document.xref_get_key(xref, key)
    if kind == "xref":
        return document.xref_object(int(value.split()[0]), compressed=True)
    return "" if kind == "null" else value


def _cmap(cmap: bytes) -> tuple[set[int], set[int]]:
    """The one-byte source codes a ToUnicode CMap's bfchar and bfrange entries cover, and the single
    code points they produce."""
    covered: set[int] = set()
    produced: set[int] = set()

    def point(token: bytes, offset: int = 0) -> None:
        text = bytes.fromhex(token.decode()).decode("utf-16-be", "replace")
        if len(text) == 1:
            produced.add(ord(text) + offset)

    for kind, body in _BLOCK.findall(cmap):
        tokens = [m.group(1) if m.group(1) is not None else m.group(0) for m in _HEX.finditer(body)]
        if kind == b"bfchar":
            for source, target in zip(tokens[0::2], tokens[1::2], strict=False):
                if len(source) == 2:
                    covered.add(int(source, 16))
                    point(target)
            continue
        i = 0
        while i + 2 < len(tokens):
            low, high = tokens[i], tokens[i + 1]
            i += 2
            if tokens[i] == b"[":  # array destination: one target per code
                close = tokens.index(b"]", i)
                targets, i = tokens[i + 1 : close], close + 1
            else:
                targets, i = [tokens[i]], i + 1
            if len(low) == 2 and len(high) == 2:
                covered |= set(range(int(low, 16), int(high, 16) + 1))
                if len(targets) == 1:
                    for offset in range(int(high, 16) - int(low, 16) + 1):
                        point(targets[0], offset)
                else:
                    for target in targets:
                        point(target)
    return covered, produced


def unmapped_codes(document: Any, xref: int) -> frozenset[int]:
    """Codes of the simple font at ``xref`` that are drawn (width > 0) but absent from its ToUnicode map.

    Empty for a CID font (out of scope), a font without a ToUnicode map (its codes go through its
    encoding, so a real ``#`` is never flagged), and any code the font's ``/Encoding`` resolves: a named
    base encoding, a ``/BaseEncoding`` or a ``/Differences`` entry. Whitespace codes and codes whose own
    character the map produces from another code are not flagged either. Measured over the 513 readable
    retained GPO PDFs and the retained advocacy submissions, the only flag left is the Calibri ligature.
    Called once per font object; the caller caches it by xref.
    """
    if _resolved(document, xref, "Subtype") not in _SIMPLE_FONTS:
        return frozenset()
    kind, value = document.xref_get_key(xref, "ToUnicode")
    if kind != "xref":
        return frozenset()
    encoding = _resolved(document, xref, "Encoding")
    if encoding.startswith("/") or "/BaseEncoding" in encoding:
        return frozenset()
    first = int(_resolved(document, xref, "FirstChar") or 0)
    widths = [float(w) for w in _NUMBER.findall(_resolved(document, xref, "Widths"))]
    drawn = {first + i for i, width in enumerate(widths) if width > 0}
    cmap = document.xref_stream(int(value.split()[0]))
    if cmap is None:  # ToUnicode names a non-stream object: the reader falls back to the encoding
        return frozenset()
    covered, produced = _cmap(cmap)
    # A code the map leaves out comes back as itself, so it is told apart from a mapped character
    # only when no mapped code produces that character too (Symbol maps <03> to the © that 0xA9
    # would also print). Whitespace is left: a space code missing from a map extracts correctly.
    return frozenset(
        code
        for code in drawn - covered - _differences(document, encoding)
        if code not in produced and not chr(code).isspace()
    )


_INDIRECT_DIFFERENCES = re.compile(r"/Differences\s+(\d+)\s+\d+\s+R")


def _differences(document: Any, encoding: str) -> set[int]:
    """Codes a ``/Differences`` array names, from the encoding dictionary's source text.

    The array may be inline or an indirect reference (both legal PDF); the reference is followed once.
    """
    reference = _INDIRECT_DIFFERENCES.search(encoding)
    if reference:
        array = document.xref_object(int(reference.group(1)), compressed=True)
        body = array[array.index("[") + 1 : array.rindex("]")]
    else:
        start = encoding.find("/Differences")
        if start < 0:
            return set()
        body = encoding[encoding.index("[", start) + 1 : encoding.index("]", start)]
    named: set[int] = set()
    code = 0
    for token in re.findall(r"\d+|/[^\s/\[\]]+", body):
        if token.startswith("/"):
            named.add(code)
            code += 1
        else:
            code = int(token)
    return named


def unmapped_by_font(
    document: Any, fonts: Iterable[Sequence[Any]], cache: dict[int, frozenset[int] | None]
) -> tuple[dict[str, frozenset[int]], tuple[str, ...]]:
    """Span font name -> unmapped codes for one page's ``get_fonts()`` rows, parsing each xref once,
    and the names of fonts whose dictionary or ToUnicode map could not be read.

    Detection is advisory, so a malformed font (an unparsable map, a broken reference) fails open:
    it is reported back for the caller to flag, and text extraction proceeds as it would without
    the check. Two subsets sharing a stripped name on one page get the union of their codes
    (conservative).
    """
    # What a malformed dictionary or map raises while read: bad numbers or hex (ValueError,
    # OverflowError), a missing bracket or reference (IndexError, TypeError) and MuPDF's own errors.
    # Imported here so importing this module loads no renderer.
    from pymupdf.mupdf import FzErrorBase

    unreadable_errors = (ValueError, TypeError, RuntimeError, OverflowError, IndexError, FzErrorBase)
    found: dict[str, frozenset[int]] = {}
    unreadable: list[str] = []
    for row in fonts:
        xref, basefont = row[0], row[3]
        if xref not in cache:
            try:
                cache[xref] = unmapped_codes(document, xref)
            except unreadable_errors:
                cache[xref] = None
        name = re.sub(r"^[A-Z]{6}\+", "", basefont)
        codes = cache[xref]
        if codes is None:
            unreadable.append(name)
        elif codes:
            found[name] = found.get(name, frozenset()) | codes
    return found, tuple(dict.fromkeys(unreadable))


__all__ = [
    "FONT_GLYPHS",
    "MINUS",
    "UNDERSCORE",
    "FontGlyphCount",
    "map_line",
    "page_counts",
    "unmapped_by_font",
    "unmapped_codes",
]
