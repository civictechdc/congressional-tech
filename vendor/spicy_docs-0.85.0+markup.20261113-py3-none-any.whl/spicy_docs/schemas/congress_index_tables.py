"""The Congress.gov index tables ``house_communications``, ``committee_meetings``, ``record_issues``, ``treaties`` and
``nominations``, one row per record of one list or detail route.

Four of them read the list row (the only place the publisher states ``url``) plus the detail record, which repeats the
identifying fields and wins where both state one, so a list-valued column is ``[]`` where the detail was read and states
none and NULL where no detail was read.  ``house_communications`` carries two eras under one identity -- the publisher's
own decomposition and a pre-114th row reconstructed from the printed Record entry whose ``url`` and unresolved fields
stay NULL beside the retained sentence -- and Senate communications have no table because their detail record could fill
none of the columns that make this table a regulatory bridge.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from types import MappingProxyType
from typing import Any

from spicy_docs.schemas.tables import (
    Reference,
    Row,
    TableContractError,
    flag,
    joined,
    json_column,
    natural_key,
    table_contract,
    text,
)

#: What produced a ``house_communications`` row. A consumer that wants only the
#: publisher's own decomposition filters on the first.
COMMUNICATION_SOURCE_ROUTES: tuple[str, ...] = ("congress-gov-detail", "congressional-record-granule")

HOUSE_COMMUNICATIONS = table_contract(
    "house_communications",
    grain=(
        "One row per House executive communication: the Congress.gov house-communication routes where the "
        "publisher decomposes it, the Congressional Record entry it printed where the publisher does not."
    ),
    identity=("congress", "communication_type", "number"),
    version_column="update_date",
    columns={
        "communication_id": "Natural key: congress, lowercase communication type and number joined with hyphens.",
        "congress": "The numbered Congress the communication was received in.",
        "communication_type": (
            "The publisher's communication type code, lowercased the way its own address spells it (ec, ml, ...)."
        ),
        "communication_type_name": "The publisher's name for that type (Executive Communication, Memorial, ...).",
        "number": "The communication's number within its Congress and type.",
        "chamber": "The chamber, as the publisher spells it.",
        "session": "The session of Congress the communication was received in.",
        "abstract": (
            "The publisher's abstract: the Record's own description of the communication. On a "
            "`congressional-record-granule` row it is the printed entry under the four normalizations the "
            "publisher's own abstract applies, which `record_entry_text` keeps unapplied."
        ),
        "report_nature": "The nature of the report transmitted, where the detail states one; where the RIN is read from.",
        "legal_authority": (
            "The statutory authority the communication cites, where the detail states one; a Congressional "
            "Review Act rule submission cites 5 U.S.C. 801(a)(1)(A)."
        ),
        "submitting_agency": "The agency that submitted the communication, where the detail states one.",
        "submitting_official": "The official who submitted it, where the detail states one.",
        "congressional_record_date": "The date the communication appeared in the Congressional Record.",
        "is_rulemaking": (
            "Whether the publisher flags the communication as a rulemaking: the publisher's `True`/`False` strings "
            "folded onto the one published truth spelling; any other spelling refuses."
        ),
        "referral_system_code": (
            "System code of the first committee the communication was referred to. NULL on a "
            "`congressional-record-granule` row: the Record prints a name, and the resolver from a name to a "
            "`committees.system_code` is not built."
        ),
        "referral_committee_name": (
            "That committee's name as the publisher spells it; on a `congressional-record-granule` row, as the "
            "Record printed it, which is the committee's name on the day and agrees with Congress.gov's "
            "current spelling on 71.5% of held-out rows. Resolve identity through `referral_system_code`, "
            "never through this."
        ),
        "referral_date": "The date of that referral.",
        "referral_count": "How many committees the detail lists; every one is in committees_json, and NULL where it is NULL.",
        "committees_json": (
            "Every committee referral the detail lists, as a JSON array of the publisher's objects. NULL where "
            "no detail was read or the detail states no committees; `[]` where it states an empty list. On a `congressional-record-granule` row, one `{name}` object per committee the "
            "printed referral tail names, in printed order."
        ),
        "matching_requirement_number": "Number of the first House reporting requirement the communication matches.",
        "matching_requirement_count": (
            "How many requirements the detail lists; every one is in matching_requirements_json, and NULL where it is NULL."
        ),
        "matching_requirements_json": (
            "Every matching requirement the detail lists, as a JSON array of numbers. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one."
        ),
        "rin": (
            "The Regulation Identifier Number read from report_nature, where the rule found one: the first "
            "occurrence in rin_occurrences_json that a RIN label directly precedes, as its published key."
        ),
        "rin_occurrences_json": (
            "All interpreted RIN occurrences supplied by the consumer, with exact field spans and digest. NULL means "
            "unread; [] means the supplied field was read and contained no RIN. Each occurrence's field_sha256 is "
            "spelled sha256: plus the hex digest under the rule report_nature/shared_rin/2; one stored under the "
            "earlier report_nature/shared_rin carries the bare hex and is re-read, not reused."
        ),
        "rin_rule": (
            "Which RIN rule fired (`report_nature_rin_label/2`), or `unmatched`; NULL where the rule was not run. "
            "Rows read before 0.50.1 name `report_nature_rin_label`, the older pattern."
        ),
        "rin_matched_text": (
            "The exact text the RIN rule matched, the label and the RIN as printed, so a false positive is "
            "readable from the row."
        ),
        "update_date": (
            "The publisher's updateDate; the merge prefers the larger value, except across source_route, "
            "where a `congress-gov-detail` row always wins."
        ),
        "url": (
            "The publisher's own URL for this communication, which only the list row states. NULL on a "
            "`congressional-record-granule` row: the detail route 404s for every pre-114th communication."
        ),
        "source_route": (
            "What produced this row: `congress-gov-detail` where the publisher decomposed the communication "
            "itself, `congressional-record-granule` where it was reconstructed from the printed entry."
        ),
        "record_package_id": (
            "The CREC package whose issue printed the entry (`CREC-{congressional_record_date}`); NULL on a "
            "publisher-decomposed row."
        ),
        "record_granule_id": (
            "The `EXECUTIVE COMMUNICATIONS, ETC.` granule within that package, so the row is replayable the "
            "way `committee_reports` replays from `package_id`; NULL on a publisher-decomposed row."
        ),
        "record_entry_text": (
            "The sentence the Record printed, GPO's own wording with none of the publisher's normalizations "
            "applied, kept beside the derived fields the way `rin_matched_text` is kept beside `rin`, so a bad "
            "parse is readable from the row; NULL on a publisher-decomposed row."
        ),
        "reconstruction_rule_version": (
            "The `record-communication-` rule identity that produced the derived fields "
            "(`RECORD_COMMUNICATION_RULE_VERSION`); NULL on a publisher-decomposed row."
        ),
        "detail_read": (
            "`true` where the Congress.gov detail route was read for this row, `false` where the row holds the list route's record only (a detail not yet reached under a run's cap, or refused). The one test of whether a detail was read: a list column cannot say it, because a read detail omits a list it does not state and the column is then NULL as for an unread one."
            " `false` on a `congressional-record-granule` row, which no detail route serves."
        ),
    },
)

COMMITTEE_MEETINGS = table_contract(
    "committee_meetings",
    references=(Reference(("committee_system_code",), "committees", ("system_code",)),),
    grain="One row per scheduled committee meeting, as the Congress.gov committee-meeting routes state it.",
    identity=("congress", "chamber", "event_id"),
    version_column="update_date",
    columns={
        "congress": "The numbered Congress the meeting belongs to.",
        "chamber": (
            "The publisher's chamber value, lowercased as its address spells it "
            "(house, senate, joint, nochamber). NoChamber stays nochamber, not an inferred chamber."
        ),
        "event_id": "The publisher's event id, the key hearing_transcripts.event_id joins on.",
        "title": "The meeting title as the detail states it.",
        "meeting_type": "The publisher's meeting type (Hearing, Markup, ...).",
        "meeting_status": "The publisher's meeting status (Scheduled, Rescheduled, ...).",
        "meeting_date": "The meeting's date-time instant as the detail states it.",
        "location_building": "The building the detail names.",
        "location_room": "The room the detail names.",
        "committee_system_code": "System code of the first committee the detail lists.",
        "committee_count": "How many committees the detail lists; every one is in committees_json, and NULL where it is NULL.",
        "committees_json": (
            "Every committee the detail lists, as a JSON array of the publisher's objects. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one."
        ),
        "hearing_jacket": "The first hearing transcript jacket number the detail lists, where it lists any.",
        "hearing_jacket_count": (
            "How many transcript jackets the detail lists; every one is in hearing_jackets_json, and NULL where it is NULL."
        ),
        "hearing_jackets_json": (
            "Every transcript jacket number the detail lists, as a JSON array of strings. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one."
        ),
        "bill_count": "How many bills the detail relates to the meeting; every one is in bill_ids_json, and NULL where it is NULL.",
        "bill_ids_json": (
            "Natural keys of every bill in relatedItems.bills, as a JSON array, in publisher order; a bill named "
            "only in a meeting document is not here. NULL where no detail was read or the detail states no "
            "relatedItems.bills; `[]` where it states an empty one."
        ),
        "nomination_references_json": "Publisher-listed related nominations, including Congress, number, partition and URL; NULL when not stated or unread, [] only when stated empty.",
        "treaty_references_json": "Publisher-listed related treaties, including Congress, number, partition and URL; NULL when not stated or unread, [] only when stated empty.",
        "witness_count": (
            "How many witness entries the detail lists, repeats included; not a count of people. NULL where "
            "witnesses_json is NULL."
        ),
        "witnesses_json": (
            "Every witness entry the detail lists, as a JSON array of the publisher's objects, in publisher order "
            "and as published: an entry can repeat within one meeting, so count people by name, not entries. NULL "
            "where no detail was read or the detail states no witnesses (the Senate and NoChamber details retained "
            "so far omit the key: no witness list, not an empty one); `[]` where it states an empty one."
        ),
        "witness_document_count": "How many witness documents the detail lists; NULL where witness_documents_json is NULL.",
        "witness_documents_json": (
            "Every witness document the detail lists, as a JSON array of the publisher's objects. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one."
        ),
        "meeting_document_count": "How many meeting documents the detail lists; NULL where meeting_documents_json is NULL.",
        "meeting_documents_json": (
            "Every meeting document the detail lists, as a JSON array of the publisher's objects. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one."
        ),
        "document_urls_json": (
            "The URL of every document the meeting lists, witness documents first then meeting documents, "
            "in publisher order: what the map's meeting-to-documents edge resolves. NULL where neither list is "
            "stated (or no detail was read); `[]` where the stated lists carry no URL."
        ),
        "videos_json": (
            "Every video link the detail lists, as a JSON array of the publisher's objects. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one."
        ),
        "update_date": "The publisher's updateDate; the merge prefers the larger value.",
        "url": "The publisher's own URL for this meeting, which only the list row states.",
        "detail_read": (
            "`true` where the Congress.gov detail route was read for this row, `false` where the row holds the list route's record only (a detail not yet reached under a run's cap, or refused). The one test of whether a detail was read: a list column cannot say it, because a read detail omits a list it does not state and the column is then NULL as for an unread one."
        ),
    },
)

#: The rule the map's ``record→legislative-day`` edge measured: an issue's
#: ``fullIssue.sections[].name`` says which chamber met.  The Daily Digest
#: and Extensions of Remarks are sections too, and name no chamber sitting.
SECTION_CHAMBERS: Mapping[str, str] = MappingProxyType({"House Section": "house", "Senate Section": "senate"})
CHAMBERS_RULE = "section_name"
#: The map's ``record→package`` rule: the issue's own link names the GovInfo
#: package by its file stem (``CREC-2026-09-18.pdf`` is ``CREC-2026-09-18``).
#: ``/2`` reads the link for ``part`` 1 rather than the first one listed: an
#: issue printed in several books lists each book's PDF, a later book's stem
#: is ``-bk{N}`` of the same package, and the list is not in part order, so the
#: first link named a package GovInfo does not have (docs/decisions.md, "A
#: Record issue's package id is its first book's stem").
PACKAGE_ID_RULE_RECORD = "entire_issue_url_stem/2"
#: The map's ``treaty→cdoc`` rule, resolved 2 of 2 on the 119th's treaties.
PACKAGE_ID_RULE_TREATY = "cdoc_tdoc_number"

RECORD_ISSUES = table_contract(
    "record_issues",
    grain="One row per daily Congressional Record issue, which is also one legislative day per chamber named.",
    identity=("volume", "issue"),
    version_column="update_date",
    columns={
        "volume": "The Record volume number.",
        "issue": "The issue number within that volume, as the publisher spells it.",
        "congress": "The numbered Congress the issue belongs to.",
        "session": "The session of Congress the issue belongs to.",
        "issue_date": "The issue date instant as the publisher states it.",
        "chambers": (
            "Which chambers this issue records a sitting of, unit-separator joined and sorted (`house`, `senate`); "
            "NULL where sections_json is NULL, empty where the detail names no chamber section."
        ),
        "chambers_rule": "How chambers was derived: `section_name`, from the detail's section names.",
        "section_count": "How many sections the detail lists; NULL where sections_json is NULL.",
        "section_names": (
            "Every section name the detail lists, unit-separator joined, in publisher order; NULL where sections_json "
            "is NULL."
        ),
        "sections_json": "Every section the detail lists, as a JSON array of the publisher's objects. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one.",
        "entire_issue_json": (
            "Every whole-issue rendition the detail lists, as a JSON array of the publisher's objects. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one."
        ),
        "package_id": (
            "The GovInfo CREC package id read from the file stem of the whole-issue link for part 1. "
            "NULL where the detail lists no part 1, or part 1 links under two stems."
        ),
        "package_id_rule": "How package_id was derived: `entire_issue_url_stem/2`.",
        "article_count": "How many articles the detail says the issue has.",
        "articles_url": "The publisher's URL for the issue's article list.",
        "update_date": "The publisher's updateDate; the merge prefers the larger value.",
        "url": "The publisher's own URL for this issue.",
        "detail_read": (
            "`true` where the Congress.gov detail route was read for this row, `false` where the row holds the list route's record only (a detail not yet reached under a run's cap, or refused). The one test of whether a detail was read: a list column cannot say it, because a read detail omits a list it does not state and the column is then NULL as for an unread one."
        ),
    },
)

TREATIES = table_contract(
    "treaties",
    grain="One row per treaty document, as the Congress.gov treaty routes state it.",
    identity=("congress_received", "number", "suffix"),
    version_column="update_date",
    columns={
        "treaty_id": "Natural key: the Congress received, the number and, where one exists, the suffix, hyphen-joined.",
        "congress_received": "The Congress the treaty was received in.",
        "congress_considered": "The Congress the treaty was considered in, where the publisher states one.",
        "number": "The treaty document number.",
        "suffix": "The part suffix, as the publisher spells it (empty on an unpartitioned treaty).",
        "old_number": "The publisher's old number, where one exists.",
        "old_number_display_name": "The publisher's display name for that old number, where one exists.",
        "topic": "The publisher's topic.",
        "transmitted_date": "The instant the treaty was transmitted to the Senate.",
        "in_force_date": "The instant the treaty entered into force, where the publisher states one.",
        "resolution_text": "The resolution of ratification text, where the detail states one.",
        "formal_title": "The detail's `Treaty - Formal Title` entry.",
        "short_title": "The detail's `Treaty - Short Title` entry.",
        "titles_json": "Every title the detail lists, as a JSON array of the publisher's objects. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one.",
        "countries_json": "Every country party the detail names, as a JSON array of names. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one.",
        "index_terms_json": "Every index term the detail names, as a JSON array of names. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one.",
        "related_docs_json": (
            "Every related document the detail lists, as a JSON array of the publisher's objects. NULL where no detail was read or the detail states no such list; `[]` where it states an empty one."
        ),
        "parts_json": "The publisher's parts object, as JSON.",
        "action_count": "How many actions the detail says the treaty has.",
        "actions_url": "The publisher's URL for the treaty's action list.",
        "package_id": "The GovInfo CDOC package id derived from the treaty number, on a treaty with no suffix.",
        "package_id_rule": "How package_id was derived: `cdoc_tdoc_number`.",
        "update_date": "The publisher's updateDate; the merge prefers the larger value.",
        "url": "The publisher's own URL for this treaty, which only the list row states.",
        "detail_read": (
            "`true` where the Congress.gov detail route was read for this row, `false` where the row holds the list route's record only (a detail not yet reached under a run's cap, or refused). The one test of whether a detail was read: a list column cannot say it, because a read detail omits a list it does not state and the column is then NULL as for an unread one."
        ),
    },
)

NOMINATIONS = table_contract(
    "nominations",
    grain="One row per nomination or part, as the Congress.gov nomination list route states it.",
    identity=("congress", "citation"),
    version_column="update_date",
    columns={
        "nomination_id": "Canonical nomination key ({congress}-pn-{number}, plus -{part} when part_number is non-zero).",
        "citation": "The publisher's citation, its own display key, with the part where one exists (PN730-20).",
        "congress": "The numbered Congress the nomination was received in.",
        "number": "The PN number.",
        "part_number": "The part number, as the publisher spells it.",
        "description": "The publisher's description of the nomination.",
        "organization": "The organization the nominee would serve in.",
        "received_date": "The date the Senate received the nomination.",
        "is_civilian": (
            "Whether the nomination is civilian, as the publisher's nominationType states it: `true` where it states "
            "isCivilian true (or isMilitary false), `false` where it states isMilitary true (or isCivilian false). "
            "The list route states exactly one of the two keys (2,287 of 2,287 rows of the 119th, 2026-10-03). NULL "
            "where it states neither, or both with contradicting values; nomination_type_json keeps what it stated, "
            "so `is_civilian IS NULL AND nomination_type_json IS NOT NULL` counts the contradictions."
        ),
        "nomination_type_json": "The publisher's nominationType object, as JSON.",
        "latest_action_date": "Date of the publisher's latestAction entry.",
        "latest_action_text": "Text of the publisher's latestAction entry.",
        "update_date": "The publisher's updateDate; the merge prefers the larger value.",
        "url": "The publisher's own URL for this nomination.",
        "committees_json": "Every committee returned by the nomination committees route, in source order; NULL when unread, [] on a complete empty response.",
        "hearings_json": "Every printed hearing returned by the nomination hearings route, including jacket number and chamber; NULL when unread, [] on a complete empty response.",
        "detail_read": "Whether this nomination's detail and both relationship lists were read successfully.",
    },
)


def _mapping(value: object) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _sequence(value: object) -> Sequence[Any]:
    return value if isinstance(value, Sequence) and not isinstance(value, str | bytes) else ()


def _listed(detail: Mapping[str, Any] | None, key: str) -> tuple[Any, ...] | None:
    """A detail's list as the publisher states it: NULL when no detail was read or the detail states no such key
    (Congress.gov omits a list rather than stating it empty: a Senate meeting's detail has no ``witnesses`` key),
    empty only when the detail states an empty list."""
    if detail is None or detail.get(key) is None:
        return None
    return tuple(_sequence(detail.get(key)))


def _json_or_null(value: object) -> str | None:
    return None if value is None else json_column(value)


def _count(value: Sequence[Any] | None) -> str | None:
    return None if value is None else str(len(value))


def _first(value: Sequence[Any] | None) -> Mapping[str, Any]:
    return _mapping(value[0]) if value else {}


_RULEMAKING: Mapping[str, bool] = MappingProxyType({"True": True, "False": False})


def _rulemaking(value: object) -> str | None:
    """Fold the publisher's ``"True"``/``"False"`` strings; refuse any other spelling."""
    if value is None:
        return None
    if isinstance(value, bool):
        return flag(value)
    if isinstance(value, str) and value in _RULEMAKING:
        return flag(_RULEMAKING[value])
    raise TableContractError(f"house_communications: isRulemaking is spelled {value!r}, which no rule folds")


def shape_house_communication(
    listed: Mapping[str, Any],
    detail: Mapping[str, Any] | None,
    *,
    rin: object | None = None,
    rin_occurrences: Sequence[Mapping[str, Any]] | None = None,
) -> Row:
    """One ``house_communications`` row from a list row and its detail record.

    ``listed`` is the list route's row for this communication, or the detail record itself when no list row was
    retained; ``rin`` is a ``RinFinding`` from ``rin_from_report_nature`` over the detail's ``reportNature``, or
    ``None`` when that rule was not run. ``rin_occurrences`` is supplied by the
    consumer without interpretation here: None means unread, an empty sequence
    means the complete selected field was read with no occurrences.
    """
    read = _chain(listed, detail)
    kind = _mapping(read.get("communicationType"))
    code = kind.get("code")
    committees = _listed(detail, "committees")
    requirements = _listed(detail, "matchingRequirements")
    referral = _first(committees)
    requirement = _first(requirements)
    return {
        "communication_id": natural_key(read.get("congress"), code, read.get("number")),
        "congress": text(read.get("congress")),
        "communication_type": None if code is None else str(code).lower(),
        "communication_type_name": text(kind.get("name")),
        "number": text(read.get("number")),
        "chamber": text(read.get("chamber")),
        "session": text(read.get("sessionNumber")),
        "abstract": text(read.get("abstract")),
        "report_nature": text(read.get("reportNature")),
        "legal_authority": text(read.get("legalAuthority")),
        "submitting_agency": text(read.get("submittingAgency")),
        "submitting_official": text(read.get("submittingOfficial")),
        "congressional_record_date": text(read.get("congressionalRecordDate")),
        "is_rulemaking": _rulemaking(read.get("isRulemaking")),
        "referral_system_code": text(referral.get("systemCode")),
        "referral_committee_name": text(referral.get("name")),
        "referral_date": text(referral.get("referralDate")),
        "referral_count": _count(committees),
        "committees_json": _json_or_null(committees),
        "matching_requirement_number": text(requirement.get("number")),
        "matching_requirement_count": _count(requirements),
        "matching_requirements_json": (
            None if requirements is None else json_column([_mapping(entry).get("number") for entry in requirements])
        ),
        "rin": None if rin is None else text(rin.rin),
        "rin_occurrences_json": None if rin_occurrences is None else json_column(rin_occurrences),
        "rin_rule": None if rin is None else text(rin.rule),
        "rin_matched_text": None if rin is None else text(rin.matched_text),
        "update_date": text(read.get("updateDate")),
        "url": text(listed.get("url")),
        "source_route": COMMUNICATION_SOURCE_ROUTES[0],
        "record_package_id": None,
        "record_granule_id": None,
        "record_entry_text": None,
        "reconstruction_rule_version": None,
        "detail_read": flag(detail is not None),
    }


#: The Record prints this section under the House heading, and Congress.gov
#: spells that chamber ``House`` on every row of the same table. Folding
#: GovInfo's ``granuleClass: HOUSE`` onto the publisher's spelling is a
#: normalization; leaving the column NULL would be losing a fact the section
#: itself states.
_RECORD_CHAMBER = "House"


def shape_record_communication(
    entry: Any,
    *,
    congress: int | str,
    record_date: str,
    rin: object | None = None,
    rin_occurrences: Sequence[Mapping[str, Any]] | None = None,
) -> Row:
    """One ``house_communications`` row reconstructed from a printed Record entry, with every unresolved field NULL
    beside the whole printed sentence retained in ``record_entry_text``.

    ``url`` is NULL because the detail route 404s for every pre-114th communication, the official/agency split scored
    88.4% against a threshold declared at 90%, and ``referral_system_code`` awaits a name-to-``system_code`` resolver
    that is not built; ``referral_date`` is filled from the Record date, which equals the publisher's ``referralDate``
    on 264 of 264 retained referrals.
    """
    committees = tuple(entry.committee_names)
    return {
        "communication_id": natural_key(congress, entry.communication_type, entry.number),
        "congress": text(congress),
        "communication_type": text(entry.communication_type),
        "communication_type_name": None,
        "number": text(entry.number),
        "chamber": _RECORD_CHAMBER,
        "session": None,
        # The measured finding: the publisher's abstract *is* this sentence,
        # under four named normalizations (97.9% on held-out rows). The column
        # carries the normalized form -- the value the publisher would have
        # carried -- and `record_entry_text` keeps the print exactly as GPO set
        # it, so the two differ on a row wherever a normalization fired.
        "abstract": text(entry.publisher_abstract),
        "report_nature": text(entry.report_nature),
        "legal_authority": text(entry.legal_authority),
        "submitting_agency": None,
        "submitting_official": None,
        "congressional_record_date": text(record_date),
        "is_rulemaking": None,
        "referral_system_code": None,
        "referral_committee_name": committees[0] if committees else None,
        "referral_date": text(record_date),
        "referral_count": str(len(committees)),
        "committees_json": json_column([{"name": name} for name in committees]),
        "matching_requirement_number": None,
        "matching_requirement_count": None,
        "matching_requirements_json": None,
        "rin": None if rin is None else text(rin.rin),
        "rin_occurrences_json": None if rin_occurrences is None else json_column(rin_occurrences),
        "rin_rule": None if rin is None else text(rin.rule),
        "rin_matched_text": None if rin is None else text(rin.matched_text),
        "update_date": None,
        "url": None,
        "source_route": COMMUNICATION_SOURCE_ROUTES[1],
        "record_package_id": text(entry.record_package_id),
        "record_granule_id": text(entry.record_granule_id),
        "record_entry_text": text(entry.entry_text),
        "reconstruction_rule_version": text(entry.rule_version),
        "detail_read": flag(False),
    }


def _chain(listed: Mapping[str, Any], detail: Mapping[str, Any] | None) -> Mapping[str, Any]:
    """The detail's fields over the list row's, the detail winning where both state one."""
    if not isinstance(listed, Mapping):
        raise TableContractError("a list row must be a mapping")
    if detail is None:
        return listed
    if not isinstance(detail, Mapping):
        raise TableContractError("a detail record must be a mapping or None")
    return {**listed, **detail}


def _urls(entries: Sequence[Any]) -> list[str]:
    return [str(url) for entry in entries if (url := _mapping(entry).get("url"))]


def shape_committee_meeting(listed: Mapping[str, Any], detail: Mapping[str, Any] | None) -> Row:
    """One ``committee_meetings`` row from a list row and its detail record.

    ``listed`` is the list route's row for this meeting, or the detail record
    itself when no list row was retained.
    """
    read = _chain(listed, detail)
    location = _mapping(read.get("location"))
    committees = _listed(detail, "committees")
    jackets = _listed(detail, "hearingTranscript")
    related = None if detail is None else detail.get("relatedItems")
    bills = _listed(related if isinstance(related, Mapping) else None, "bills")
    nominations = _listed(related if isinstance(related, Mapping) else None, "nominations")
    treaties = _listed(related if isinstance(related, Mapping) else None, "treaties")
    witnesses = _listed(detail, "witnesses")
    witness_documents = _listed(detail, "witnessDocuments")
    meeting_documents = _listed(detail, "meetingDocuments")
    videos = _listed(detail, "videos")
    chamber = read.get("chamber")
    jacket_numbers = None if jackets is None else [str(_mapping(entry).get("jacketNumber")) for entry in jackets]
    return {
        "congress": text(read.get("congress")),
        "chamber": None if chamber is None else str(chamber).lower(),
        "event_id": text(read.get("eventId")),
        "title": text(read.get("title")),
        "meeting_type": text(read.get("type")),
        "meeting_status": text(read.get("meetingStatus")),
        "meeting_date": text(read.get("date")),
        "location_building": text(location.get("building")),
        "location_room": text(location.get("room")),
        "committee_system_code": text(_first(committees).get("systemCode")),
        "committee_count": _count(committees),
        "committees_json": _json_or_null(committees),
        "hearing_jacket": None if not jacket_numbers else jacket_numbers[0],
        "hearing_jacket_count": _count(jackets),
        "hearing_jackets_json": _json_or_null(jacket_numbers),
        "bill_count": _count(bills),
        "bill_ids_json": (
            None
            if bills is None
            else json_column(
                [
                    natural_key(entry.get("congress"), entry.get("type"), entry.get("number"))
                    for entry in map(_mapping, bills)
                ]
            )
        ),
        "nomination_references_json": _json_or_null(nominations),
        "treaty_references_json": _json_or_null(treaties),
        "witness_count": _count(witnesses),
        "witnesses_json": _json_or_null(witnesses),
        "witness_document_count": _count(witness_documents),
        "witness_documents_json": _json_or_null(witness_documents),
        "meeting_document_count": _count(meeting_documents),
        "meeting_documents_json": _json_or_null(meeting_documents),
        "document_urls_json": (
            None
            if witness_documents is None and meeting_documents is None
            else json_column(_urls(witness_documents or ()) + _urls(meeting_documents or ()))
        ),
        "videos_json": _json_or_null(videos),
        "update_date": text(read.get("updateDate")),
        "url": text(listed.get("url")),
        "detail_read": flag(detail is not None),
    }


def _package_stem(url: object) -> str | None:
    """``.../CREC-2026-09-18.pdf`` names package ``CREC-2026-09-18``; anything else is NULL."""
    if not isinstance(url, str) or not url:
        return None
    stem = url.rsplit("/", 1)[-1]
    stem = stem.split(".", 1)[0]
    return stem or None


def _record_package_id(entire: Sequence[Any]) -> str | None:
    """The stem of the part-1 whole-issue link, where exactly one stem is stated for part 1; else NULL.

    Later books are ``-bk{N}`` files of the same package and may be listed
    first, so the part is read, not the position.
    """
    stems = {_package_stem(entry.get("url")) for entry in map(_mapping, entire) if text(entry.get("part")) == "1"}
    return stems.pop() if len(stems) == 1 else None


def shape_record_issue(listed: Mapping[str, Any], detail: Mapping[str, Any] | None) -> Row:
    """One ``record_issues`` row from a list row and its detail record (the ``issue`` object)."""
    read = _chain(listed, detail)
    stated = None if detail is None else detail.get("fullIssue")
    full = stated if isinstance(stated, Mapping) else None
    sections = _listed(full, "sections")
    entire = _listed(full, "entireIssue")
    articles = {} if full is None else _mapping(full.get("articles"))
    names = None if sections is None else [str(_mapping(section).get("name")) for section in sections]
    chambers = None if names is None else sorted({SECTION_CHAMBERS[name] for name in names if name in SECTION_CHAMBERS})
    package_id = None if not entire else _record_package_id(entire)
    return {
        "volume": text(read.get("volumeNumber")),
        "issue": text(read.get("issueNumber")),
        "congress": text(read.get("congress")),
        "session": text(read.get("sessionNumber")),
        "issue_date": text(read.get("issueDate")),
        "chambers": None if chambers is None else joined(chambers),
        "chambers_rule": None if chambers is None else CHAMBERS_RULE,
        "section_count": _count(sections),
        "section_names": None if names is None else joined(names),
        "sections_json": _json_or_null(sections),
        "entire_issue_json": _json_or_null(entire),
        "package_id": package_id,
        "package_id_rule": None if package_id is None else PACKAGE_ID_RULE_RECORD,
        "article_count": text(articles.get("count")),
        "articles_url": text(articles.get("url")),
        "update_date": text(read.get("updateDate")),
        "url": text(read.get("url")),
        "detail_read": flag(detail is not None),
    }


def treaty_id(congress: object, number: object, suffix: object) -> str:
    """``{congress}-{number}``, plus ``-{suffix}`` on a partitioned treaty."""
    return f"{congress}-{number}" + (f"-{suffix}" if suffix else "")


def treaty_package_id(congress: object, number: object, suffix: object) -> str | None:
    """The map's ``treaty→cdoc`` rule, on an unpartitioned treaty only."""
    if congress is None or number is None or suffix:
        return None
    return f"CDOC-{congress}tdoc{number}"


def shape_treaty(listed: Mapping[str, Any], detail: Mapping[str, Any] | None) -> Row:
    """One ``treaties`` row from a list row and its detail record."""
    read = _chain(listed, detail)
    congress, number, suffix = read.get("congressReceived"), read.get("number"), read.get("suffix")
    titles = _listed(detail, "titles")
    by_type = (
        {} if titles is None else {_mapping(entry).get("titleType"): _mapping(entry).get("title") for entry in titles}
    )
    countries = _listed(detail, "countriesParties")
    terms = _listed(detail, "indexTerms")
    related = _listed(detail, "relatedDocs")
    actions = {} if detail is None else _mapping(detail.get("actions"))
    parts = read.get("parts")
    package_id = treaty_package_id(congress, number, suffix)
    return {
        "treaty_id": treaty_id(congress, number, suffix),
        "congress_received": text(congress),
        "congress_considered": text(read.get("congressConsidered")),
        "number": text(number),
        "suffix": text(suffix),
        "old_number": text(read.get("oldNumber")),
        "old_number_display_name": text(read.get("oldNumberDisplayName")),
        "topic": text(read.get("topic")),
        "transmitted_date": text(read.get("transmittedDate")),
        "in_force_date": text(read.get("inForceDate")),
        "resolution_text": text(read.get("resolutionText")),
        "formal_title": text(by_type.get("Treaty - Formal Title")),
        "short_title": text(by_type.get("Treaty - Short Title")),
        "titles_json": _json_or_null(titles),
        "countries_json": None
        if countries is None
        else json_column([_mapping(entry).get("name") for entry in countries]),
        "index_terms_json": None if terms is None else json_column([_mapping(entry).get("name") for entry in terms]),
        "related_docs_json": _json_or_null(related),
        "parts_json": None if not isinstance(parts, Mapping) else json_column(dict(parts)),
        "action_count": text(actions.get("count")),
        "actions_url": text(actions.get("url")),
        "package_id": package_id,
        "package_id_rule": None if package_id is None else PACKAGE_ID_RULE_TREATY,
        "update_date": text(read.get("updateDate")),
        "url": text(listed.get("url")),
        "detail_read": flag(detail is not None),
    }


def _is_civilian(kind: object) -> bool | None:
    """Read civilian status from both keys the publisher may state: ``{"isCivilian": true}`` or ``{"isMilitary":
    true}`` (it states exactly one), so a military nomination's answer is stated, as the other key. Two keys that
    disagree with each other (both true, both false) are no answer, and neither key is none.
    """
    stated = _mapping(kind)
    civilian, military = stated.get("isCivilian"), stated.get("isMilitary")
    from_civilian = civilian if isinstance(civilian, bool) else None
    from_military = (not military) if isinstance(military, bool) else None
    if from_civilian is None:
        return from_military
    return from_civilian if from_military in (None, from_civilian) else None


def _nonnegative_int(value: object) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return value if value >= 0 else None
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.isdecimal() and stripped.isascii():
            return int(stripped)
    return None


def nomination_id(congress: object, number: object, part_number: object = None) -> str | None:
    """``{congress}-pn-{number}``, plus ``-{int(part)}`` unless the part is 0 or absent."""
    parsed_congress = _nonnegative_int(congress)
    parsed_number = _nonnegative_int(number)
    if parsed_congress is None or parsed_number is None:
        return None
    base = f"{parsed_congress}-pn-{parsed_number}"
    if part_number is None or (isinstance(part_number, str) and not part_number.strip()):
        return base
    parsed_part = _nonnegative_int(part_number)
    if parsed_part is None:
        return None
    return base if parsed_part == 0 else f"{base}-{parsed_part}"


def shape_nomination(record: Mapping[str, Any], detail: Mapping[str, Any] | None = None) -> Row:
    """One nomination with optional complete, independently walked relationship lists."""
    if not isinstance(record, Mapping):
        raise TableContractError("a nomination record must be a mapping")
    record = _chain(record, detail)
    latest = _mapping(record.get("latestAction"))
    kind = record.get("nominationType")
    civilian = _mapping(kind).get("isCivilian")
    return {
        "nomination_id": nomination_id(record.get("congress"), record.get("number"), record.get("partNumber")),
        "citation": text(record.get("citation")),
        "congress": text(record.get("congress")),
        "number": text(record.get("number")),
        "part_number": text(record.get("partNumber")),
        "description": text(record.get("description")),
        "organization": text(record.get("organization")),
        "received_date": text(record.get("receivedDate")),
        "is_civilian": text(civilian)
        if civilian is not None and not isinstance(civilian, bool)
        else flag(_is_civilian(kind)),
        "nomination_type_json": None if not isinstance(kind, Mapping) else json_column(dict(kind)),
        "latest_action_date": text(latest.get("actionDate")),
        "latest_action_text": text(latest.get("text")),
        "update_date": text(record.get("updateDate")),
        "url": text(record.get("url")),
        "committees_json": _json_or_null(_listed(detail, "committee_records")),
        "hearings_json": _json_or_null(_listed(detail, "hearing_records")),
        "detail_read": flag(detail is not None and "committee_records" in detail and "hearing_records" in detail),
    }


__all__ = [
    "CHAMBERS_RULE",
    "COMMITTEE_MEETINGS",
    "COMMUNICATION_SOURCE_ROUTES",
    "HOUSE_COMMUNICATIONS",
    "NOMINATIONS",
    "PACKAGE_ID_RULE_RECORD",
    "PACKAGE_ID_RULE_TREATY",
    "RECORD_ISSUES",
    "SECTION_CHAMBERS",
    "TREATIES",
    "nomination_id",
    "shape_committee_meeting",
    "shape_house_communication",
    "shape_nomination",
    "shape_record_communication",
    "shape_record_issue",
    "shape_treaty",
    "treaty_id",
    "treaty_package_id",
]
