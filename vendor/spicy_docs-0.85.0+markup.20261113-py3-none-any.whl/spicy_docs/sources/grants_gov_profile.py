"""One admitted Grants.gov daily export through the existing source-release file stream."""

import hashlib
import re
from contextlib import closing
from dataclasses import dataclass
from functools import cache

from rulespec_artifacts import canonical_json_bytes, schema_bundle_digest

from spicy_docs.releases.profile import SourceNativeBlobPage, SourceNativeProfile
from spicy_docs.sources.grants_gov import MAX_ZIP_BYTES, GrantsGovError, grants_scope, snapshot_records, validate_scope

SCOPE_ID = "grants-gov-opportunity-snapshot-v1"
SCHEMA_NAME = "grants-gov-opportunity-observation"
SCHEMA_KEY = f"schemas/{SCHEMA_NAME}-1.0.json"
MAX_PAGE_BYTES = 1024**2
MAX_PAGE_RECORDS = 100
_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": f"urn:spicy-docs:schema:{SCHEMA_NAME}:1.0",
    "type": "object",
    "additionalProperties": False,
    "required": ["snapshot_date", "notice_type", "opportunity_id", "version", "ordinal", "fields", "source_locator"],
    "properties": {
        "snapshot_date": {"type": "string"},
        "notice_type": {"enum": ["synopsis", "forecast"]},
        "opportunity_id": {"type": "string", "pattern": "^[0-9]{1,20}$"},
        "version": {"type": ["string", "null"]},
        "ordinal": {"type": "integer", "minimum": 0},
        "fields": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["tag", "text", "attributes", "source_xpath"],
                "properties": {
                    "tag": {"type": "string"},
                    "text": {"type": "string"},
                    "attributes": {"type": "object", "additionalProperties": {"type": "string"}},
                    "source_xpath": {"type": "string"},
                },
            },
        },
        "source_locator": {"type": "object"},
    },
    "x-spicy-record-order": [
        {
            "fieldPath": path,
            "nullOrder": "forbidden",
            "tupleComparison": "utf16-code-unit",
            "valueType": "string",
        }
        for path in ("/notice_type", "/opportunity_id")
    ],
}


def _key(index):
    return f"grants-gov://snapshot/page/{index}"


def iter_retained_pages(scope, *, blob_source):
    """Hand the selected original ZIP to the publisher without a decoded copy."""
    capture = validate_scope(scope)["capture"]
    yield SourceNativeBlobPage(
        0, 0, _key(0), capture["response_sha256"], capture["byte_size"], blob_source, "application/zip"
    )


def _page(index, rows, terminal):
    return {"requestKey": _key(index), "page": index, "results": rows, "terminal": terminal}


def _parse_file(stream, *, query_scope, request_key, evidence_ref, byte_size, media_type):
    scope = validate_scope(query_scope)
    capture = scope["capture"]
    if (request_key, evidence_ref, byte_size, media_type) != (
        _key(0),
        capture["response_sha256"],
        capture["byte_size"],
        "application/zip",
    ):
        raise GrantsGovError("Grants.gov original differs from the selected capture")
    page, rows, size = 0, [], 0
    overhead = len(canonical_json_bytes(_page(page, [], False)))
    with closing(snapshot_records(stream, scope=scope)) as records:
        for record in records:
            record_size = len(canonical_json_bytes(record))
            if rows and (len(rows) == MAX_PAGE_RECORDS or overhead + size + record_size + len(rows) > MAX_PAGE_BYTES):
                yield _page(page, rows, False)
                page, rows, size = page + 1, [], 0
                overhead = len(canonical_json_bytes(_page(page, [], False)))
            if overhead + record_size > MAX_PAGE_BYTES:
                raise GrantsGovError("Grants.gov record exceeds the source page bound")
            rows.append(record)
            size += record_size
    yield _page(page, rows, True)


@dataclass
class _Traversal:
    pages: int = 0
    records: int = 0
    terminal: bool = False

    def add(self, response, *, page_index):
        if self.terminal or response["page"] != page_index or page_index != self.pages:
            raise GrantsGovError("Grants.gov pages are not contiguous")
        for row in response["results"]:
            if row["ordinal"] != self.records:
                raise GrantsGovError("Grants.gov XML record ordering differs")
            self.records += 1
        self.pages += 1
        self.terminal = response["terminal"]

    def finish(self):
        if not self.pages or not self.terminal:
            raise GrantsGovError("Grants.gov export did not finish")


@dataclass
class _Acquisition:
    observed: bool = False

    def add_window(self, response, *, page_window, records_included, response_bytes):
        if self.observed or page_window != 0 or response["page"] != 0 or not records_included:
            raise GrantsGovError("Grants.gov requires one selected original")
        self.observed = True

    def finish(self, *, query_scope):
        if not self.observed:
            raise GrantsGovError("Grants.gov selected original is missing")


def _window(key):
    if not isinstance(key, str) or re.fullmatch(r"grants-gov://snapshot/page/(0|[1-9][0-9]*)", key) is None:
        raise GrantsGovError("Grants.gov page key differs")
    return 0


def _record_scope(record, *, query_scope, page_window):
    capture = query_scope["capture"]
    locator = record["source_locator"]
    if (
        record["snapshot_date"] != query_scope["snapshot_date"]
        or any(locator.get(key) != capture[key] for key in ("request_url", "response_sha256", "observed_at"))
        or locator.get("member_name") != query_scope["member_name"]
        or locator.get("source_xpath") != f"/*[1]/*[{record['ordinal'] + 1}]"
    ):
        raise GrantsGovError("Grants.gov record coordinates differ from its selected source")


def _byte_parser(_raw):
    raise GrantsGovError("Grants.gov requires its captured original stream")


@cache
def _schema_digest():
    return schema_bundle_digest({SCHEMA_KEY: _SCHEMA})


def _records_included(response, **kwargs):
    """An empty snapshot legitimately yields zero records; refuse nothing per page."""
    return True


GRANTS_GOV_PROFILE = SourceNativeProfile(
    name="Retained Grants.gov daily opportunity export",
    source_system_id="https://www.grants.gov/xml-extract.html",
    source_system_version="OpportunityDetail-V1.0",
    acquisition_policy_id="urn:spicy-docs:acquisition:grants-gov-daily-export",
    acquisition_policy_version="1.0",
    scope_id=SCOPE_ID,
    source_schema_key=SCHEMA_KEY,
    source_schema=_SCHEMA,
    record_stem="grants-gov",
    max_traversals=1,
    source_state_scope="observed-crawl",
    traversal_acceptance="single-observed-traversal",
    acquisition_policy=lambda scope: {
        "initialQueryScope": validate_scope(scope),
        "maxPageBytes": MAX_PAGE_BYTES,
        "coverageLimits": [
            "Every synopsis and forecast record in one selected dated XML member; no all-history or deleted-record claim.",
            "Notice type is not current opportunity status; archive/deadline dates and version text remain literal.",
            "A missing later record is unobserved, never inferred withdrawn or deleted.",
            "All field occurrences remain ordered; the original ZIP preserves exact markup, escaping and other members.",
            "The publisher has no declared row count in this XML; full-member completion proves selected-file coverage only.",
        ],
    },
    validate_query_scope=validate_scope,
    parse_page_response=_byte_parser,
    parse_file_stream=_parse_file,
    max_evidence_bytes=MAX_ZIP_BYTES,
    next_page=lambda response, *, seen_urls: None if response["terminal"] else _key(response["page"] + 1),
    traversal_check=_Traversal,
    classify_record=dict,
    wrap_record=lambda row, *, schema_digest: {
        "fieldDiagnostics": [],
        "record": dict(row),
        "schemaDigest": schema_digest,
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
        "scopeId": SCOPE_ID,
        "sourceRecordId": f"grants-gov:{row['notice_type']}:{row['opportunity_id']}",
    },
    record_digest=lambda row: "sha256:" + hashlib.sha256(canonical_json_bytes(dict(row))).hexdigest(),
    rendition_rows=lambda row: (),
    source_schema_digest=_schema_digest,
    source_schema_declaration=lambda: {
        "schemaDigest": _schema_digest(),
        "schemaName": SCHEMA_NAME,
        "schemaVersion": "1.0",
    },
    validate_record_scope=_record_scope,
    records_included=_records_included,
    acquisition_check=_Acquisition,
    page_window=_window,
)

__all__ = ["GRANTS_GOV_PROFILE", "grants_scope", "iter_retained_pages"]
