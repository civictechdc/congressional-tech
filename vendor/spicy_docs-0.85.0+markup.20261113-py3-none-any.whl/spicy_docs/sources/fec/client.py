"""Official FEC raw metadata readers and independently selected asset transfers."""

from __future__ import annotations

import fcntl
import hashlib
import json
import re
from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from functools import cache
from pathlib import Path
from types import SimpleNamespace
from typing import Self
from urllib.parse import parse_qsl, quote, urlencode, urlsplit, urlunsplit

from rulespec_artifacts import LocalBlobWriter

from spicy_docs.reading.refusals import RefusedResponse, attach_refused_response
from spicy_docs.reading.s3_listing import parse_s3_listing
from spicy_docs.sources.fec import metadata
from spicy_docs.sources.fec.assets import validate_original_prefix
from spicy_docs.sources.fec.catalog import (
    API_ROOT,
    BUCKET,
    BUCKET_URL,
    MAX_METADATA_BYTES,
    PREFIXES,
    api_operations,
    official_url,
)
from spicy_docs.sources.fec.metadata import api_page, parse_api, parse_page_links, parse_sitemap, split_record
from spicy_docs.transport.credentials import CredentialRefusedError
from spicy_docs.transport.download import (
    AcquisitionError,
    BoundedAcquirer,
    RateLimit,
    ResponseCapture,
)
from spicy_docs.transport.resume import ResumeError, TraversalCheckpoint, write_json_atomic

# OpenFEC is served through api.data.gov's limiter, which states the key's quota
# as X-RateLimit-Limit requests per rolling minute and answers HTTP 429 with a
# delay-seconds Retry-After of at most one window. Measured 2026-09-25: the
# header read 60, and scheduled spicy-regs runs 36049323173 and 36180816422
# (0.25 s pace) got exactly 60 committee pages per clock minute, then 429.
# Until a response states its limit, pace to the documented standard key
# (1,000 calls/hour, 3.6 s). A wait longer than two windows means a larger
# quota is spent, so acquisition stops rather than sleeping it out; ten
# windows of waiting in all bound a key another client is also spending.
OPENFEC_QUOTA = RateLimit(
    hosts=frozenset({"api.open.fec.gov"}),
    window=60.0,
    fallback_interval=3.6,
    max_wait=120.0,
    wait_budget=600.0,
)


_REPLAYED = "retained-checkpoint"


@contextmanager
def exclusive_run(directory: Path) -> Iterator[Path]:
    """Own one retained FEC attempt directory; a second owner is refused, a dead owner's lock is released."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / ".lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ResumeError("retained FEC attempt is owned by another acquisition") from None
        yield directory


def _require_owner(directory: Path) -> None:
    """Refuse a resume whose caller does not hold exclusive_run(directory)."""
    if not directory.is_dir():
        raise ResumeError("resume_dir must be an existing attempt directory held by exclusive_run")
    with (directory / ".lock").open("a") as probe:
        try:
            fcntl.flock(probe, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return
    raise ResumeError("hold exclusive_run(resume_dir) while resuming an FEC traversal")


@cache
def _reader_sha256() -> str:
    """Code identity of this reader's request, parsing and continuation rules."""
    digest = hashlib.sha256()
    for path in (Path(__file__), Path(metadata.__file__), Path(__file__).with_name("api_operations.json")):
        digest.update(path.read_bytes())
    return "sha256:" + digest.hexdigest()


@dataclass(frozen=True)
class _ApiStep:
    """One validated page in the shape TraversalCheckpoint.track admits."""

    page_index: int
    capture: SimpleNamespace  # requested_url, observed_at
    sha256: str
    next_url: str | None
    declared_count: int | None
    page: dict


def _url(url: str, changes: Mapping) -> str:
    p = urlsplit(url)
    query = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if k not in changes]
    query.extend((k, str(v).lower() if isinstance(v, bool) else v) for k, v in changes.items() if v is not None)
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(query, doseq=True), ""))


def _positive(value: int, label: str) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{label} must be a positive integer")
    return value


class FecClient:
    """Metadata requests never download linked documents, archives or media.

    Every yielded page points to its retained exact response. Iterators are
    bounded by max_pages and fail if a continuation remains at that bound.
    Previously yielded pages remain partial observations when iteration fails;
    only normal iterator exhaustion completes the selected traversal. API
    requests pace to ``OPENFEC_QUOTA`` unless ``rate_limit`` replaces it.
    """

    def __init__(self, *, store: Path, api_key: str | None = None, zyte_on_denial=None, **transport_options) -> None:
        if api_key is not None and (not api_key.strip() or api_key != api_key.strip()):
            raise ValueError("FEC API key must be nonempty without surrounding whitespace")
        self.store = Path(store)
        self._writer = LocalBlobWriter(self.store)
        self._key = api_key
        transport_options.setdefault("rate_limit", OPENFEC_QUOTA)
        self.http = BoundedAcquirer(
            validate_url=official_url,
            zyte_on_denial=zyte_on_denial,
            public_fallback_url=lambda url: urlsplit(url).hostname != "api.open.fec.gov",
            headers=lambda url: (
                {"X-Api-Key": self._key} if self._key and urlsplit(url).hostname == "api.open.fec.gov" else {}
            ),
            **transport_options,
        )

    def __enter__(self) -> Self:
        self.http.__enter__()
        return self

    def __exit__(self, *error: object) -> None:
        self.http.__exit__(*error)

    def _capture(self, url: str) -> ResponseCapture:
        result = self.http.capture(url, max_bytes=MAX_METADATA_BYTES)
        if self._key and self._key.encode() in result.body:
            raise CredentialRefusedError("source response echoed the API credential; capture was not retained")
        return result

    def _page(
        self, capture: ResponseCapture, *, records: list[tuple[str, object]], continuation: str | None, **context
    ) -> dict:
        stored = self._writer.put([capture.body], max_bytes=MAX_METADATA_BYTES, expected_digest=capture.sha256)
        return {
            "source": "fec",
            "request_url": capture.url,
            "resolved_url": capture.resolved_url,
            "observed_at": capture.observed_at,
            "media_type": capture.media_type,
            "via": capture.via,
            "evidence": {"sha256": stored.digest, "bytes": stored.byte_size, "blob_path": stored.object_key},
            "records": [split_record(value, source_pointer=path) for path, value in records],
            "next_url": continuation,
            "scope": "observed source traversal; no frozen publisher snapshot",
            **context,
        }

    def _parsed(self, capture: ResponseCapture, parser, **kwargs):
        try:
            return parser(capture.body, **kwargs)
        except (ValueError, SyntaxError) as error:
            attach_refused_response(
                error, RefusedResponse(capture.url, "source-validation", capture.body, capture.media_type)
            )
            raise

    def _api_mode(self, path: str) -> str | list[str]:
        operations = api_operations()
        modes = (
            [operations[path]]
            if path in operations
            else [
                mode
                for template, mode in operations.items()
                if re.fullmatch(re.sub(r"\\\{[^}]+\\\}", r"[^/?]+", re.escape(template)), path)
            ]
        )
        if len(modes) != 1:
            raise ValueError("path is not a supported official OpenFEC GET operation")
        if modes[0] == "asset":
            raise ValueError("calendar export returns CSV/ICS; use download with an explicit byte bound")
        return modes[0]

    def _retained(self, url: str, pinned: dict) -> ResponseCapture:
        """Re-admit one committed page from this client's own store; no request, pacing or budget."""
        if url != pinned["url"]:
            raise ResumeError("reader request differs from retained prefix")
        path = self.store / "sha256" / pinned["sha256"].removeprefix("sha256:")
        if path.is_symlink() or not path.is_file():
            raise ResumeError("retained page bytes are missing from the store")
        if path.stat().st_size > MAX_METADATA_BYTES:
            raise ResumeError("retained page exceeds the metadata byte bound")
        capture = ResponseCapture(url, url, "application/json", pinned["observed_at"], path.read_bytes(), _REPLAYED)
        if capture.sha256 != pinned["sha256"]:
            raise ResumeError("retained page bytes changed")
        return capture

    def _api_pages(
        self, url: str, mode: str | list[str], max_pages: int, *, retained: list[dict]
    ) -> Iterator[_ApiStep]:
        seen = set()
        for index in range(max_pages):
            if url in seen:
                raise AcquisitionError("FEC API repeated its continuation")
            seen.add(url)
            replayed = index < len(retained)
            capture = self._retained(url, retained[index]) if replayed else self._capture(url)
            value = self._parsed(capture, parse_api)
            try:
                records, changes, context = api_page(value, url=url, mode=mode)
                if "api_version" in value:
                    context["api_version"] = value["api_version"]
            except ValueError as error:
                attach_refused_response(
                    error, RefusedResponse(url, "source-validation", capture.body, capture.media_type)
                )
                raise
            next_url = _url(url, changes) if changes is not None else None
            if next_url is not None:
                official_url(next_url)
            page = self._page(capture, records=records, continuation=next_url, **context)
            if replayed:
                # The checkpoint keeps neither the resolved URL nor the media type of a committed page.
                page.update(resolved_url=None, media_type=None)
            pagination = context.get("pagination") or {}
            declared = pagination.get("count") if pagination.get("is_count_exact") is True else None
            yield _ApiStep(
                index,
                SimpleNamespace(requested_url=url, observed_at=capture.observed_at),
                capture.sha256,
                next_url,
                declared,
                page,
            )
            if next_url is None:
                return
            url = next_url
        raise AcquisitionError("FEC API page bound reached before a terminal response")

    def _checkpoint(self, directory: Path, first_url: str, max_pages: int) -> TraversalCheckpoint:
        _require_owner(directory)
        selection = {
            "format": "fec-api-traversal-v1",
            "first_url": first_url,
            "max_pages": max_pages,
            "reader_sha256": _reader_sha256(),
        }
        pin = (
            "sha256:"
            + hashlib.sha256(json.dumps(selection, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        )
        if not (directory / "checkpoint.json").exists():
            # The readable manifest lands first and whole, so no checkpoint ever lacks it (as RetainedGetTraversal does).
            write_json_atomic(directory / "selection.json", selection)
        return TraversalCheckpoint(directory / "checkpoint.json", selection_sha256=pin, first_url=first_url)

    def api(
        self, path: str, *, params: Mapping | None = None, max_pages: int = 100, resume_dir: Path | None = None
    ) -> Iterator[dict]:
        """Read documented GET operations; use bulk for transaction backfills.

        API credentials use X-Api-Key and never enter request URLs. Pass all
        source filters explicitly: this reader does not silently select current
        reports or exclude amendments. API numeric decimals remain Decimal.

        ``resume_dir`` keeps a ``TraversalCheckpoint`` in an attempt directory
        the caller owns with ``exclusive_run``; ``api`` refuses a caller that
        does not hold it. Rerun with the same ``store`` and arguments: committed
        pages replay from that store through the unchanged parser and
        continuation rules, with no request, pacing or budget. A replayed page
        keeps its first ``observed_at`` and reports ``via`` ``retained-checkpoint``
        with no resolved URL or media type, which the checkpoint does not retain.
        A changed query, ``max_pages``, reader code, declared exact count, page
        bytes or a second owner refuses; 401/403 stay terminal and are recorded
        beside the pending URL. Only normal exhaustion completes the checkpoint,
        and complete means an observed traversal, not a frozen population.
        """
        _positive(max_pages, "max_pages")
        if not self._key:
            raise ValueError("OpenFEC acquisition requires an explicit API key")
        mode = self._api_mode(path)
        url = official_url(_url(API_ROOT + path, params or {}))
        if resume_dir is None:
            for step in self._api_pages(url, mode, max_pages, retained=[]):
                yield step.page
            return
        progress = self._checkpoint(Path(resume_dir), url, max_pages)
        steps = self._api_pages(url, mode, max_pages, retained=list(progress.state["pages"]))
        # _page already stored each page durably before its step is yielded, so retain_capture has nothing to do.
        for step in progress.track(steps, retain_capture=lambda _capture: None, api_keys=(self._key,)):
            yield step.page

    def objects(self, prefix: str, *, max_pages: int = 1000, page_size: int = 1000) -> Iterator[dict]:
        """Enumerate metadata only under a published bulk/legal/export prefix."""
        _positive(max_pages, "max_pages")
        if not isinstance(prefix, str) or not prefix.startswith(PREFIXES):
            raise ValueError("FEC prefix must be under bulk-downloads/, legal/ or user-downloads/")
        if type(page_size) is not int or not 1 <= page_size <= 1000:
            raise ValueError("S3 page_size must be between 1 and 1000")
        token = None
        seen_tokens = set()
        previous_key = None
        for _ in range(max_pages):
            url = _url(
                BUCKET_URL, {"list-type": 2, "prefix": prefix, "max-keys": page_size, "continuation-token": token}
            )
            capture = self._capture(url)
            objects, token = self._parsed(capture, parse_s3_listing, bucket=BUCKET, prefix=prefix)
            rows = []
            for obj in objects:
                if previous_key is not None and obj.key <= previous_key:
                    raise AcquisitionError("FEC S3 listing keys repeated or ceased increasing")
                previous_key = obj.key
                rows.append(
                    (
                        None,
                        {
                            **asdict(obj),
                            "url": official_url(BUCKET_URL + quote(obj.key, safe="/")),
                            "fec_url": "https://www.fec.gov/files/" + quote(obj.key, safe="/"),
                        },
                    )
                )
            if token is not None and (not objects or token in seen_tokens):
                raise AcquisitionError("FEC S3 listing did not advance")
            seen_tokens.add(token)
            next_url = _url(url, {"continuation-token": token}) if token else None
            yield self._page(
                capture, records=rows, continuation=next_url, prefix=prefix, record_coordinates="S3 Key in retained XML"
            )
            if token is None:
                return
        raise AcquisitionError("FEC S3 page bound reached before IsTruncated=false")

    def sitemap(self, url: str, *, max_pages: int = 100) -> Iterator[dict]:
        """Follow only XML child indexes; leaf pages and documents stay unrequested."""
        _positive(max_pages, "max_pages")
        pending, seen = [official_url(url)], set()
        scheduled = set(pending)
        while pending:
            current = pending.pop()
            if current in seen:
                continue
            if len(seen) >= max_pages:
                raise AcquisitionError("FEC sitemap page bound exhausted")
            seen.add(current)
            capture = self._capture(current)
            kind, rows = self._parsed(capture, parse_sitemap)
            if kind == "sitemapindex":
                for row in reversed(rows):
                    child = official_url(row["url"])
                    if child not in scheduled:
                        scheduled.add(child)
                        pending.append(child)
            yield self._page(
                capture,
                records=[(None, x) for x in rows],
                continuation=pending[-1] if pending else None,
                kind=kind,
                record_coordinates="loc in retained sitemap XML",
            )

    def page_links(self, url: str) -> dict:
        """Explicit HTML/XHTML discovery fallback for official collection pages."""
        if urlsplit(url).hostname not in {"www.fec.gov", "fec.gov", "transition.fec.gov"}:
            raise ValueError("collection page discovery requires an FEC website URL")
        capture = self._capture(url)
        value = self._parsed(capture, parse_page_links, url=capture.resolved_url)
        return self._page(
            capture,
            records=[(None, value)],
            continuation=None,
            record_coordinates="link labels/hrefs in retained page",
            discovery_only=True,
        )

    def download(self, url: str, *, max_bytes: int, **options) -> dict:
        """Download one caller-selected original; never infer alternate URLs."""
        if urlsplit(url).hostname == "api.open.fec.gov" and not self._key:
            raise ValueError("OpenFEC acquisition requires an explicit API key")
        options.setdefault("validate_prefix", lambda chunk: validate_original_prefix(chunk, url=url))
        return self.http.download(url, store=self.store, max_bytes=max_bytes, **options)
