"""Native content occurrences in an explicitly dated eCFR response."""

from __future__ import annotations

import hashlib
from dataclasses import asdict

from spicy_docs.reading.xml import scan_xml

from .ecfr import validate_ecfr_xml
from .models import MAX_CFR_BYTES, CfrSourceError, EcfrSelection


def read_ecfr_snapshot(
    body: bytes, *, selection: EcfrSelection, final_url: str, max_bytes: int = MAX_CFR_BYTES, max_nodes: int = 100_000
) -> tuple[dict, list[dict]]:
    """Keep requested date separate from native amendment/currency fields.

    SECTION/APPENDIX rows follow native XML elements. Position counts XML
    element children, including non-content siblings. Text is decoded native
    descendant text, with no OCR, legal interpretation or inferred section ids.
    A complete read precedes returning any rows; original bytes retain markup.
    """
    if type(max_nodes) is not int or not 1 <= max_nodes <= 1_000_000:
        raise CfrSourceError("max_nodes must be within 1..1000000")
    facts = asdict(validate_ecfr_xml(body, selection=selection, final_url=final_url, max_bytes=max_bytes))
    digest = "sha256:" + hashlib.sha256(body).hexdigest()
    snapshot = {
        "title": selection.title,
        "snapshot_date": selection.date,
        "selected_part": selection.part,
        "selected_section": selection.section,
        "source_url": final_url,
        "source_sha256": digest,
        "source_bytes": len(body),
        "native_metadata": facts,
    }
    stack, rows, active = [], [], []

    def position():
        return 0

    def bind(reader):
        nonlocal position
        position = reader

    def start(tag, attributes):
        path = (1,)
        if stack:
            stack[-1]["children"] += 1
            path = (*stack[-1]["path"], stack[-1]["children"])
        frame = {"tag": tag, "attributes": attributes, "path": path, "children": 0}
        stack.append(frame)
        if attributes.get("TYPE") in {"SECTION", "APPENDIX"}:
            if len(rows) + len(active) >= max_nodes:
                raise CfrSourceError("eCFR snapshot exceeds content occurrence bound")
            part = next(
                (f["attributes"].get("N") for f in reversed(stack[:-1]) if f["attributes"].get("TYPE") == "PART"),
                selection.part,
            )
            active.append(
                {
                    "xml_position": "/".join(map(str, path)),
                    "byte_start": position(),
                    "kind": attributes["TYPE"],
                    "native_number": attributes.get("N"),
                    "part": part,
                    "attributes": dict(attributes),
                    "text": [],
                    "heading": [],
                    "depth": len(stack),
                }
            )

    def data(text):
        for item in active:
            item["text"].append(text)
            if len(stack) > item["depth"] and stack[item["depth"]]["tag"] == "HEAD":
                item["heading"].append(text)

    def end(_tag):
        if active and active[-1]["depth"] == len(stack):
            item = active.pop()
            item.pop("depth")
            item["text"] = "".join(item["text"])
            item["heading"] = "".join(item["heading"]) or None
            rows.append(item)
        stack.pop()

    scan_xml(
        body,
        start=start,
        end=end,
        data=data,
        byte_index=bind,
        max_bytes=max_bytes,
        error_type=CfrSourceError,
        label="eCFR snapshot",
        max_depth=256,
    )
    rows.sort(key=lambda row: row["byte_start"])
    snapshot["content_nodes"] = len(rows)
    return snapshot, rows
