"""Bounded decoding of CourtListener's PostgreSQL CSV exports.

The bulk exports use UTF-8, HEADER, ESCAPE '\\', and FORCE_QUOTE *:
https://github.com/freelawproject/courtlistener/blob/main/scripts/make_bulk_data.sh
The one-off ``randoms/bankruptcy-dockets-2022-09-19.csv.bz2`` export is not made by that script and
uses PostgreSQL's CSV defaults instead: ESCAPE '"' (a quote inside a value is doubled, a backslash is
an ordinary character) and values quoted only where needed. Callers name the ESCAPE they read;
nothing is sniffed. ``CourtListenerLocalDump`` reads that export; ``CourtListenerBulkReader``
addresses the bulk exports by dataset and date, so it reads only their backslash dialect. In both, unquoted empty fields are NULL and quoted empty fields are empty
strings. Python 3.12's csv.QUOTE_NOTNULL reader does not preserve that distinction.
"""

from __future__ import annotations

import codecs
import io
import re
from collections.abc import Callable, Iterator
from typing import BinaryIO, Literal

#: PostgreSQL's CSV ESCAPE option: the bulk exports' backslash, or the default, a doubled quote.
Escape = Literal["\\", '"']

MAX_RECORD_CHARACTERS = 64 * 1024 * 1024
MAX_COLUMNS = 1024
_TEXT_CHUNK = 64 * 1024
_UNQUOTED_RUN = re.compile(r'[^,"\r\n]+')
#: A quoted run takes escape pairs with it. Opinion HTML escapes every attribute quote (``\\"``);
#: ending the run at each backslash sent each pair through the per-character loop below, 73% of a
#: pass over the 2026-06-30 opinions export (profiled 2026-09-22). A backslash that ends a chunk
#: still goes through that loop, which resolves the pair once the next chunk arrives.
_QUOTED_RUN = re.compile(r'(?:[^"\\]+|\\[\s\S])+')
#: Inside quotes only a quote or a backslash is escaped; any other backslash is literal, as in the loop.
_QUOTED_ESCAPE = re.compile(r'\\(["\\])')
#: With ESCAPE '"' a quoted run stops only at a quote; a backslash is text.
_DOUBLED_RUN = re.compile(r'[^"]+')


class CourtListenerCsvError(ValueError):
    """The source CSV cannot be decoded faithfully within its limits."""


def validate_record_limit(value: int) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("max_record_characters must be a positive integer")


def validate_escape(value: object) -> None:
    if value not in ("\\", '"'):
        raise ValueError("escape must be a backslash or a double quote (PostgreSQL's CSV ESCAPE)")


def iter_postgres_csv(
    stream: BinaryIO,
    *,
    max_record_characters: int = MAX_RECORD_CHARACTERS,
    escape: Escape = "\\",
    is_truncated: Callable[[], bool] = lambda: False,
) -> Iterator[list[str | None]]:
    """Decode one record at a time, counting the header as record 1.

    The record limit includes CSV quoting and delimiters, but excludes its line
    ending. A deliberate compressed-byte cutoff discards the unfinished record.
    With ``escape="\\"`` backslashes only escape quotes/backslashes inside quoted
    fields and are literal otherwise; with ``escape='"'`` a doubled quote inside
    quotes is one quote and backslashes are always literal. The caller names the
    dialect; there is no auto-detection.
    """
    validate_record_limit(max_record_characters)
    validate_escape(escape)
    doubled = escape == '"'
    quoted_run = _DOUBLED_RUN if doubled else _QUOTED_RUN
    decoder = codecs.getincrementaldecoder("utf-8")("strict")
    state = "start"
    field = io.StringIO()
    fields: list[str | None] = []
    record_number = 1
    record_characters = 0
    skip_lf = False

    def error(reason: str) -> CourtListenerCsvError:
        return CourtListenerCsvError(f"CourtListener CSV record {record_number}: {reason}")

    def count(size: int) -> None:
        nonlocal record_characters
        record_characters += size
        if record_characters > max_record_characters:
            raise error(f"exceeds {max_record_characters} characters")

    def finish_field() -> None:
        if len(fields) >= MAX_COLUMNS:
            raise error(f"exceeds {MAX_COLUMNS} columns")
        fields.append(None if state == "start" else field.getvalue())
        field.seek(0)
        field.truncate(0)

    while True:
        encoded = stream.read(_TEXT_CHUNK)
        invalid_utf8 = False
        try:
            chunk = decoder.decode(encoded, final=not encoded and not is_truncated())
        except UnicodeDecodeError as exc:
            # Process the valid prefix first so the error names its actual CSV
            # record, even when a single input block contains many records.
            chunk = exc.object[: exc.start].decode("utf-8")
            invalid_utf8 = True
        position = 0
        while position < len(chunk):
            char = chunk[position]
            if skip_lf:
                skip_lf = False
                if char == "\n":
                    position += 1
                    continue
            if state in {"start", "unquoted", "quoted"}:
                pattern = quoted_run if state == "quoted" else _UNQUOTED_RUN
                if match := pattern.match(chunk, position):
                    value = match.group()
                    count(len(value))
                    if state == "quoted" and not doubled and "\\" in value:
                        value = _QUOTED_ESCAPE.sub(r"\1", value)
                    field.write(value)
                    if state == "start":
                        state = "unquoted"
                    position = match.end()
                    continue
            position += 1
            if state == "escaped":
                count(1)
                field.write(char if char in {'"', "\\"} else "\\" + char)
                state = "quoted"
            elif state == "quoted":
                count(1)
                state = "escaped" if char == "\\" else "closed"
            elif char in "\r\n":
                finish_field()
                yield fields
                fields = []
                state = "start"
                record_number += 1
                record_characters = 0
                skip_lf = char == "\r"
            elif char == ",":
                count(1)
                finish_field()
                state = "start"
            elif char == '"' and state == "start":
                count(1)
                state = "quoted"
            elif char == '"' and state == "closed" and doubled:
                # The second quote of a doubled pair, possibly at the start of the next chunk.
                count(1)
                field.write('"')
                state = "quoted"
            else:
                raise error(
                    "unexpected character after a closing quote" if state == "closed" else "quote in unquoted field"
                )
        if invalid_utf8:
            raise error("invalid UTF-8") from None
        if not encoded:
            break

    if is_truncated():
        return
    if state in {"quoted", "escaped"}:
        raise error("unterminated quoted field")
    if record_characters:
        finish_field()
        yield fields
