"""CourtListener opinion bodies as Markdown with inline citation links, one deterministic lxml walk per opinion.

Dialect: GFM plus footnotes (owner, 2026-10-31): CommonMark, GFM pipe tables (the one GFM extension written) and
reference-style footnotes (``[^label]`` and ``[^label]: body``), as marko reads it with its ``gfm`` and ``footnote``
extensions. A plain CommonMark reader takes a footnote definition for a link reference definition: on 2026-10-30,
markdown-it's CommonMark preset found 1,677 fewer citation pairs than marko in the same 362,517
(``work/court-text-measure-20261030/markdown/roundtrip.json``). So consumers must be told the dialect;
``docs/sources/courtlistener-opinion-markdown.md`` states it.

A ``<span class="citation" data-id="N">`` becomes ``[text](opinion:N)``; one without a numeric ``data-id`` becomes
``[text](cite:<path>)`` with the ``/c/`` lookup path its link carries, else bare ``cite:``. Every source backtick is
written as ``&#96;`` because marko opens a code span at an escaped backtick (CommonMark forbids that), and a line start
that CommonMark would read as a block marker is escaped. Images and scripts are dropped. Preformatted text keeps its
lines and indentation (:func:`_paragraph`); emphasis a reader could not close where it stands loses its delimiters
rather than printing them (``_Converter._flanks``).

:func:`select_source` applies the publisher's renderings in a fixed order: ``html_with_citations``, else ``html``,
else ``plain_text`` (escaped as text, not parsed as HTML), else nothing. The full 2026-06-30 export has 17,885 rows
without ``html_with_citations``: 9,355 fall back to ``html``, 7,976 to ``plain_text`` and 554 have no text at all.

The output is a function of the input bytes, this module and the lxml/libxml2 build; :func:`converter_identity` names
all three for a host's receipts. ``OPINION_MARKDOWN_VERSION`` moves when the Markdown an opinion converts to can
change; ``tests/test_opinion_markdown.py`` pins it together with the module's code digest.

Measured against the reference converter this module was ported from
(``work/court-text-measure-20261030/markdown/md_measure.py``): the emphasis/citation block test is one post-order
pass rather than a descendant scan per inline element (O(n) rather than O(n * depth)) and the footnote-mark queues
are deques. The walk is recursive; the deepest of the first 100,000 opinions in the export nests 58 elements, far
inside Python's default limit, and a deeper document raises :class:`OpinionMarkdownError` rather than changing the
process's recursion limit. Nested blockquotes re-prefix their inner text once per level (O(n * quote depth)).
"""

from __future__ import annotations

import re
import unicodedata
from collections import defaultdict, deque
from typing import NamedTuple
from urllib.parse import quote

import lxml.etree
import lxml.html

#: Moves when the Markdown an opinion converts to can change; see the module docstring.
OPINION_MARKDOWN_VERSION = "001"
#: The rendering columns :func:`select_source` reads, in the order it prefers them.
SOURCE_COLUMNS = ("html_with_citations", "html", "plain_text")
#: ``text_source`` of a row none of :data:`SOURCE_COLUMNS` fills.
NO_TEXT = "none"

_PARSER = lxml.html.HTMLParser(encoding="utf-8", remove_comments=True, remove_pis=True, huge_tree=True)
_SENTINEL = "\x00"  # marks each citation link's "[" until offsets are taken; libxml2 never returns NUL
_WS = re.compile(r"\s+")
_SPACES = re.compile(r"[ \t]{2,}")
_BLANK = re.compile("\n(?:[ \t\u00a0]*\n)+")  # a no-break space on a line leaves it blank; the next
# line's indentation stays with it
_ESC = re.compile(r"([\\*_\[\]<~])")
_ENTITY = re.compile(r"&(?=#?\w+;)")
_ORDINAL = re.compile(r"\d{1,9}(?=[.)])")
_CITE = re.compile(r"citation\b")
_FN_ID = re.compile(r"(fn|footnote)(?!r_)(?!.*ref)", re.IGNORECASE)
_HEADINGS = {"h1": 1, "h2": 2, "h3": 3, "h4": 4, "h5": 5, "h6": 6, "h": 3}
#: Harvard ``<emphasis typestyle=...>`` and HTML emphasis tags, by Markdown delimiter.
_STYLE = {"it": "*", "iu": "*", "bf": "**", "bu": "**"}
_DELIM = {"em": "*", "i": "*", "strong": "**", "b": "**"}
_SKIP = frozenset(["script", "style", "head", "title", "meta", "link", "colspec", "img"])
#: Elements that break a paragraph: HTML blocks plus the Harvard/Columbia/Lawbox structural tags.
BLOCKS = frozenset(
    [
        "p",
        "div",
        "blockquote",
        "li",
        "ul",
        "ol",
        "tr",
        "table",
        "thead",
        "tbody",
        "tfoot",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "hr",
        "opinion",
        "author",
        "footnote",
        "footnotes",
        "center",
        "dd",
        "dt",
        "dl",
        "section",
        "article",
        "header",
        "footer",
        "headnotes",
        "summary",
        "syllabus",
        "attorneys",
        "parties",
        "docketnumber",
        "court",
        "decisiondate",
        "otherdate",
        "judges",
        "disposition",
        "casebody",
        "pre",
        "h",
        "bodytext",
        "footnote_body",
        "th",
        "td",
        "caption",
    ]
)

Cite = tuple[int, str, int | None]


class OpinionMarkdownError(ValueError):
    """An opinion rendering this converter cannot turn into Markdown; a host records it as a refusal."""


class OpinionText(NamedTuple):
    """One opinion's Markdown, the rendering column it came from, and its citation links.

    ``cites`` holds, per link in document order, the offset in ``markdown`` of the character after its ``[``, the
    cited text and the cited opinion id (None for a ``cite:`` link).
    """

    markdown: str
    text_source: str
    cites: tuple[Cite, ...]


def esc(text: str) -> str:
    """Escape inline Markdown syntax; a backtick becomes ``&#96;`` (see the module docstring)."""
    return _ENTITY.sub(r"\\&", _ESC.sub(r"\\\1", text)).replace("`", "&#96;")


def esc_line(line: str) -> str:
    """Neutralise a line start that CommonMark would read as a block marker (list, heading, quote, rule, table)."""
    if line[0] in "-+=#>|":
        return "\\" + line
    m = _ORDINAL.match(line)
    return line[: m.end()] + "\\" + line[m.end() :] if m else line


#: A laid-out line's first space or tab as a character reference, so CommonMark keeps the indentation it would strip.
_INDENT = {" ": "&#32;", "\t": "&#9;"}
#: Line-start controls a reader would not keep as indentation (a form feed marks a page in ``<pre>`` renderings).
_PAGE_CONTROLS = dict.fromkeys(map(ord, "\x0b\x0c\x1c\x1d\x1e\x1f\x85\u2028\u2029"))


def _layout_line(line: str) -> str:
    """One line of preformatted text, indentation kept (see :func:`_paragraph`)."""
    text = line.lstrip()
    indent = line[: len(line) - len(text)].translate(_PAGE_CONTROLS)
    if not indent:
        return esc_line(text)
    return _INDENT.get(indent[0], indent[0]) + indent[1:] + text


def _paragraph(text: str, layout: bool) -> str:
    """One paragraph's escaped lines as Markdown; empty when no line holds text.

    Flowing text (``layout`` false) collapses runs of spaces and joins its lines with soft breaks. Preformatted text
    (a ``<pre>`` rendering, or ``plain_text``) keeps its line structure: each line ends in a hard break (``\\``) and
    keeps its leading whitespace, the first space written as ``&#32;`` so a CommonMark reader neither strips the
    indentation nor reads four spaces as a code block (a fenced block would turn the citation links into text).
    """
    if layout:
        lines = [_layout_line(line) for line in (raw.rstrip() for raw in text.split("\n")) if line.strip()]
        return "\\\n".join(lines)
    lines = [esc_line(line) for line in (_SPACES.sub(" ", raw.strip()) for raw in text.split("\n")) if line]
    return "\n".join(lines)


def _delimiter_class(char: str) -> str:
    """CommonMark's flanking class of one character: ``space`` (or a line edge), ``punct`` or ``other``."""
    if not char or char.isspace() or unicodedata.category(char) == "Zs":
        return "space"
    return "punct" if unicodedata.category(char)[0] in "PS" else "other"


def _prefixed(text: str, first: str, rest: str) -> str:
    lines = text.split("\n")
    return "\n".join([first + lines[0]] + [(rest + line) if line else rest.rstrip() for line in lines[1:]])


def _block_holders(root) -> frozenset:
    """Every element with a block-level descendant, in one pass: each block marks its ancestors up to the first
    already marked one, so every element is marked at most once."""
    held: set = set()
    for el in root.iter():
        if isinstance(el.tag, str) and el.tag in BLOCKS:
            for ancestor in el.iterancestors():
                if ancestor in held:
                    break
                held.add(ancestor)
    return frozenset(held)


class _Converter:
    def __init__(self, doc: str):
        try:
            self.root = lxml.html.document_fromstring(doc.encode("utf-8", "replace"), parser=_PARSER)
        except lxml.etree.ParserError as error:
            raise OpinionMarkdownError(f"unparseable rendering: {error}") from error
        self.has_block = _block_holders(self.root)
        self.label: dict = {}  # footnote body element -> Markdown label (referenced bodies only)
        self.marker: dict = {}  # marker element -> body element
        self.used: set[str] = set()
        self.cites: list[tuple[str, int | None]] = []
        self.blocks: list[str] = []
        self.buf: list[str] = []
        self.buf_pre = False
        self.pre = self.inline_only = self.link = self.in_body = 0
        self.emph: set[str] = set()
        self.last_emph: tuple | None = None  # (buffer, its length, delimiter) right after a closed run
        self._footnotes()

    # -- footnotes: markers resolve by id (href="#x", anchoridref) or, for Harvard <footnotemark>, by label order
    def _footnotes(self) -> None:
        ids = {}
        for el in self.root.iter():
            if isinstance(el.tag, str):
                for key in (el.get("id"), el.get("name")):
                    if key and key not in ids:
                        ids[key] = el

        def body_for(target):
            e = target
            while e is not None:
                if e.tag in ("footnote", "footnote_body"):
                    return e
                if e.tag in ("div", "li", "p", "section", "aside") and (
                    _FN_ID.match(e.get("id") or "") or "footnote" in (e.get("class") or "").split()
                ):
                    return e
                e = e.getparent()
            return None

        pending: defaultdict[str, deque] = defaultdict(deque)
        for fn in self.root.iter("footnote"):
            if fn.get("label"):
                pending[_WS.sub("", fn.get("label"))].append(fn)
        claimed = {}  # label -> last body a <footnotemark> claimed; a repeated mark reuses it
        for el in self.root.iter("a", "footnotereference", "footnotemark"):
            body = None
            if el.tag == "footnotemark":
                key = _WS.sub("", el.text_content())
                queue = pending.get(key)
                while queue and body is None:
                    cand = queue.popleft()
                    body = cand if cand not in self.label else None
                body = body if body is not None else claimed.get(key)
                if body is not None:
                    claimed[key] = body
            else:
                ref = (el.get("href") or "") if el.tag == "a" else "#" + (el.get("anchoridref") or "")
                if ref.startswith("#") and len(ref) > 1 and ref[1:] in ids:
                    body = body_for(ids[ref[1:]])
                if body is not None and any(a is body for a in el.iterancestors()):
                    body = None  # a link inside its own footnote is a back-reference
            if body is None:
                continue
            self.marker[el] = body
            if body not in self.label:
                text = re.sub(r"[^0-9A-Za-z]", "", el.text_content()) or f"fn{len(self.label) + 1}"
                label, k = text, 1
                while label.casefold() in self.used:
                    k += 1
                    label = f"{text}-{k}"
                self.used.add(label.casefold())
                self.label[body] = label

    # -- buffers
    def text(self, s: str) -> None:
        if self.pre:
            s = s.replace("\r\n", "\n").replace("\r", "\n")
            self.buf_pre = True
        else:
            s = _WS.sub(" ", s)
        if s:
            self.buf.append(esc(s))

    def flush(self) -> None:
        if not self.buf:
            return
        s, pre = "".join(self.buf), self.buf_pre
        self.buf, self.buf_pre = [], False
        self.blocks.extend(block for block in (_paragraph(para, pre) for para in _BLANK.split(s)) if block)

    def capture(self, el) -> str:
        saved, self.buf = self.buf, []
        self.children(el)
        out, self.buf = "".join(self.buf), saved
        return out

    def sub_blocks(self, el) -> list[str]:
        self.flush()
        saved, self.blocks = self.blocks, []
        self.children(el)
        self.flush()
        out, self.blocks = self.blocks, saved
        return out

    # -- walk
    def children(self, el) -> None:
        if el.text:
            self.text(el.text)
        for child in el:
            self.node(child)
            if child.tail:
                self.text(child.tail)

    def node(self, el) -> None:
        tag = el.tag
        if not isinstance(tag, str) or tag in _SKIP or el in self.label:
            return
        if el in self.marker:
            self.buf.append(f"[^{self.label[self.marker[el]]}]")
            return
        if tag == "span" and _CITE.match(el.get("class") or ""):
            return self.citation(el)
        if tag == "a":
            return self.anchor(el)
        delim = _delimiter(el)
        if delim:
            return self.emphasis(el, delim)
        if tag == "br":
            self.buf.append(" " if self.inline_only else "\n")
            return
        if tag == "pre":
            inline = "inline" in (el.get("class") or "").split() or self.inline_only
            if not inline:
                self.flush()
            self.pre += 1
            self.children(el)
            self.pre -= 1
            if not inline:
                self.flush()
            return
        if self.inline_only:  # heading text or a table cell: blocks become spaces
            if tag in BLOCKS:
                self.buf.append(" ")
            self.children(el)
            if tag in BLOCKS:
                self.buf.append(" ")
            return
        if tag in _HEADINGS:
            return self.heading(el, _HEADINGS[tag])
        if tag == "blockquote":
            inner = self.sub_blocks(el)
            if inner:
                self.blocks.append(_prefixed("\n\n".join(inner), "> ", "> "))
            return
        if tag in ("ul", "ol"):
            return self.listing(el, tag == "ol")
        if tag == "table":
            return self.table(el)
        if tag == "hr":
            self.flush()
            self.blocks.append("---")
            return
        if tag in BLOCKS:
            self.flush()
            self.children(el)
            self.flush()
            return
        self.children(el)

    def _wrapped(self, el) -> tuple[str, str, str]:
        """``el``'s inline text split into leading space, core and trailing space, captured inside a link."""
        self.link += 1
        inner = _BLANK.sub("\n", self.capture(el))
        self.link -= 1
        core = inner.strip()
        return inner[: len(inner) - len(inner.lstrip())], core, inner[len(inner.rstrip()) :] if core else ""

    def citation(self, el) -> None:
        if self.link or el in self.has_block:
            return self.children(el)
        data_id = el.get("data-id") or ""
        if data_id.isdigit():
            dest, target = f"opinion:{data_id}", int(data_id)
        else:
            a = el.find(".//a[@href]")
            href = a.get("href") if a is not None else ""
            path = href[3:].strip("/") if href.startswith("/c/") else ""
            dest, target = "cite:" + quote(path, safe="/.,:-_~%"), None
        lead, core, trail = self._wrapped(el)
        if not core:
            self.buf.append(lead)
            return
        self.buf.append(f"{lead}{_SENTINEL}[{core}]({dest}){trail}")
        self.cites.append((_WS.sub(" ", el.text_content()).strip(), target))

    def anchor(self, el) -> None:
        href = el.get("href") or ""
        if href.startswith("#") and self.in_body:
            return  # back-reference inside a rendered footnote body
        if href.startswith(("http://", "https://")) and not self.link and el not in self.has_block:
            lead, core, trail = self._wrapped(el)
            if core:
                self.buf.append(f"{lead}[{core}]({quote(href, safe='/:?#&=%.,-_~+;@!$')}){trail}")
            return
        self.children(el)

    def emphasis(self, el, delim: str) -> None:
        if delim in self.emph or el in self.has_block:
            return self.children(el)
        self.emph.add(delim)
        inner = _BLANK.sub("\n", self.capture(el))
        self.emph.discard(delim)
        core = inner.strip()
        if not core:
            self.buf.append(inner)
            return
        lead, trail = inner[: len(inner) - len(inner.lstrip())], inner[len(inner.rstrip()) :]
        if not self._flanks(core, lead, trail, el):
            self.buf.append(inner)  # delimiters a reader would print as literal asterisks: keep the text, drop them
            self.last_emph = None
            return
        last = self.last_emph
        if not lead and last and last[0] is self.buf and last[1:] == (len(self.buf), delim):
            self.buf[-1] = self.buf[-1][: -len(delim)]  # <em>a</em><em>b</em>: one run
            self.buf.append(f"{core}{delim}{trail}")
        else:
            self.buf.append(f"{lead}{delim}{core}{delim}{trail}")
        self.last_emph = (self.buf, len(self.buf), delim) if not trail else None

    def _flanks(self, core: str, lead: str, trail: str, el) -> bool:
        """Whether ``*`` delimiters around ``core`` open and close in CommonMark, which requires a delimiter between a
        punctuation character and a letter or digit to sit on the punctuation's outer side: ``*A.*2d`` stays literal
        text. The character before is the last one written; the one after comes from the source."""
        before = "" if lead else next((part[-1] for part in reversed(self.buf) if part), "")
        after = "" if trail else self._next_char(el)
        opens = _delimiter_class(core[0]) != "punct" or _delimiter_class(before) != "other"
        closes = _delimiter_class(core[-1]) != "punct" or _delimiter_class(after) != "other"
        return opens and closes

    def _opener(self, el) -> str | None:
        """The syntax ``el`` opens with when it writes any: ``[`` for a link or footnote mark, ``*`` for emphasis."""
        if el in self.marker or (el.tag == "span" and _CITE.match(el.get("class") or "")):
            return "["
        if el.tag == "a" and (el.get("href") or "").startswith(("http://", "https://")):
            return "["
        return "*" if _delimiter(el) else None

    def _first_char(self, el) -> str:
        """The first character ``el`` writes, its opening syntax included; empty when it writes nothing."""
        if el.tag in _SKIP or el in self.label:
            return ""
        if (opener := self._opener(el)) is not None:
            text = next((t for t in el.itertext() if t), "")
            return text[0] if text[:1].isspace() else opener if text or opener == "[" else ""
        if el.text:
            return el.text[0]
        for child in el:
            if isinstance(child.tag, str) and (first := self._first_char(child)):
                return first
            if child.tail:
                return child.tail[0]
        return ""

    def _next_char(self, el) -> str:
        """The first character written after ``el``'s closing delimiter: the source text that follows within the
        block, or the syntax a following link or emphasis opens with or an enclosing one closes with. Empty at a
        block edge. A run of elements without text is walked past, so a long one costs its length."""
        while el is not None:
            if el.tail:
                return el.tail[0]
            sibling = el.getnext()
            if sibling is not None and sibling.tag == el.tag and _delimiter(sibling) == _delimiter(el):
                return ""  # an adjacent run of the same emphasis merges with this one; the merged run is checked
            while sibling is not None:
                if isinstance(sibling.tag, str):
                    if sibling.tag in BLOCKS:
                        return ""
                    if first := self._first_char(sibling):
                        return first
                if sibling.tail:
                    return sibling.tail[0]
                sibling = sibling.getnext()
            el = el.getparent()
            if el is None or el.tag in BLOCKS:
                return ""
            if (opener := self._opener(el)) is not None:
                return "]" if opener == "[" else opener
        return ""

    def heading(self, el, level: int) -> None:
        self.flush()
        self.inline_only += 1
        text = _WS.sub(" ", self.capture(el)).strip()
        self.inline_only -= 1
        if text:
            text = re.sub(r"#+$", lambda m: "\\" + m.group(), text)
            self.blocks.append("#" * level + " " + text)

    def listing(self, el, ordered: bool) -> None:
        self.flush()
        items, n = [], 0
        for child in el:
            if not isinstance(child.tag, str):
                continue
            inner = self.sub_blocks(child) if child.tag == "li" else self._one(child)
            if child.tail and child.tail.strip():
                self.text(child.tail)
                self.flush()
            if not inner:
                continue
            n += 1
            marker = f"{n}." if ordered else "-"
            items.append(_prefixed("\n\n".join(inner), marker + " ", " " * (len(marker) + 1)))
        if items:
            self.blocks.append("\n".join(items) if all("\n" not in i for i in items) else "\n\n".join(items))

    def _one(self, el) -> list[str]:
        self.flush()
        saved, self.blocks = self.blocks, []
        self.node(el)
        self.flush()
        out, self.blocks = self.blocks, saved
        return out

    def table(self, el) -> None:
        self.flush()
        rows = []
        for tr in el.iter("tr"):
            if next(tr.iterancestors("table"), None) is not el:
                continue
            cells = []
            for cell in tr:
                if cell.tag in ("td", "th"):
                    self.inline_only += 1
                    text = self.capture(cell)
                    self.inline_only -= 1
                    cells.append(_WS.sub(" ", text).strip().replace("|", "\\|"))
            if any(cells):
                rows.append(cells)
        if not rows:
            return
        width = max(len(r) for r in rows)
        lines = ["| " + " | ".join(r + [""] * (width - len(r))) + " |" for r in rows]
        lines.insert(1, "|" + " --- |" * width)
        self.blocks.append("\n".join(lines))

    def convert(self) -> tuple[str, tuple[Cite, ...]]:
        body = self.root.find("body")
        self.children(body if body is not None else self.root)
        self.flush()
        blocks = self.blocks
        self.in_body = 1
        for el in self.root.iter():
            if el in self.label:
                inner = self.sub_blocks(el)
                if inner:
                    blocks.append(_prefixed("\n\n".join(inner), f"[^{self.label[el]}]: ", "    "))
        md = "\n\n".join(blocks) + ("\n" if blocks else "")
        parts = md.split(_SENTINEL)
        offsets, pos = [], 0
        for i, part in enumerate(parts):
            if i:
                offsets.append(pos + 1)
            pos += len(part)
        if len(offsets) != len(self.cites):
            raise OpinionMarkdownError(f"{len(offsets)} link sentinels for {len(self.cites)} citations")
        return "".join(parts), tuple((o, c, t) for o, (c, t) in zip(offsets, self.cites, strict=True))


def _delimiter(el) -> str | None:
    """The emphasis delimiter ``el`` writes, if it is an emphasis element."""
    tag = el.tag
    return _DELIM.get(tag) or (_STYLE.get(el.get("typestyle") or "") if tag == "emphasis" else None)


def to_markdown(doc: str | None) -> tuple[str, tuple[Cite, ...]]:
    """One HTML/XML rendering as Markdown and its citation links; empty for an empty or blank rendering."""
    if not doc or not doc.strip():
        return "", ()
    try:
        return _Converter(doc).convert()
    except RecursionError as error:
        raise OpinionMarkdownError("rendering nests deeper than the converter walks") from error


def plain_text_markdown(text: str | None) -> str:
    """``plain_text`` as Markdown paragraphs laid out as a ``<pre>`` rendering is: blank lines separate them, every
    line escaped as text, its line breaks and indentation kept."""
    if not text or not text.strip():
        return ""
    text = esc(text.replace("\r\n", "\n").replace("\r", "\n"))
    paragraphs = [block for block in (_paragraph(para, True) for para in _BLANK.split(text)) if block]
    return "\n\n".join(paragraphs) + ("\n" if paragraphs else "")


def select_source(row: dict) -> OpinionText:
    """The first filled rendering of ``row`` in :data:`SOURCE_COLUMNS` order, as Markdown; ``none`` for no text.

    A rendering counts as filled when it holds anything but whitespace.
    """
    for column in SOURCE_COLUMNS:
        value = row.get(column)
        if value and value.strip():
            if column == "plain_text":
                return OpinionText(plain_text_markdown(value), column, ())
            markdown, cites = to_markdown(value)
            return OpinionText(markdown, column, cites)
    return OpinionText("", NO_TEXT, ())


def converter_identity() -> dict[str, str]:
    """What a converted text depends on besides its input: this version, its code digest and the lxml build."""
    from spicy_docs.extraction.derivation import derivation_code_digest

    return {
        "converter": __name__,
        "converter_version": OPINION_MARKDOWN_VERSION,
        "code_digest": derivation_code_digest(__name__, ("spicy_docs.sources.courtlistener",)),
        "lxml_version": ".".join(map(str, lxml.etree.LXML_VERSION)),
        "libxml2_version": ".".join(map(str, lxml.etree.LIBXML_VERSION)),
    }


__all__ = [
    "BLOCKS",
    "NO_TEXT",
    "OPINION_MARKDOWN_VERSION",
    "SOURCE_COLUMNS",
    "OpinionMarkdownError",
    "OpinionText",
    "converter_identity",
    "esc",
    "plain_text_markdown",
    "select_source",
    "to_markdown",
]
