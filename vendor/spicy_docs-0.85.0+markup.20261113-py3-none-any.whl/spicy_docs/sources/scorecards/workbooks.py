"""Bounded workbook syntax and literal cells; publisher readers choose their meaning."""

import posixpath
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import date, timedelta
from io import BytesIO
from zipfile import BadZipFile, ZipFile

from spicy_docs.sources.scorecards.common import ScorecardSourceError

NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
# ECMA-376 Part 1, 18.8.30: format codes implied by built-in numFmtId values. 5-8 are
# locale-dependent; the US-dollar spelling is the one Excel writes for en-US workbooks.
BUILTIN_FORMATS = {
    0: "General",
    1: "0",
    2: "0.00",
    3: "#,##0",
    4: "#,##0.00",
    5: '"$"#,##0_);("$"#,##0)',
    6: '"$"#,##0_);[Red]("$"#,##0)',
    7: '"$"#,##0.00_);("$"#,##0.00)',
    8: '"$"#,##0.00_);[Red]("$"#,##0.00)',
    9: "0%",
    10: "0.00%",
    11: "0.00E+00",
    12: "# ?/?",
    13: "# ??/??",
    14: "mm-dd-yy",
    15: "d-mmm-yy",
    16: "d-mmm",
    17: "mmm-yy",
    18: "h:mm AM/PM",
    19: "h:mm:ss AM/PM",
    20: "h:mm",
    21: "h:mm:ss",
    22: "m/d/yy h:mm",
    37: "#,##0 ;(#,##0)",
    38: "#,##0 ;[Red](#,##0)",
    39: "#,##0.00;(#,##0.00)",
    40: "#,##0.00;[Red](#,##0.00)",
    45: "mm:ss",
    46: "[h]:mm:ss",
    47: "mmss.0",
    48: "##0.0E+0",
    49: "@",
}
BUILTIN_DATE_IDS = frozenset(range(14, 23)) | {45, 46, 47}


def _display_text(node):
    # OOXML rPh and phoneticPr describe pronunciation annotations, not displayed
    # cell text. Read only direct text or rich-text runs, in document order.
    result = []
    for child in node:
        if child.tag == "{" + NS["x"] + "}t":
            result.append(child.text or "")
        elif child.tag == "{" + NS["x"] + "}r":
            result.extend(text.text or "" for text in child.findall("x:t", NS))
    return "".join(result)


@dataclass(frozen=True)
class WorkbookCell:
    value: str | None
    formula: str | None
    # None means no formula node; () means a formula node without attributes.
    # Shared followers can have attributes even when their formula text is absent.
    formula_attributes: tuple[tuple[str, str], ...] | None = None
    # Presentation facts from the cell's style; they describe, never rewrite, the value.
    kind: str = "n"
    number_format: str | None = None
    is_date: bool = False
    # Calendar date of a serial whose format shows a day or year (time of day dropped).
    # None for pure time or duration formats (is_date still holds), for serials outside
    # Python's calendar, and for serials before 1900-03-01 in the 1900 system, where
    # Excel's fictitious leap day applies.
    date_value: date | None = None


def _format_tokens(code: str | None) -> str:
    """The format code's own tokens: quoted literals, [..] sections and escapes removed."""
    return re.sub(r'"[^"]*"|\[[^\]]*\]|\\.', "", code or "")


def is_date_format(code: str | None) -> bool:
    """A format code shows a date or time once literals, [..] sections and escapes are removed."""
    stripped = _format_tokens(code)
    return "General" not in stripped and re.search(r"[dmyhs]", stripped, re.IGNORECASE) is not None


def _serial_date(text: str, date1904: bool) -> date | None:
    try:
        days = int(float(text))
        if date1904:
            return date(1904, 1, 1) + timedelta(days=days)
        return date(1899, 12, 30) + timedelta(days=days) if days >= 61 else None
    except (ValueError, OverflowError):
        # Not a number, infinite, or beyond the calendar Python (and Excel, year 9999) can hold.
        return None


def literal_sheets(body: bytes) -> dict[str, dict[str, WorkbookCell]]:
    """Read complete ZIP entries, resolve internal worksheets, and retain cached formula values.

    Values remain source text. An absent cached value stays absent; this reader
    never evaluates a formula or infers an omitted cell. Each cell also carries
    its resolved number format and, for date-formatted numbers, the calendar
    date in the workbook's epoch. A workbook without styles has no formats.
    """
    try:
        with ZipFile(BytesIO(body)) as archive:
            infos = archive.infolist()
            if (
                len(infos) > 1000
                or sum(i.file_size for i in infos) > 100 * 1024**2
                or len({i.filename for i in infos}) != len(infos)
                or archive.testzip() is not None
            ):
                raise ScorecardSourceError("Workbook ZIP is incomplete, repeated or exceeds its expanded bound")

            def xml(path):
                raw = archive.read(path)
                if b"<!DOCTYPE" in raw or b"<!ENTITY" in raw:
                    raise ScorecardSourceError("Workbook XML contains unsupported declarations")
                return ET.fromstring(raw)

            strings = (
                [_display_text(n) for n in xml("xl/sharedStrings.xml")]
                if "xl/sharedStrings.xml" in archive.namelist()
                else []
            )
            formats = dict(BUILTIN_FORMATS)
            style_formats: list[int] = []
            if "xl/styles.xml" in archive.namelist():
                styles = xml("xl/styles.xml")
                for entry in styles.iter("{" + NS["x"] + "}numFmt"):
                    formats[int(entry.get("numFmtId", ""))] = entry.get("formatCode", "")
                style_formats = [int(xf.get("numFmtId", "0")) for xf in styles.findall("x:cellXfs/x:xf", NS)]
            properties = xml("xl/workbook.xml").find("x:workbookPr", NS)
            date1904 = properties is not None and properties.get("date1904") in {"1", "true"}
            relationships = {}
            relationship_ids = set()
            for relation in xml("xl/_rels/workbook.xml.rels"):
                identifier = relation.get("Id")
                if not identifier or identifier in relationship_ids:
                    raise ScorecardSourceError("Workbook relationship identities are missing or repeated")
                relationship_ids.add(identifier)
                if relation.get("TargetMode") == "External":
                    continue
                target = relation.get("Target", "")
                path = posixpath.normpath(target.lstrip("/") if target.startswith("/") else "xl/" + target)
                if not path.startswith("xl/") or path not in archive.namelist():
                    raise ScorecardSourceError("Workbook relationship leaves its retained ZIP")
                relationships[identifier] = path
            result = {}
            for sheet in xml("xl/workbook.xml").findall("x:sheets/x:sheet", NS):
                name = sheet.get("name")
                if not name or name in result or sheet.get(RID) not in relationships:
                    raise ScorecardSourceError("Workbook worksheet identities are missing or repeated")
                cells = {}
                root = xml(relationships[sheet.get(RID)])
                for node in root.findall("x:sheetData/x:row/x:c", NS):
                    coordinate = node.get("r")
                    if not coordinate or not re.fullmatch(r"[A-Z]+[1-9]\d*", coordinate) or coordinate in cells:
                        raise ScorecardSourceError("Workbook cell coordinates are missing or repeated")
                    value, formula = node.find("x:v", NS), node.find("x:f", NS)
                    text = value.text if value is not None else None
                    kind = node.get("t", "n")
                    if kind == "s":
                        if text is None or not re.fullmatch(r"[0-9]+", text):
                            raise ScorecardSourceError("Workbook shared-string reference is not a nonnegative index")
                        text = strings[int(text)]
                    elif kind == "inlineStr":
                        text = _display_text(node.find("x:is", NS))
                    elif kind not in {"n", "str", "e"}:
                        raise ScorecardSourceError("Workbook introduces an unsupported cell value encoding")
                    # A cell without s uses cellXfs[0]; without styles there is no format.
                    style = node.get("s", "0")
                    if style_formats and (not re.fullmatch(r"[0-9]+", style) or int(style) >= len(style_formats)):
                        raise ScorecardSourceError("Workbook cell style is not an index into its cell formats")
                    format_id = style_formats[int(style)] if style_formats else None
                    number_format = formats.get(format_id) if format_id is not None else None
                    is_date = (
                        kind == "n"
                        and text is not None
                        and format_id is not None
                        and (format_id in BUILTIN_DATE_IDS or is_date_format(number_format))
                    )
                    cells[coordinate] = WorkbookCell(
                        text,
                        formula.text if formula is not None else None,
                        tuple(formula.attrib.items()) if formula is not None else None,
                        kind,
                        number_format,
                        is_date,
                        _serial_date(text, date1904)
                        if is_date and re.search(r"[dy]", _format_tokens(number_format), re.IGNORECASE)
                        else None,
                    )
                result[name] = cells
            return result
    except (BadZipFile, KeyError, IndexError, TypeError, ValueError, AttributeError, ET.ParseError) as error:
        if isinstance(error, ScorecardSourceError):
            raise
        raise ScorecardSourceError("Workbook cannot establish complete literal cells") from error


def column(number: int) -> str:
    result = ""
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result
