"""AGC aggregate tables, one Senate action grid and selected profile observations.

Other profiles and action details remain unqualified. No roll
number or official member identifier is inferred from a publisher URL.
"""

import re
from collections import Counter
from urllib.parse import urlsplit

from bs4 import Comment

from spicy_docs.schemas.tables import json_column

from .common import Bundle, ScorecardEdition, ScorecardSourceError, decimal_text, key, soup, validate_url

parser_version = "agc-html-aggregate-key-vote-index/1"
KEY_VOTE_PARSER_VERSION = "agc-selected-key-vote/1"
NAME = "Associated General Contractors of America"
HOMEPAGE = "https://www.agc.org/"
INDEX = "https://advocacy.agc.org/legislator-scorecard/"
ORIGIN = "https://agcscorecard.voxara.net"
STYLE = ORIGIN + "/css/style.css"
TITLE = "CONGRESSIONAL SCORECARD"
CONGRESSES = ("119", "118", "117", "116")
# Exact observed complete cohorts in the retained qualification, not official
# roster counts or publisher-declared counts. Drift needs a fresh qualification.
REVIEWED_COUNTS = {
    ("119", "house"): (445, 5),
    ("119", "senate"): (102, 2),
    ("118", "house"): (442, 10),
    ("118", "senate"): (102, 4),
    ("117", "house"): (449, 9),
    ("117", "senate"): (100, 6),
    ("116", "house"): (437, 12),
    ("116", "senate"): (99, 3),
}


def _url(kind, chamber, congress):
    return f"{ORIGIN}/{kind}-{chamber}?search-congress={congress}"


def edition(congress):
    if congress not in CONGRESSES:
        raise ScorecardSourceError("AGC congressional rendition has not been qualified")
    return ScorecardEdition(
        "agc",
        congress + "-aggregate-key-vote-index",
        _url("members", "house", congress),
        TITLE,
        congress=congress,
        chamber="both",
        is_current=congress == CONGRESSES[0],
    )


def _text(node):
    return " ".join(node.get_text(" ", strip=True).split())


def _one(root, selector):
    nodes = root.select(selector)
    if len(nodes) != 1:
        raise ScorecardSourceError("AGC native field is missing or repeated: " + selector)
    return nodes[0]


def _layout(node, children):
    elements = [child.name for child in node.children if getattr(child, "name", None)]
    text = [str(child).strip() for child in node.children if isinstance(child, str) and not isinstance(child, Comment)]
    if elements != children or any(text):
        raise ScorecardSourceError("AGC native table exposes unreviewed content or notes")


def _html(document, url):
    if document.url != url or document.response.requested_url != url:
        raise ScorecardSourceError("AGC selected original route changed")
    if not document.body.rstrip().lower().endswith(b"</html>") or b"</body>" not in document.body.lower():
        raise ScorecardSourceError("AGC original HTML is incomplete")
    html = soup(document)
    _one(html, "html")
    _one(html, "body")
    # The publisher's WordPress guide has unrelated navigation. Only a native
    # scorecard table's pagination describes the selected scoring population.
    if url != INDEX and html.select("[class*='pagination'], [class*='pager'], [data-next-page], a[rel='next']"):
        raise ScorecardSourceError("AGC original exposes an unreviewed partial population")
    return html


def _authority(document):
    html = _html(document, INDEX)
    heading = _one(html, "#main h1")
    frame = _one(html, "iframe#agcscorecard")
    context = _one(html, "#main .fusion-text")
    if _text(heading) != "How Congress Voted" or frame.get("src") != ORIGIN + "/members-house" or not _text(context):
        raise ScorecardSourceError("AGC publisher no longer designates the selected scorecard host")
    return {"heading": _text(heading), "context": _text(context), "scorecard_url": frame["src"]}


def _name_display(document):
    if document.url != STYLE or document.response.requested_url != STYLE:
        raise ScorecardSourceError("AGC selected name-display stylesheet route changed")
    try:
        css = re.sub(r"/\*.*?\*/", "", document.body.decode("utf-8"), flags=re.DOTALL)
    except UnicodeError as error:
        raise ScorecardSourceError("AGC name-display stylesheet is not UTF-8") from error
    rules = re.findall(r"(?:^|})\s*span\.hide\s*\{([^{}]*)\}", css)
    if len(rules) != 1 or not re.fullmatch(r"\s*display\s*:\s*none\s*;\s*", rules[0]):
        raise ScorecardSourceError("AGC native sorting surname is no longer explicitly hidden")
    return "span.hide { display: none; }"


def _table(document, kind, chamber, congress):
    html = _html(document, _url(kind, chamber, congress))
    if _text(_one(html, "title")) != NAME or _text(_one(html, "h1")) != TITLE:
        raise ScorecardSourceError("AGC scorecard attribution or heading changed")
    if len(html.select('link[rel="stylesheet"][href="' + STYLE + '"]')) != 1:
        raise ScorecardSourceError("AGC native name-display stylesheet reference changed")
    form = _one(html, "form#searchForm")
    if form.get("action") != kind + "-" + chamber or form.get("method", "").upper() != "GET":
        raise ScorecardSourceError("AGC unfiltered table form changed")
    options = _one(html, "select#search-congress").find_all("option", recursive=False)
    if [o.get("value") for o in options] != list(CONGRESSES) or [
        o.get("value") for o in options if o.has_attr("selected")
    ] != [congress]:
        raise ScorecardSourceError("AGC selected period or complete congressional catalog changed")
    labels = [_text(o) for o in options]
    if any(
        not re.fullmatch(c + r"(?:st|nd|rd|th) Congress", label) for c, label in zip(CONGRESSES, labels, strict=True)
    ):
        raise ScorecardSourceError("AGC congressional label changed")
    if html.select("input[checked]") or any(n.get("value", "") for n in html.select("input[type='search']")):
        raise ScorecardSourceError("AGC member table is filtered")
    selected_states = html.select("select#search-state option[selected]")
    if selected_states and (len(selected_states) != 1 or selected_states[0].get("value") != ""):
        raise ScorecardSourceError("AGC member table has a selected state")
    table = _one(html, "table#myTable")
    container = _one(html, ".record-list > section.container-fluid")
    responsive = _one(container, "section.table-responsive")
    _layout(container.parent, ["section"])
    _layout(container, ["section"])
    _layout(responsive, ["table"])
    _layout(table, ["thead", "tbody"])
    expected = (
        ["MEMBER", "PARTY", "CHAMBER", "DISTRICT", "CURRENT", "LIFETIME"]
        if kind == "members"
        else ["BILL", "TITLE", "AGC", "RESULT"]
    )
    if len(html.select("table")) != 1 or [_text(n) for n in table.select("thead th")] != expected:
        raise ScorecardSourceError("AGC native table columns changed")
    if table.select("caption, tfoot, [title], [aria-label], [data-tooltip], [hidden]"):
        raise ScorecardSourceError("AGC table exposes unreviewed notes or exclusions")
    rows = _one(table, "tbody").find_all("tr", recursive=False)
    expected_count = REVIEWED_COUNTS[(congress, chamber)][0 if kind == "members" else 1]
    if len(rows) != expected_count or len(table.select("tbody tr")) != len(rows):
        raise ScorecardSourceError("AGC complete named table population changed")
    _layout(_one(table, "tbody"), ["tr"] * len(rows))
    facts, identities = [], set()
    for number, row in enumerate(rows, 1):
        cells = row.find_all("td", recursive=False)
        _layout(row, ["td"] * len(expected))
        route = re.fullmatch(r"document\.location='([^']+)'", row.get("onclick", ""))
        if (
            len(cells) != len(expected)
            or len(row.select("td")) != len(cells)
            or route is None
            or set(row.attrs) - {"class", "scope", "onclick", "style"}
            or any(set(cell.attrs) - {"class"} for cell in cells)
        ):
            raise ScorecardSourceError("AGC native row shape changed")
        url = route[1]
        validate_url(url, ("agcscorecard.voxara.net",))
        prefix = f"/{kind}-{chamber}/"
        parsed = urlsplit(url)
        native_id = parsed.path.removeprefix(prefix)
        if not parsed.path.startswith(prefix) or not native_id or "/" in native_id or parsed.fragment:
            raise ScorecardSourceError("AGC native row identifier changed")
        values = [_text(c) for c in cells]
        if kind == "members":
            sort_span = cells[0].find_all("span", recursive=False)
            if (
                len(sort_span) != 1
                or sort_span[0].get("class") != ["hide"]
                or len(cells[0].find_all()) != 1
                or any(cell.find() for cell in cells[1:])
                or set(sort_span[0].attrs) != {"class"}
            ):
                raise ScorecardSourceError("AGC native visible member name changed")
            values[0] = " ".join(
                str(n).strip() for n in cells[0].children if isinstance(n, str) and not isinstance(n, Comment)
            ).strip()
            if (
                not re.fullmatch(r"[A-Z]\d{6}", native_id)
                or parsed.query != "congress=" + congress
                or values[2] != chamber.title()
                or not re.fullmatch(r"[A-Z]{2} - (?:\d+|Senate|At-Large)", values[3])
                or any(not re.fullmatch(r"\d+%", v) for v in values[4:])
            ):
                raise ScorecardSourceError("AGC member period, chamber, district or native percentages changed")
            identity = native_id
        else:
            if parsed.query or any(c.find() for c in cells) or not all(values):
                raise ScorecardSourceError("AGC key-vote index exposes an unreviewed item shape")
            # The 116th Senate source reuses one URL for two differently titled
            # H.R.268 actions. Its URL alone is not a unique scoring-item ID.
            identity = key(native_id, values[1])
        if not all(values) or identity in identities:
            raise ScorecardSourceError("AGC native table repeats or omits an identity")
        identities.add(identity)
        facts.append(
            {
                "id": native_id,
                "identity": identity,
                "values": values,
                "url": url,
                "path": f"#myTable > tbody > tr:nth-of-type({number})",
                "sort_text": _text(sort_span[0]) if kind == "members" else None,
            }
        )
    return {"period": labels[CONGRESSES.index(congress)], "headers": expected, "rows": facts}


def list_scorecards(context):
    source = context.read(
        _url("members", "house", CONGRESSES[0]), stage="scorecards:agc:catalog", hosts=("agcscorecard.voxara.net",)
    )
    _table(source, "members", "house", CONGRESSES[0])
    return tuple(edition(c) for c in CONGRESSES)


def acquire_scorecard(selected, context):
    if selected in _PROFILE_SPONSORSHIP_EDITIONS:
        return _acquire_profile_sponsorships(selected, context)
    if selected in _PROFILE_PAST_SCORE_EDITIONS:
        return _acquire_profile_past_scores(selected, context)
    if selected in _PROFILE_VOTE_EDITIONS:
        return _acquire_profile_votes(selected, context)
    if selected == key_vote_edition():
        return _acquire_key_vote(selected, context)
    if selected.congress not in CONGRESSES or selected != edition(selected.congress):
        raise ScorecardSourceError("AGC selection is outside the qualified aggregate and key-vote-index rendition")
    authority = context.read(INDEX, stage="scorecards:agc:publisher-authority", hosts=("advocacy.agc.org",))
    authority_facts = _authority(authority)
    style = context.read(STYLE, stage="scorecards:agc:name-display", hosts=("agcscorecard.voxara.net",))
    style_rule = _name_display(style)
    documents, facts = {}, {}
    for chamber in ("house", "senate"):
        for kind in ("members", "key-votes"):
            document = context.read(
                _url(kind, chamber, selected.congress),
                stage=f"scorecards:agc:{kind}:{chamber}",
                hosts=("agcscorecard.voxara.net",),
            )
            documents[(kind, chamber)] = document
            facts[(kind, chamber)] = _table(document, kind, chamber, selected.congress)
    bundle = Bundle(
        selected,
        context,
        documents[("members", "house")],
        publisher_name=NAME,
        parser_version=parser_version,
        rendition_rule="Complete native unfiltered House and Senate aggregate tables and key-vote indexes; profiles, item details, individual actions and sponsorship grids are separate renditions",
        homepage=HOMEPAGE,
    )
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        edition_label_text=facts[("members", "house")]["period"], source_path="h1", methodology_url=INDEX
    )
    bundle.use(authority, "publisher-authority", "publisher-guide")
    bundle.use(style, "name-display")
    bundle.add(
        "scorecard_methodologies",
        authority,
        "#main .fusion-text",
        methodology_id="publisher-guide",
        methodology_text=json_column(authority_facts),
        methodology_url=INDEX,
        disclosure_status="Native aggregate values and key-vote indexes; individual votes, sponsorships and past profile scores are outside this rendition",
    )
    for chamber in ("house", "senate"):
        members = documents[("members", chamber)]
        items = documents[("key-votes", chamber)]
        bundle.use(members, f"members:{chamber}", f"ratings:{chamber}")
        bundle.use(items, f"items:{chamber}", f"positions:{chamber}")
        bundle.add(
            "scorecard_methodologies",
            items,
            "#myTable",
            methodology_id=key("native-key-vote-index", chamber),
            chamber_text=chamber.title(),
            methodology_text=json_column(facts[("key-votes", chamber)]),
            disclosure_status="Native publisher bill outcomes and item detail URLs; no member action grid or metric weight is stated by the selected index",
        )
        period = facts[("members", chamber)]["period"]
        for column, name in enumerate(facts[("members", chamber)]["headers"][4:], 5):
            metric = key(chamber, name)
            bundle.add(
                "scorecard_metrics",
                members,
                f"#myTable > thead > tr > th:nth-of-type({column})",
                metric_id=metric,
                name=name,
                chamber_text=chamber.title(),
                period_text=period if name == "CURRENT" else name,
                value_unit_text="%",
            )
        for member in facts[("members", chamber)]["rows"]:
            name, party, native_chamber, from_text, current, lifetime = member["values"]
            state, district = from_text.split(" - ")
            member_key = key(chamber, member["id"])
            bundle.add(
                "scorecard_members",
                members,
                member["path"],
                publisher_member_key=member_key,
                publisher_member_id=member["id"],
                member_name=name,
                party=party,
                chamber_text=native_chamber,
                state=state,
                district=district,
                period_text=period,
                identifiers_json=json_column([{"scheme": "agc", "value": member["id"]}]),
                notes_text=json_column(
                    {
                        "native_district_text": from_text,
                        "native_sort_text": member["sort_text"],
                        "profile_url": member["url"],
                    }
                ),
            )
            for column, metric_name, value in ((5, "CURRENT", current), (6, "LIFETIME", lifetime)):
                bundle.add(
                    "scorecard_member_ratings",
                    members,
                    member["path"] + f" > td:nth-of-type({column})",
                    metric_id=key(chamber, metric_name),
                    publisher_member_key=member_key,
                    value_text=value,
                    value_number=decimal_text(value),
                )
        for item in facts[("key-votes", chamber)]["rows"]:
            citation, title, position, _result = item["values"]
            bundle.add(
                "scorecard_items",
                items,
                item["path"],
                item_id=key(chamber, item["identity"]),
                publisher_item_id=item["id"],
                item_kind_text="KEY VOTES",
                title=title,
                chamber_text=chamber.title(),
                congress_text=selected.congress,
                bill_citation_text=citation,
                publisher_position_text=position,
                position_basis="explicit",
                position_source_path=item["path"] + " > td:nth-of-type(3)",
            )
    repeat = context.read(INDEX, stage="scorecards:agc:publisher-authority-reread", hosts=("advocacy.agc.org",))
    if _authority(repeat) != authority_facts:
        raise ScorecardSourceError("AGC publisher designation or source guide changed on reread")
    bundle.use(repeat, "publisher-authority", "publisher-guide", role="corroboration")
    repeat = context.read(STYLE, stage="scorecards:agc:name-display-reread", hosts=("agcscorecard.voxara.net",))
    if _name_display(repeat) != style_rule:
        raise ScorecardSourceError("AGC native name-display rule changed on reread")
    bundle.use(repeat, "name-display", role="corroboration")
    for (kind, chamber), original in facts.items():
        repeat = context.read(
            _url(kind, chamber, selected.congress),
            stage=f"scorecards:agc:{kind}:{chamber}:reread",
            hosts=("agcscorecard.voxara.net",),
        )
        if _table(repeat, kind, chamber, selected.congress) != original:
            raise ScorecardSourceError("AGC complete native membership, ratings or key-vote items changed on reread")
        groups = (
            (f"members:{chamber}", f"ratings:{chamber}")
            if kind == "members"
            else (f"items:{chamber}", f"positions:{chamber}")
        )
        bundle.use(repeat, *groups, role="corroboration")
    return bundle.finish(
        "Complete original publisher-designated unfiltered native House/Senate tables reached closing HTML; each named cohort and item count matches its retained qualification; both chamber tables, congressional labels, native IDs/values and publisher guide agree on reread. Profiles and item details are separate source renditions."
    )


def key_vote_edition():
    """The qualified complete grid of one Senate item, separate from aggregate editions."""
    return ScorecardEdition(
        "agc",
        "119-senate-key-vote-hr1-1-119",
        ORIGIN + "/key-votes-senate/hr1-1-119",
        "One Big Beautiful Bill Act",
        congress="119",
        chamber="Senate",
    )


def _key_vote_detail(document, item, congress):
    # The publisher closes an extra div inside its tally headers. html.parser
    # ejects the remaining cells from the table; lxml recovers the native table.
    # Keep original bytes and verify both complete tables rather than edit HTML.
    from bs4 import BeautifulSoup, FeatureNotFound

    _html(document, item["url"])
    try:
        html = BeautifulSoup(document.body, "lxml")
    except FeatureNotFound as error:
        raise ScorecardSourceError("AGC key-vote details require spicy-docs[html,reconstruct] for lxml") from error
    if _text(_one(html, "title")) != NAME or _text(_one(html, "h1")) != TITLE:
        raise ScorecardSourceError("AGC key-vote detail attribution changed")
    if [_text(h) for h in html.select(".voting-record h3")] != ["Votes by Party", "Roll Call Votes"]:
        raise ScorecardSourceError("AGC key-vote detail modules changed")
    citation, title, _position, _outcome = item["values"]
    if _text(_one(html, ".details h3.text-blue")) != citation or _text(_one(html, "h4")) != title:
        raise ScorecardSourceError("AGC key-vote detail disagrees with its selected index item")
    description = _text(_one(html, "div.text-blue.h5"))
    if not description or len(html.select('link[rel="stylesheet"][href="' + STYLE + '"]')) != 1:
        raise ScorecardSourceError("AGC key-vote detail description or name stylesheet changed")
    tables = html.select("table")
    if [table.get("id") for table in tables] != ["myTables", "myTable"]:
        raise ScorecardSourceError("AGC key-vote detail has missing or unreviewed tables")
    member_table = tables[1]
    expected_headers = (
        ["PARTY", "YEAS", "NAYS", "PRESENT", "NOT VOTING"],
        ["MEMBER", "", "DISTRICT", "PARTY", "VOTE"],
    )
    table_rows = []
    for table, headers in zip(tables, expected_headers, strict=True):
        _layout(table, ["thead", "tbody"])
        if [_text(h) for h in table.select("thead th")] != headers:
            raise ScorecardSourceError("AGC key-vote detail columns changed")
        if table.select("caption, tfoot, [title], [aria-label], [data-tooltip], [hidden]"):
            raise ScorecardSourceError("AGC key-vote detail exposes unreviewed notes")
        rows = _one(table, "tbody").find_all("tr", recursive=False)
        _layout(_one(table, "tbody"), ["tr"] * len(rows))
        if not rows or len(table.select("tbody tr")) != len(rows):
            raise ScorecardSourceError("AGC key-vote detail has an empty or nested population")
        for row in rows:
            _layout(row, ["td"] * len(headers))
        table_rows.append(rows)
    party_names = {"Republican": "R", "Democratic": "D", "Independent": "I"}
    tallies = {}
    tally_rows = []
    for row in table_rows[0]:
        cells = row.find_all("td", recursive=False)
        values = [_text(cell) for cell in cells]
        label, *counts = values
        if (
            row.attrs
            or label not in {*party_names, "total"}
            or label in tallies
            or any(cell.find() or cell.attrs for cell in cells)
            or any(not re.fullmatch(r"0|[1-9]\d*", count) for count in counts)
        ):
            raise ScorecardSourceError("AGC party tally identity or value changed")
        tallies[label] = tuple(map(int, counts))
        tally_rows.append(values)
    if (
        set(tallies) != {*party_names, "total"}
        or tuple(sum(tallies[party][i] for party in party_names) for i in range(4)) != tallies["total"]
    ):
        raise ScorecardSourceError("AGC party tallies do not reconcile with their total")
    hidden_header = member_table.select("thead th")[1]
    if hidden_header.attrs != {"style": "display:none"}:
        raise ScorecardSourceError("AGC hidden empty member column changed")
    votes = {"Yes": 0, "No": 1, "Present": 2, "Not Voting": 3}
    members, identities, observed = [], set(), Counter()
    for number, row in enumerate(table_rows[1], 1):
        cells = row.find_all("td", recursive=False)
        if (
            set(row.attrs) - {"onclick", "style"}
            or any(cell.attrs for i, cell in enumerate(cells) if i != 1)
            or cells[1].attrs != {"style": "display:none"}
            or _text(cells[1])
            or any(cell.find() for cell in cells[1:])
        ):
            raise ScorecardSourceError("AGC key-vote member row shape changed")
        surname = cells[0].find_all("span", recursive=False)
        if len(surname) != 1 or surname[0].attrs != {"class": ["hide"]} or len(cells[0].find_all()) != 1:
            raise ScorecardSourceError("AGC key-vote visible member name changed")
        name = " ".join(
            str(n).strip() for n in cells[0].children if isinstance(n, str) and not isinstance(n, Comment)
        ).strip()
        route = re.fullmatch(r"document\.location='([^']+)'", row.get("onclick", ""))
        prefix = ORIGIN + "/members-senate/"
        if route is None:
            raise ScorecardSourceError("AGC key-vote member profile route changed")
        match = re.fullmatch(re.escape(prefix) + r"([A-Z]\d{6})\?congress=" + congress, route[1])
        state, party, vote = [_text(cell) for cell in cells[2:]]
        if (
            not name
            or not _text(surname[0])
            or match is None
            or match[1] in identities
            or not re.fullmatch(r"[A-Z]{2}", state)
            or party not in party_names.values()
            or vote not in votes
        ):
            raise ScorecardSourceError("AGC key-vote member identity, period or action changed")
        identities.add(match[1])
        observed[(party, votes[vote])] += 1
        members.append(
            {
                "id": match[1],
                "name": name,
                "state": state,
                "party": party,
                "vote": vote,
                "profile_url": route[1],
                "sort_text": _text(surname[0]),
                "path": f"#myTable > tbody > tr:nth-of-type({number})",
            }
        )
    if any(tuple(observed[(code, i)] for i in range(4)) != tallies[label] for label, code in party_names.items()):
        raise ScorecardSourceError("AGC member votes do not reconcile with source-declared party totals")
    return {"description": description, "tallies": tally_rows, "members": members}


def _key_vote_facts(detail):
    # Native sorting ties reorder state pairs between requests. Compare source
    # identities and values; output locators remain bound to the primary capture.
    return {
        "description": detail["description"],
        "tallies": sorted(detail["tallies"]),
        "members": {m["id"]: {k: v for k, v in m.items() if k != "path"} for m in detail["members"]},
    }


def _acquire_key_vote(selected, context):
    documents, facts = {}, {}
    for label, url, hosts in (
        ("authority", INDEX, ("advocacy.agc.org",)),
        ("style", STYLE, ("agcscorecard.voxara.net",)),
        ("index", _url("key-votes", "senate", selected.congress), ("agcscorecard.voxara.net",)),
        ("detail", selected.source_url, ("agcscorecard.voxara.net",)),
    ):
        documents[label] = context.read(url, stage="scorecards:agc:key-vote:" + label, hosts=hosts)
    facts["authority"] = _authority(documents["authority"])
    facts["style"] = _name_display(documents["style"])
    facts["index"] = _table(documents["index"], "key-votes", "senate", selected.congress)
    matches = [item for item in facts["index"]["rows"] if item["url"] == selected.source_url]
    if len(matches) != 1 or matches[0]["values"][:2] != ["H.R.1", selected.title]:
        raise ScorecardSourceError("AGC selected key vote is absent, ambiguous or changed in its native index")
    item = matches[0]
    detail = facts["detail"] = _key_vote_detail(documents["detail"], item, selected.congress)
    bundle = Bundle(
        selected,
        context,
        documents["detail"],
        publisher_name=NAME,
        parser_version=KEY_VOTE_PARSER_VERSION,
        homepage=HOMEPAGE,
        rendition_rule="Complete native member grid for the selected Senate H.R.1 item only; other items, aggregate ratings, profiles and sponsorships are outside this rendition",
    )
    for label, document in documents.items():
        bundle.use(document, label)
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(edition_label_text=facts["index"]["period"], source_path="h4")
    bundle.add(
        "scorecard_methodologies",
        documents["authority"],
        "#main .fusion-text",
        methodology_id="publisher-guide",
        methodology_text=json_column(facts["authority"]),
        methodology_url=INDEX,
    )
    bundle.add(
        "scorecard_methodologies",
        documents["detail"],
        "#myTables",
        methodology_id="selected-item-detail",
        chamber_text="Senate",
        methodology_text=json_column({"description": detail["description"], "party_tallies": detail["tallies"]}),
        disclosure_status="Literal publisher explanation and vote totals; no official roll number, scoring weight or member credit is stated",
    )
    item_id = key("senate", item["identity"])
    bundle.add(
        "scorecard_items",
        documents["index"],
        item["path"],
        item_id=item_id,
        publisher_item_id=item["id"],
        item_kind_text="KEY VOTES",
        title=item["values"][1],
        congress_text=selected.congress,
        chamber_text="Senate",
        bill_citation_text=item["values"][0],
        publisher_position_text=item["values"][2],
        position_basis="explicit",
        position_source_path=item["path"] + " > td:nth-of-type(3)",
    )
    bundle.add(
        "scorecard_methodologies",
        documents["index"],
        item["path"],
        methodology_id="selected-item-index",
        methodology_text=json_column(item),
        disclosure_status="Native index outcome describes the bill, not member credit",
    )
    for member in detail["members"]:
        member_key = key("senate", member["id"])
        bundle.add(
            "scorecard_members",
            documents["detail"],
            member["path"],
            publisher_member_key=member_key,
            publisher_member_id=member["id"],
            member_name=member["name"],
            party=member["party"],
            state=member["state"],
            chamber_text="Senate",
            period_text=facts["index"]["period"],
            identifiers_json=json_column([{"scheme": "agc", "value": member["id"]}]),
            notes_text=json_column({"profile_url": member["profile_url"], "native_sort_text": member["sort_text"]}),
        )
        bundle.add(
            "scorecard_member_item_results",
            documents["detail"],
            member["path"] + " > td:nth-of-type(5)",
            item_id=item_id,
            publisher_member_key=member_key,
            result_id="native-member-vote",
            action_text=member["vote"],
        )
    parsers = {
        "authority": _authority,
        "style": _name_display,
        "index": lambda d: _table(d, "key-votes", "senate", selected.congress),
        "detail": lambda d: _key_vote_detail(d, item, selected.congress),
    }
    for label, document in documents.items():
        repeat = context.read(
            document.url, stage="scorecards:agc:key-vote:" + label + ":reread", hosts=(urlsplit(document.url).hostname,)
        )
        repeated_facts = parsers[label](repeat)
        same = (
            _key_vote_facts(repeated_facts) == _key_vote_facts(facts[label])
            if label == "detail"
            else repeated_facts == facts[label]
        )
        if not same:
            raise ScorecardSourceError("AGC selected key-vote source facts changed on reread")
        bundle.use(repeat, label, role="corroboration")
    return bundle.finish(
        "One exact native Senate index item and complete member grid; all unique source member IDs bind Congress 119, every party/action tally reconciles to the publisher total, and authority, style, index and detail facts agree on reread. No other item or profile cohort is claimed.",
        declared={"party_tallies": detail["tallies"]},
    )


class AgcKeyVoteReader:
    """Named retained-input reader with the selected rendition's evidence version."""

    parser_version = KEY_VOTE_PARSER_VERSION

    def list_scorecards(self, context):
        return (key_vote_edition(),)

    def acquire_scorecard(self, selected, context):
        if selected != key_vote_edition():
            raise ScorecardSourceError("AGC named key-vote reader requires its exact qualified selection")
        return _acquire_key_vote(selected, context)


PROFILE_VOTE_PARSER_VERSION = "agc-selected-profile-votes/1"
PROFILE_VOTE_SELECTIONS = (
    ("house", "118", "P000197"),
    ("house", "119", "P000197"),
    ("house", "119", "B001323"),
    ("senate", "119", "C001098"),
)
PROFILE_VOTE_GUIDE = (
    "Below are the legislator’s votes on bills that AGC has designated as key votes. "
    "Click on any bill to learn more about the issue and how they voted."
)


def profile_vote_edition(chamber, congress, member_id):
    """One retained member's complete Voting Record, bound to its native index."""
    if (chamber, congress, member_id) not in PROFILE_VOTE_SELECTIONS:
        raise ScorecardSourceError("AGC selected profile voting record has not been qualified")
    return ScorecardEdition(
        "agc",
        f"{congress}-{chamber}-profile-votes-{member_id}",
        f"{ORIGIN}/members-{chamber}/{member_id}?congress={congress}",
        "Voting Record",
        congress=congress,
        chamber=chamber.title(),
        is_current=congress == CONGRESSES[0],
    )


def _profile(document, member, chamber):
    from bs4 import BeautifulSoup, FeatureNotFound

    _html(document, member["url"])
    try:
        html = BeautifulSoup(document.body, "lxml")
    except FeatureNotFound as error:
        raise ScorecardSourceError("AGC profile votes require spicy-docs[html,reconstruct] for lxml") from error
    if (
        _text(_one(html, "title")) != NAME
        or _text(_one(html, "h1")) != TITLE
        or len(html.select('link[rel="stylesheet"][href="' + STYLE + '"]')) != 1
    ):
        raise ScorecardSourceError("AGC profile attribution or name stylesheet changed")
    bio = _one(html, ".main-bio")
    name = _text(_one(bio, "h2"))
    affiliation = _text(_one(bio, "h4"))
    chamber_text = _text(_one(bio, "h3"))
    native_name, party, _chamber, district, _current, _lifetime = member["values"]
    if (
        name != native_name
        or chamber_text != {"house": "U.S. House of Representatives", "senate": "U.S. Senate"}[chamber]
        or re.fullmatch(
            re.escape({"R": "Republican", "D": "Democratic", "I": "Independent"}.get(party, "?"))
            + r" \| "
            + district[:2]
            + r"(?: - ?(?:\d+|At-Large)?)?",
            affiliation,
        )
        is None
    ):
        raise ScorecardSourceError("AGC profile member identity disagrees with its selected native index")
    return html, {"name": name, "affiliation": affiliation, "chamber": chamber_text}


def _profile_votes(document, member, items, chamber):
    html, profile_identity = _profile(document, member, chamber)
    table = _one(html, "table#myTable")
    section = table.find_parent("section", class_="voting-record")
    if section is None:
        raise ScorecardSourceError("AGC profile vote table left its Voting Record section")
    home = _one(section, "#home")
    responsive = _one(home, "section.table-responsive")
    _layout(home, ["section"])
    _layout(responsive, ["table"])
    if table.parent is not responsive:
        raise ScorecardSourceError("AGC profile vote table left its selected Current Score tab")
    if _text(_one(section, "h3")) != "Voting Record" or _text(_one(section, "p")) != PROFILE_VOTE_GUIDE:
        raise ScorecardSourceError("AGC profile voting-record scope or explanation changed")
    _layout(table, ["thead", "tbody"])
    if [_text(h) for h in table.select("thead th")] != ["Bill", "Name", "AGC Position", "Member Vote", "Result"]:
        raise ScorecardSourceError("AGC profile vote columns changed")
    if table.select("caption, tfoot, [title], [aria-label], [data-tooltip], [hidden]"):
        raise ScorecardSourceError("AGC profile vote table exposes unreviewed notes")
    rows = _one(table, "tbody").find_all("tr", recursive=False)
    _layout(_one(table, "tbody"), ["tr"] * len(rows))
    indexed = {(item["url"], item["values"][1]): item for item in items["rows"]}
    if len(rows) != len(indexed) or len(table.select("tbody tr")) != len(rows):
        raise ScorecardSourceError("AGC profile vote population differs from its complete native item index")
    votes, seen = [], set()
    for number, row in enumerate(rows, 1):
        _layout(row, ["td"] * 5)
        cells = row.find_all("td", recursive=False)
        route = re.fullmatch(r"document\.location='([^']+)'", row.get("onclick", ""))
        if (
            route is None
            or set(row.attrs) - {"class", "scope", "onclick", "style"}
            or row.get("class") != ["noncurrent"]
            or row.get("scope") != "row"
            or row.get("style") != "cursor:pointer"
            or any(
                cell.find() or cell.attrs != ({} if i < 2 else {"class": ["text-center"]})
                for i, cell in enumerate(cells)
            )
        ):
            raise ScorecardSourceError("AGC profile vote row shape changed")
        values = [_text(cell) for cell in cells]
        identity = (route[1], values[1])
        item = indexed.get(identity)
        if (
            item is None
            or identity in seen
            or [values[0], values[1], values[2], values[4]] != item["values"]
            or values[3] not in {"Yes", "No"}
        ):
            raise ScorecardSourceError(
                "AGC profile vote identity, action or item context differs from its native index"
            )
        seen.add(identity)
        votes.append({"item": item, "values": values, "path": f"#myTable > tbody > tr:nth-of-type({number})"})
    return {**profile_identity, "votes": votes}


def _acquire_profile_votes(selected, context):
    chamber = selected.chamber.lower()
    documents = {}
    for label, url in (
        ("authority", INDEX),
        ("style", STYLE),
        ("members", _url("members", chamber, selected.congress)),
        ("items", _url("key-votes", chamber, selected.congress)),
        ("profile", selected.source_url),
    ):
        documents[label] = context.read(
            url, stage="scorecards:agc:profile-votes:" + label, hosts=(urlsplit(url).hostname,)
        )
    authority = _authority(documents["authority"])
    _name_display(documents["style"])
    members = _table(documents["members"], "members", chamber, selected.congress)
    items = _table(documents["items"], "key-votes", chamber, selected.congress)
    matches = [member for member in members["rows"] if member["url"] == selected.source_url]
    if len(matches) != 1:
        raise ScorecardSourceError("AGC selected profile is absent or ambiguous in its native member index")
    member = matches[0]
    detail = _profile_votes(documents["profile"], member, items, chamber)
    bundle = Bundle(
        selected,
        context,
        documents["profile"],
        publisher_name=NAME,
        parser_version=PROFILE_VOTE_PARSER_VERSION,
        homepage=HOMEPAGE,
        rendition_rule="One selected member's complete Voting Record as retained; chamber and Congress come from exact native member and key-vote index linkage. One profile observation; no reread or current-availability claim. Sponsorships, past scores and metric participation are excluded.",
    )
    for label, document in documents.items():
        bundle.use(document, label)
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None,
        edition_label_text=items["period"],
        source_path="section.voting-record:has(table#myTable) h3",
    )
    bundle.add(
        "scorecard_methodologies",
        documents["authority"],
        "#main .fusion-text",
        methodology_id="publisher-guide",
        methodology_text=json_column(authority),
        methodology_url=INDEX,
    )
    bundle.add(
        "scorecard_methodologies",
        documents["profile"],
        ".main-bio",
        methodology_id="selected-profile-voting-record",
        methodology_text=json_column(
            {
                "name": detail["name"],
                "native_affiliation_text": detail["affiliation"],
                "native_chamber_text": detail["chamber"],
                "voting_record_explanation": PROFILE_VOTE_GUIDE,
            }
        ),
        disclosure_status="One retained profile observation. The Current Congress label alone does not identify a period; native indexes bind the exact member route and complete item set. Bill outcomes are not member credit. No score weights or official roll numbers are inferred.",
    )
    bundle.add(
        "scorecard_methodologies",
        documents["items"],
        "#myTable",
        methodology_id="selected-profile-item-index",
        methodology_text=json_column(items),
    )
    member_key = key(chamber, member["id"])
    state, district = member["values"][3].split(" - ", 1)
    bundle.add(
        "scorecard_members",
        documents["members"],
        member["path"],
        publisher_member_key=member_key,
        publisher_member_id=member["id"],
        member_name=member["values"][0],
        party=member["values"][1],
        chamber_text=member["values"][2],
        state=state,
        district=district,
        period_text=members["period"],
        identifiers_json=json_column([{"scheme": "agc", "value": member["id"]}]),
        notes_text=json_column(
            {
                "profile_url": member["url"],
                "native_district_text": member["values"][3],
                "native_sort_text": member["sort_text"],
            }
        ),
    )
    for vote in detail["votes"]:
        item = vote["item"]
        item_id = key(chamber, item["identity"])
        bundle.add(
            "scorecard_items",
            documents["profile"],
            vote["path"],
            item_id=item_id,
            publisher_item_id=item["id"],
            item_kind_text="Voting Record",
            title=vote["values"][1],
            congress_text=selected.congress,
            chamber_text=selected.chamber,
            bill_citation_text=vote["values"][0],
            publisher_position_text=vote["values"][2],
            position_basis="explicit",
            position_source_path=vote["path"] + " > td:nth-of-type(3)",
        )
        bundle.add(
            "scorecard_member_item_results",
            documents["profile"],
            vote["path"] + " > td:nth-of-type(4)",
            item_id=item_id,
            publisher_member_key=member_key,
            result_id="native-profile-vote",
            action_text=vote["values"][3],
        )
    return bundle.finish(
        "Complete Voting Record table for one exact native member profile, with closed HTML, no pagination, unique item identities and exact agreement with every bill, title, preferred position, outcome and URL in the qualified chamber/Congress item index. One retained profile observation; no whole-member cohort, paired reread, sponsorship, historical-score or current-availability claim."
    )


class AgcProfileVoteReader:
    """Named reader for the explicitly selected retained profile Voting Records."""

    parser_version = PROFILE_VOTE_PARSER_VERSION

    def list_scorecards(self, context):
        return tuple(profile_vote_edition(*selection) for selection in PROFILE_VOTE_SELECTIONS)

    def acquire_scorecard(self, selected, context):
        if selected not in self.list_scorecards(context):
            raise ScorecardSourceError("AGC named profile-vote reader requires an exact qualified selection")
        return _acquire_profile_votes(selected, context)


PROFILE_PAST_SCORE_PARSER_VERSION = "agc-selected-profile-past-scores/1"
# Reviewed literal label sets from the retained tables, not a historical roster
# or a rule that Past Scores precede the selected page's Congress.
PROFILE_PAST_SCORE_PERIODS = {
    ("house", "118", "P000197"): (
        "119th",
        "117th",
        "116th",
        "115th",
        "114th",
        "113th",
        "112th",
        "111th",
        "110th",
        "109th",
        "108th",
        "107th",
        "106th",
        "105th and Prior",
    ),
    ("house", "119", "P000197"): (
        "118th",
        "117th",
        "116th",
        "115th",
        "114th",
        "113th",
        "112th",
        "111th",
        "110th",
        "109th",
        "108th",
        "107th",
        "106th",
        "105th and Prior",
    ),
    ("house", "119", "B001323"): (),
    ("senate", "119", "C001098"): ("118th", "117th", "116th", "115th", "114th", "113th"),
}


def profile_past_score_edition(chamber, congress, member_id):
    """One retained profile's literal Past Scores, with no single period implied."""
    profile = profile_vote_edition(chamber, congress, member_id)
    return ScorecardEdition(
        "agc",
        f"{congress}-{chamber}-profile-past-scores-{member_id}",
        profile.source_url,
        "Past Scores",
        is_current=False,
    )


def _profile_past_scores(document, member, selection):
    html, identity = _profile(document, member, selection[0])
    table = _one(html, "table#myTables")
    section = table.find_parent("section", class_="voting-record")
    if section is None or _text(_one(section, "h3")) != "Voting Record":
        raise ScorecardSourceError("AGC Past Scores left the Voting Record section")
    label = _one(section, 'a[href="#menu1"]')
    if _text(label) != "Past Scores" or label.get("data-toggle") != "tab":
        raise ScorecardSourceError("AGC Past Scores tab changed")
    tab = _one(section, "#menu1")
    responsive = _one(tab, "section.table-responsive")
    _layout(tab, ["section"])
    _layout(responsive, ["table"])
    if table.parent is not responsive:
        raise ScorecardSourceError("AGC Past Scores table left its labelled tab")
    _layout(table, ["thead", "tbody"])
    if [_text(h) for h in table.select("thead th")] != ["Congressional Session", "Session Score"]:
        raise ScorecardSourceError("AGC Past Scores columns changed")
    if table.select("caption, tfoot, [title], [aria-label], [data-tooltip], [hidden]"):
        raise ScorecardSourceError("AGC Past Scores exposes unreviewed notes")
    body = _one(table, "tbody")
    rows = body.find_all("tr", recursive=False)
    _layout(body, ["tr"] * len(rows))
    if len(table.select("tbody tr")) != len(rows):
        raise ScorecardSourceError("AGC Past Scores contains nested rows")
    scores, seen = [], set()
    for number, row in enumerate(rows, 1):
        _layout(row, ["td", "td"])
        cells = row.find_all("td", recursive=False)
        if row.attrs or any(cell.attrs or cell.find() for cell in cells):
            raise ScorecardSourceError("AGC Past Scores row shape changed")
        period, value = (_text(cell) for cell in cells)
        if period in seen or re.fullmatch(r"(?:100|[1-9]?\d)%", value) is None:
            raise ScorecardSourceError("AGC Past Scores repeats a session or changes its percentage syntax")
        seen.add(period)
        scores.append({"period": period, "value": value, "path": f"#myTables > tbody > tr:nth-of-type({number})"})
    if seen != set(PROFILE_PAST_SCORE_PERIODS[selection]):
        raise ScorecardSourceError("AGC Past Scores differs from its reviewed literal session set")
    return {**identity, "scores": scores}


def _acquire_profile_past_scores(selected, context):
    selection = next(
        selection for selection in PROFILE_VOTE_SELECTIONS if selected == profile_past_score_edition(*selection)
    )
    chamber, congress, member_id = selection
    documents = {}
    for label, url in (
        ("authority", INDEX),
        ("style", STYLE),
        ("members", _url("members", chamber, congress)),
        ("profile", selected.source_url),
    ):
        documents[label] = context.read(
            url, stage="scorecards:agc:profile-past-scores:" + label, hosts=(urlsplit(url).hostname,)
        )
    authority = _authority(documents["authority"])
    _name_display(documents["style"])
    members = _table(documents["members"], "members", chamber, congress)
    matches = [member for member in members["rows"] if member["url"] == selected.source_url]
    if len(matches) != 1:
        raise ScorecardSourceError("AGC Past Scores profile is absent or ambiguous in its native member index")
    member = matches[0]
    detail = _profile_past_scores(documents["profile"], member, selection)
    bundle = Bundle(
        selected,
        context,
        documents["profile"],
        publisher_name=NAME,
        parser_version=PROFILE_PAST_SCORE_PARSER_VERSION,
        homepage=HOMEPAGE,
        rendition_rule="One selected profile's complete literal Past Scores table, including a present empty table. Session labels define each rating period; the selected member-index Congress is provenance only. No historical membership, party, district, score weights or official identity is inferred.",
    )
    for label, document in documents.items():
        bundle.use(document, label)
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None,
        edition_label_text="Past Scores",
        source_path='section.voting-record:has(table#myTables) a[href="#menu1"]',
    )
    bundle.add(
        "scorecard_methodologies",
        documents["authority"],
        "#main .fusion-text",
        methodology_id="publisher-guide",
        methodology_text=json_column(authority),
        methodology_url=INDEX,
    )
    bundle.add(
        "scorecard_methodologies",
        documents["members"],
        member["path"],
        methodology_id="selected-profile-member-context",
        methodology_text=json_column({"selected_index_period": members["period"], "native_member_row": member}),
        disclosure_status="This index binds the selected profile identity. Its current party, chamber, district and Congress do not establish those facts for historical score periods.",
    )
    bundle.add(
        "scorecard_methodologies",
        documents["profile"],
        ".main-bio, section.voting-record:has(table#myTables)",
        methodology_id="selected-profile-past-scores",
        methodology_text=json_column(
            {
                "native_name": detail["name"],
                "native_affiliation_text": detail["affiliation"],
                "native_chamber_text": detail["chamber"],
                "tab": "Past Scores",
                "headers": ["Congressional Session", "Session Score"],
                "rows": [{"session": row["period"], "score": row["value"]} for row in detail["scores"]],
            }
        ),
        disclosure_status="One retained profile observation. Past Scores is a publisher tab label, not a rule that every session precedes the selected page. An empty table is not a zero score or evidence of no service. Mixed labels such as 105th and Prior stay unsplit; weights and metric participation remain unstated.",
    )
    member_key = key("profile", member_id)
    bundle.add(
        "scorecard_members",
        documents["profile"],
        ".main-bio h2",
        publisher_member_key=member_key,
        publisher_member_id=member_id,
        member_name=detail["name"],
        identifiers_json=json_column([{"scheme": "agc", "value": member_id}]),
    )
    for row in detail["scores"]:
        metric_id = key("session-score", row["period"])
        bundle.add(
            "scorecard_metrics",
            documents["profile"],
            row["path"] + " > td:nth-of-type(1)",
            metric_id=metric_id,
            methodology_id="selected-profile-past-scores",
            name="Session Score",
            period_text=row["period"],
            value_unit_text="%",
        )
        bundle.add(
            "scorecard_member_ratings",
            documents["profile"],
            row["path"] + " > td:nth-of-type(2)",
            metric_id=metric_id,
            publisher_member_key=member_key,
            value_text=row["value"],
            value_number=decimal_text(row["value"]),
        )
    return bundle.finish(
        "Complete labelled Past Scores table for one exact native member profile, with closed HTML, no pagination, exact columns and the reviewed unique literal session set. A present empty table is retained as empty. One original observation; no historical roster, complete member cohort, chronological interpretation of Past Scores, weights, sponsorships or current-availability claim."
    )


class AgcProfilePastScoreReader:
    """Named reader for the selected profiles' explicitly labelled session scores."""

    parser_version = PROFILE_PAST_SCORE_PARSER_VERSION

    def list_scorecards(self, context):
        return tuple(profile_past_score_edition(*selection) for selection in PROFILE_VOTE_SELECTIONS)

    def acquire_scorecard(self, selected, context):
        if selected not in self.list_scorecards(context):
            raise ScorecardSourceError("AGC named Past Scores reader requires an exact qualified selection")
        return _acquire_profile_past_scores(selected, context)


PROFILE_SPONSORSHIP_PARSER_VERSION = "agc-selected-profile-sponsorships/1"
# Retained table sizes, not publisher-declared counts or a legislative roster.
PROFILE_SPONSORSHIP_COUNTS = {
    ("house", "119", "P000197"): 11,
    ("house", "119", "B001323"): 11,
    ("senate", "119", "C001098"): 6,
}
PROFILE_SPONSORSHIP_TITLE = "Sponsorships and Co-sponsorships"
PROFILE_SPONSORSHIP_GUIDE = (
    "Below are the key AGC bills that the member has sponsored or co-sponsored. "
    "Click on any bill to learn more about the issue."
)


def profile_sponsorship_edition(chamber, congress, member_id):
    """One retained sponsorship table; the member query does not date its bills."""
    if (chamber, congress, member_id) not in PROFILE_SPONSORSHIP_COUNTS:
        raise ScorecardSourceError("AGC selected profile sponsorship table has not been qualified")
    return ScorecardEdition(
        "agc",
        f"{congress}-{chamber}-profile-sponsorships-{member_id}",
        f"{ORIGIN}/members-{chamber}/{member_id}?congress={congress}",
        PROFILE_SPONSORSHIP_TITLE,
        is_current=False,
    )


def _profile_sponsorships(document, member, selection):
    chamber = selection[0]
    html, identity = _profile(document, member, chamber)
    table = _one(html, "table#sponsorships")
    section = table.find_parent("section", class_="voting-record")
    if section is None:
        raise ScorecardSourceError("AGC sponsorship table left its labelled section")
    container = _one(section, "section.container")
    content = _one(container, "div.tab-content")
    home = _one(content, "#home")
    responsive = _one(home, "section.table-responsive")
    for node, children in (
        (section, ["section"]),
        (container, ["h3", "p", "div"]),
        (content, ["div"]),
        (home, ["section"]),
        (responsive, ["table"]),
        (table, ["thead", "tbody"]),
    ):
        _layout(node, children)
    if (
        table.parent is not responsive
        or _text(_one(section, "h3")) != PROFILE_SPONSORSHIP_TITLE
        or _text(_one(section, "p")) != PROFILE_SPONSORSHIP_GUIDE
        or [_text(h) for h in table.select("thead th")] != ["Bill", "Name", "AGC Position", "Sponsorship"]
        or table.select("caption, tfoot, [title], [aria-label], [data-tooltip], [hidden]")
    ):
        raise ScorecardSourceError("AGC sponsorship scope, columns or notes changed")
    rows = _one(table, "tbody").find_all("tr", recursive=False)
    _layout(_one(table, "tbody"), ["tr"] * len(rows))
    if len(rows) != PROFILE_SPONSORSHIP_COUNTS[selection] or len(table.select("tbody tr")) != len(rows):
        raise ScorecardSourceError("AGC sponsorship table differs from its reviewed complete population")
    items, seen = [], set()
    for number, row in enumerate(rows, 1):
        _layout(row, ["td"] * 4)
        cells = row.find_all("td", recursive=False)
        values = [_text(cell) for cell in cells]
        citation, title, position, action = values
        route = re.fullmatch(r"document\.location='([^']+)'", row.get("onclick", ""))
        bill = re.fullmatch(r"H\.R\. *(\d+)" if chamber == "house" else r"S\. *(\d+)", citation)
        prefix = "hr" if chamber == "house" else "s"
        if (
            route is None
            or bill is None
            or route[1] != f"{ORIGIN}/key-votes-{chamber}/{prefix}-{bill[1]}"
            or not title
            or position not in {"Support", "Oppose"}
            or action not in {"None", "Co-sponsor"}
            or row.attrs
            != {"class": ["noncurrent"], "scope": "row", "onclick": row.get("onclick"), "style": "cursor:pointer"}
            or any(cell.find() for cell in cells)
            or [cell.attrs for cell in cells]
            != [{}, {}, {"class": ["text-center", "bill-" + position.lower()]}, {"class": ["text-center"]}]
        ):
            raise ScorecardSourceError("AGC sponsorship identity, literal action or row shape changed")
        item_id = key("profile-sponsorship", route[1], citation, title)
        if item_id in seen:
            raise ScorecardSourceError("AGC sponsorship item is repeated")
        seen.add(item_id)
        items.append(
            {
                "id": item_id,
                "url": route[1],
                "values": values,
                "path": f"#sponsorships > tbody > tr:nth-of-type({number})",
            }
        )
    return {**identity, "items": items}


# Edition membership resolved once at import; acquisitions only dispatch.
_PROFILE_SPONSORSHIP_EDITIONS = tuple(
    profile_sponsorship_edition(*selection) for selection in PROFILE_SPONSORSHIP_COUNTS
)
_PROFILE_PAST_SCORE_EDITIONS = tuple(profile_past_score_edition(*selection) for selection in PROFILE_VOTE_SELECTIONS)
_PROFILE_VOTE_EDITIONS = tuple(profile_vote_edition(*selection) for selection in PROFILE_VOTE_SELECTIONS)


def _acquire_profile_sponsorships(selected, context):
    selection = next(
        selection for selection in PROFILE_SPONSORSHIP_COUNTS if selected == profile_sponsorship_edition(*selection)
    )
    chamber, congress, member_id = selection
    documents = {}
    for label, url in (
        ("authority", INDEX),
        ("style", STYLE),
        ("members", _url("members", chamber, congress)),
        ("profile", selected.source_url),
    ):
        documents[label] = context.read(
            url, stage="scorecards:agc:profile-sponsorships:" + label, hosts=(urlsplit(url).hostname,)
        )
    authority = _authority(documents["authority"])
    _name_display(documents["style"])
    members = _table(documents["members"], "members", chamber, congress)
    matches = [member for member in members["rows"] if member["url"] == selected.source_url]
    if len(matches) != 1:
        raise ScorecardSourceError("AGC sponsorship profile is absent or ambiguous in its native member index")
    member = matches[0]
    detail = _profile_sponsorships(documents["profile"], member, selection)
    bundle = Bundle(
        selected,
        context,
        documents["profile"],
        publisher_name=NAME,
        parser_version=PROFILE_SPONSORSHIP_PARSER_VERSION,
        homepage=HOMEPAGE,
        rendition_rule="One selected profile's complete literal sponsorship table. The member-index query identifies the profile, not the bills' Congress or action dates. One retained observation; no complete member cohort, official sponsorship comparison or current-availability claim.",
    )
    for label, document in documents.items():
        bundle.use(document, label)
    bundle.tables["scorecard_publishers"][0]["scorecard_index_url"] = INDEX
    bundle.tables["scorecards"][0].update(
        publisher_edition_key=None,
        edition_label_text=PROFILE_SPONSORSHIP_TITLE,
        source_path="section.voting-record:has(table#sponsorships) h3",
    )
    bundle.add(
        "scorecard_methodologies",
        documents["authority"],
        "#main .fusion-text",
        methodology_id="publisher-guide",
        methodology_text=json_column(authority),
        methodology_url=INDEX,
    )
    bundle.add(
        "scorecard_methodologies",
        documents["members"],
        member["path"],
        methodology_id="selected-profile-member-context",
        methodology_text=json_column({"selected_index_period": members["period"], "native_member_row": member}),
        disclosure_status="This index identifies the selected profile. Its current Congress, party, district and chamber do not date the sponsorship actions.",
    )
    bundle.add(
        "scorecard_methodologies",
        documents["profile"],
        ".main-bio, section.voting-record:has(table#sponsorships)",
        methodology_id="selected-profile-sponsorships",
        methodology_text=json_column(
            {
                "native_name": detail["name"],
                "native_affiliation_text": detail["affiliation"],
                "native_chamber_text": detail["chamber"],
                "explanation": PROFILE_SPONSORSHIP_GUIDE,
                "rows": detail["items"],
            }
        ),
        disclosure_status="Every literal None and Co-sponsor cell is retained despite the section's sponsored/co-sponsored explanation. None is not official evidence of absence. The section states no Congress or dates; linked details are not captured and item periods, official IDs, score weights and metric participation remain unknown.",
    )
    member_key = key("profile", member_id)
    bundle.add(
        "scorecard_members",
        documents["profile"],
        ".main-bio h2",
        publisher_member_key=member_key,
        publisher_member_id=member_id,
        member_name=detail["name"],
        identifiers_json=json_column([{"scheme": "agc", "value": member_id}]),
    )
    for item in detail["items"]:
        citation, title, position, action = item["values"]
        bundle.add(
            "scorecard_items",
            documents["profile"],
            item["path"],
            item_id=item["id"],
            item_kind_text=PROFILE_SPONSORSHIP_TITLE,
            title=title,
            bill_citation_text=citation,
            publisher_position_text=position,
            position_basis="explicit",
            position_source_path=item["path"] + " > td:nth-of-type(3)",
        )
        bundle.add(
            "scorecard_member_item_results",
            documents["profile"],
            item["path"] + " > td:nth-of-type(4)",
            item_id=item["id"],
            publisher_member_key=member_key,
            result_id="native-profile-sponsorship",
            action_text=action,
        )
    return bundle.finish(
        "Complete labelled Sponsorships and Co-sponsorships table for one exact retained member profile; closed HTML, no pagination, exact columns, reviewed table size and unique literal item identities. One original observation with unknown bill periods, not a complete member cohort or sponsorship history. Literal None is preserved; no official identifiers, metric participation, linked-detail coverage or current availability is inferred."
    )


class AgcProfileSponsorshipReader:
    """Named reader for the selected profiles' literal sponsorship tables."""

    parser_version = PROFILE_SPONSORSHIP_PARSER_VERSION

    def list_scorecards(self, context):
        return tuple(profile_sponsorship_edition(*selection) for selection in PROFILE_SPONSORSHIP_COUNTS)

    def acquire_scorecard(self, selected, context):
        if selected not in self.list_scorecards(context):
            raise ScorecardSourceError("AGC named sponsorship reader requires an exact qualified selection")
        return _acquire_profile_sponsorships(selected, context)
