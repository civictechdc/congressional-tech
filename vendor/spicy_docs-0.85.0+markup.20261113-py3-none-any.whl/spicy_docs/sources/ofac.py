"""Literal OFAC enhanced XML observations from one pinned official ZIP."""

from __future__ import annotations

import re
from datetime import datetime
from urllib.parse import urlsplit, urlunsplit
from zipfile import ZipFile

from spicy_docs.reading.xml import iter_xml_stream
from spicy_docs.reading.xml_observations import XmlObservationScan
from spicy_docs.reading.xml_tree import XmlTreeElement
from spicy_docs.reading.zip_archive import inspect_archive_stream, seekable_stream
from spicy_docs.transport.credentials import scrub_record

EXPORT_BASE = "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/"
NAMESPACE = EXPORT_BASE + "ENHANCED_XML"
MAX_ZIP_BYTES = 16 * 1024**2
MAX_XML_BYTES = 256 * 1024**2
MAX_RECORD_TEXT = 2 * 1024**2
MAX_RECORD_ELEMENTS = 20_000
MAX_RECORDS = 100_000
_LISTS = {
    "consolidated": ("CONS_ENHANCED", "91512", "Consolidated List"),
    "sdn": ("SDN_ENHANCED", "1550", "SDN List"),
}
_FILE_HOST = "wc2h-sls-prod-public-published.s3.us-gov-west-1.amazonaws.com"


class OfacError(ValueError):
    """The selected export cannot establish complete literal observations."""


def _selection(selected_list):
    if not isinstance(selected_list, str) or selected_list not in _LISTS:
        raise OfacError("OFAC requires the explicit sdn or consolidated list")
    return _LISTS[selected_list]


def validate_download_url(url, *, selected_list):
    """Validate every normal redirect without exposing its temporary query in errors."""
    stem, _, _ = _selection(selected_list)
    parts = urlsplit(url)
    if parts.scheme != "https" or parts.username or parts.password or parts.port not in (None, 443) or parts.fragment:
        raise OfacError("OFAC export URL shape differs")
    if url != EXPORT_BASE + stem + ".ZIP" and not (
        parts.hostname == _FILE_HOST
        and parts.path.startswith("/Published/")
        and parts.path.rsplit("/", 1)[-1] == stem + ".ZIP"
    ):
        raise OfacError("OFAC redirect is outside the selected official export")
    return url


def acquire_snapshot(acquirer, selected_list, *, store):
    """Use a BoundedAcquirer configured with validate_download_url for every hop."""
    stem, _, _ = _selection(selected_list)

    def prefix(chunk):
        if chunk[:4] != b"PK\x03\x04":
            raise OfacError("OFAC export is not a ZIP")

    result = acquirer.download(
        EXPORT_BASE + stem + ".ZIP", store=store, max_bytes=MAX_ZIP_BYTES, validate_prefix=prefix
    )
    # A temporary signed redirect is not a source locator. Retain its path only.
    response = result["response"]
    resolved = urlsplit(response["resolved_url"])
    return scrub_record(
        {
            **result,
            "response": {
                **response,
                "resolved_url": urlunsplit((resolved.scheme, resolved.netloc, resolved.path, "", "")),
            },
        }
    )


def ofac_scope(capture, selected_list):
    """Bind a selected list to original bytes and acquisition time, not a guessed publisher date."""
    stem, _, _ = _selection(selected_list)
    if (
        not isinstance(capture, dict)
        or set(capture) != {"request_url", "response_sha256", "observed_at", "byte_size"}
        or capture["request_url"] != EXPORT_BASE + stem + ".ZIP"
        or not isinstance(capture["response_sha256"], str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", capture["response_sha256"]) is None
        or type(capture["byte_size"]) is not int
        or not 0 < capture["byte_size"] <= MAX_ZIP_BYTES
    ):
        raise OfacError("OFAC capture identity differs")
    try:
        if datetime.fromisoformat(capture["observed_at"]).utcoffset() is None:
            raise ValueError
    except (TypeError, ValueError) as error:
        raise OfacError("OFAC capture requires a timestamp with timezone") from error
    return {"selected_list": selected_list, "capture": dict(capture), "member_name": stem + ".XML"}


def validate_scope(value):
    if not isinstance(value, dict) or set(value) != {"selected_list", "capture", "member_name"}:
        raise OfacError("OFAC scope fields differ")
    scope = ofac_scope(value["capture"], value["selected_list"])
    if scope != value:
        raise OfacError("OFAC member differs from the selected list")
    return scope


def _name(local):
    return f"{{{NAMESPACE}}}{local}"


def _tree_json(element):
    return {
        "name": element.name,
        "attributes": [list(pair) for pair in element.attributes],
        "namespace_declarations": [list(pair) for pair in element.namespace_declarations],
        "path": list(element.path),
        "content": [item if isinstance(item, str) else _tree_json(item) for item in element.content],
    }


class _RecordScan(XmlObservationScan):
    """Keep one subtree; the root and entities container are separate shallow observations."""

    def __init__(self, scope, member_digest):
        super().__init__(error_type=OfacError, label="OFAC enhanced XML", max_depth=64)
        self.scope, self.member_digest = scope, member_digest
        self.pending, self.frames, self.declarations = [], [], []
        self.ordinal = self.record_text = self.record_elements = 0
        self.seen_sections = set()
        self.entities_position = None

    def namespace(self, prefix, uri):
        self.declarations.append((prefix, uri))

    def _emit(self, element, kind):
        if self.ordinal >= MAX_RECORDS:
            raise OfacError("OFAC export exceeds max_records")
        entity_id = identity_id = None
        if kind == "entity":
            entity_id = element.attribute("id")
            identities = element.findall(_name("generalInfo"), _name("identityId"))
            if not entity_id or len(identities) != 1 or not identities[0].text:
                raise OfacError("OFAC entity or identity ID is missing or ambiguous")
            identity_id = identities[0].text
        self.pending.append(
            {
                "id": f"ofac:{self.scope['selected_list']}:{self.scope['capture']['response_sha256']}:{self.ordinal:020d}",
                "selected_list": self.scope["selected_list"],
                "kind": kind,
                "ordinal": self.ordinal,
                "entity_id": entity_id,
                "identity_id": identity_id,
                "element": _tree_json(element),
                "source_locator": {
                    **{key: self.scope["capture"][key] for key in ("request_url", "response_sha256", "observed_at")},
                    "member_name": self.scope["member_name"],
                    "member_sha256": self.member_digest,
                    "source_xpath": "".join(f"/*[{n}]" for n in element.path),
                },
            }
        )
        self.ordinal += 1

    def observe_start(self, tag, attributes):
        depth = len(self.stack)
        path = tuple(frame.position for frame in self.stack)
        shallow = depth == 1 or (depth == 2 and tag == _name("entities"))
        if depth == 1 and tag != _name("sanctionsData"):
            raise OfacError("OFAC enhanced root or namespace differs")
        if depth == 2 and tag in {_name("publicationInfo"), _name("referenceValues"), _name("entities")}:
            if tag in self.seen_sections:
                raise OfacError("OFAC repeats a required root section")
            if tag == _name("entities"):
                if _name("publicationInfo") not in self.seen_sections:
                    raise OfacError("OFAC publication identity must precede entities")
                self.entities_position = self.stack[-1].position
            self.seen_sections.add(tag)
        if shallow:
            self._emit(
                XmlTreeElement(tag, tuple(attributes.items()), tuple(self.declarations), path, ()),
                "root" if depth == 1 else "container",
            )
        else:
            if not self.frames:
                self.record_text = self.record_elements = 0
            self.record_elements += 1
            self.record_text += sum(len(k) + len(v) for k, v in attributes.items()) + len(tag)
            if self.record_elements > MAX_RECORD_ELEMENTS or self.record_text > MAX_RECORD_TEXT:
                raise OfacError("OFAC subtree exceeds its element or text bound")
            self.frames.append([tag, tuple(attributes.items()), tuple(self.declarations), path, []])
        self.declarations.clear()

    def observe_text(self, text):
        if self.frames:
            self.record_text += len(text)
            if self.record_text > MAX_RECORD_TEXT:
                raise OfacError("OFAC subtree exceeds its text bound")
            content = self.frames[-1][-1]
            if content and isinstance(content[-1], str):
                content[-1] += text
            else:
                content.append(text)
        elif text.strip():
            raise OfacError("OFAC has non-whitespace text outside a subtree")

    def observe_end(self, tag):
        depth = len(self.stack)
        if depth == 1 or (depth == 2 and tag == _name("entities")):
            return
        frame = self.frames.pop()
        element = XmlTreeElement(*frame[:-1], tuple(frame[-1]))
        if self.frames:
            self.frames[-1][-1].append(element)
            return
        if depth == 2 and tag == _name("publicationInfo"):
            _, ref_id, label = _selection(self.scope["selected_list"])
            filters = element.findall(_name("filters"))
            lists = element.findall(_name("filters"), _name("sanctionsLists"), _name("sanctionsList"))
            dates = element.findall(_name("dataAsOf"))
            if len(filters) != 1 or [child.name for child in filters[0].children] != [_name("sanctionsLists")]:
                raise OfacError("OFAC publication has additional or missing selection filters")
            if len(lists) != 1 or (lists[0].attribute("refId"), lists[0].text) != (ref_id, label):
                raise OfacError("OFAC publication filter differs from the selected list")
            if len(dates) != 1 or not dates[0].text:
                raise OfacError("OFAC publication dataAsOf is missing or ambiguous")
        if depth == 2:
            kind = "metadata"
        else:
            kind = "entity" if tag == _name("entity") else "extension"
        self._emit(element, kind)

    def finish(self):
        if self.seen_sections != {_name("publicationInfo"), _name("referenceValues"), _name("entities")}:
            raise OfacError("OFAC required root sections are missing")


def snapshot_records(stream, *, scope):
    """Verify every archive member, then stream complete source observations without extraction."""
    scope = validate_scope(scope)
    with seekable_stream(stream, byte_size=scope["capture"]["byte_size"]) as original:
        inventory = inspect_archive_stream(
            original,
            byte_size=scope["capture"]["byte_size"],
            max_entries=8,
            max_decoded_bytes=MAX_XML_BYTES,
            max_metadata_bytes=128 * 1024,
        )
        selected = [member for member in inventory["members"] if member["name"] == scope["member_name"]]
        if len(selected) != 1 or selected[0]["isDirectory"]:
            raise OfacError("OFAC selected XML member is missing or ambiguous")
        member = selected[0]
        with ZipFile(original) as archive, archive.open(archive.infolist()[member["ordinal"]]) as decoded:
            scan = _RecordScan(scope, member["sha256"])
            for _ in iter_xml_stream(
                decoded,
                start=scan.start,
                end=scan.end,
                data=scan.data,
                namespace=scan.namespace,
                max_bytes=MAX_XML_BYTES,
                error_type=OfacError,
                label="OFAC enhanced XML",
                max_depth=64,
            ):
                yield from scan.pending
                scan.pending.clear()
            scan.finish()
