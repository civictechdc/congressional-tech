"""House and Senate history pages: session dates and chamber party divisions, with effective dates.

Three official pages, each keyless and each one request (docs/sources/party-divisions.md):

- the House Historian's *List of all Sessions* (``HOUSE_SESSION_DATES_URL``): House sessions, beginning and
  adjournment dates, calendar and legislative days;
- the House Historian's *Party Divisions* (``HOUSE_PARTY_DIVISIONS_URL``): seats per party **as of the initial
  election results** of each Congress, so the House states one division per Congress and no mid-Congress change;
- the Senate Historical Office's *Party Division* (``SENATE_PARTY_DIVISION_URL``): per Congress, its term dates and
  majority, then per session the division, and a dated row for every change within a session.

Majority means the majority caucus, independents included (owner, 2026-10-31). The Senate page states it: each
session table lists the majority party first, which is how the 117th Congress reads Republicans first until
1/20/2021 and Democrats first after it while Republicans hold 50 seats to 48. The House page states seats only, so
its majority is the named party with more seats, except where its own footnote says another party organized the
House (the 72nd Congress); ``majority_basis`` says which rule applied, and ``house-seats-plurality`` marks a
Congress where that party held no more than half the seats, so the page alone cannot name the organizing caucus.

The readers are one linear pass of the stdlib ``HTMLParser`` per page; nothing here guesses a value a page leaves
blank (a blank Senate vacancy cell stays ``None``).
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date, timedelta
from html.parser import HTMLParser
from typing import TYPE_CHECKING

from spicy_docs.reading.markup import decode_html_page, feed_html
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_request_count,
    check_timing,
    named_challenge,
    narrow_byte_limit,
    utc_now,
)

if TYPE_CHECKING:
    from datetime import datetime

    import httpx

HOUSE_SESSION_DATES_URL = "https://history.house.gov/Institution/Session-Dates/All/"
HOUSE_PARTY_DIVISIONS_URL = "https://history.house.gov/Institution/Party-Divisions/Party-Divisions/"
SENATE_PARTY_DIVISION_URL = "https://www.senate.gov/about/parties-leadership/party-division.htm"
MEDIA_TYPES = ("text/html",)
# Measured 2026-10-31: session dates 236,089 bytes, House divisions 95,319, Senate division 701,400.
DEFAULT_MAX_BYTES = 4 * 1024**2
MAX_PAGE_BYTES = 16 * 1024**2

#: The Senate page's own cell vocabulary: one custom element per cell names its role.
_SENATE_ROLES = frozenset(
    {"date", "majority", "minority", "other", "vacancies", "total", "header", "party1", "party2", "other_party"}
)
_MONTHS = {
    m: i
    for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), start=1)
}
_LONG_DATE = re.compile(r"([A-Za-z]{3})[A-Za-z]*\.?\s*(\d{1,2}),\s*(\d{4})")
_SLASH_DATE = re.compile(r"(\d{1,2})/(\d{1,2})/(\d{4})")
_ORDINAL = re.compile(r"(\d+)(?:st|nd|rd|th)\b")
_SESSION_HEADER = re.compile(r"^(.*?)\s*session\s*\((.*)\)\s*$", re.IGNORECASE | re.DOTALL)
#: Session labels the Senate page spells in words; any other label keeps its own words, lowercased.
_WORD_ORDINALS = {"first": "1"}
#: Two party headers the Senate page spells unlike every other session of its era (visual review 2026-10-31):
#: "Pro-Admi" (truncated, 1st Congress era where every other header reads "Pro-Admin") and a singular
#: "Republican". The stated header stays on ``SenatePeriod``; ``PartyControl`` carries the era's spelling.
_PARTY_SPELLINGS = {"Pro-Admi": "Pro-Admin", "Republican": "Republicans"}
_HOUSE_ORGANIZED = re.compile(r"(Democrats|Republicans) organized with the majority")


class PartyDivisionError(ValueError):
    """A page cannot establish its sessions or divisions."""


class PartyDivisionUnavailableError(PartyDivisionError):
    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"history page answered HTTP {capture.status_code}")
        self.capture = capture


class PartyDivisionRefusedError(PartyDivisionError):
    """A keyless route answered 401/403 (the Senate host's bot wall answers 403); no credential exists to reject."""

    def __init__(self, url: str) -> None:
        super().__init__(f"history page refused access to {url}; no credential exists to reject")
        self.url = url


@dataclass
class _Cell:
    role: str | None = None
    text: str = ""
    sups: list[str] = field(default_factory=list)

    @property
    def value(self) -> str:
        return " ".join(self.text.split())


@dataclass
class _Row:
    classes: str
    cells: list[_Cell] = field(default_factory=list)
    footnotes: list[str] = field(default_factory=list)


class _Rows(HTMLParser):
    """Every ``<tr>`` in the order it closes, its cells' text apart from ``<sup>`` markers, and ``<footnote>`` paragraphs.

    Text lands in the innermost open row only, so a nested table's cells never leak into the row that holds it, and
    a row holding a nested table closes after the nested rows: the Senate page's fold row (sessions, then footnotes)
    follows its session rows.
    """

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[_Row] = []
        self._open: list[_Row] = []
        self._sup = 0
        self._footnote: _Row | None = None

    def _cell(self) -> _Cell | None:
        return self._open[-1].cells[-1] if self._open and self._open[-1].cells else None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "tr":
            self._open.append(_Row(dict(attrs).get("class") or ""))
        elif tag in ("td", "th") and self._open:
            self._open[-1].cells.append(_Cell())
        elif tag == "footnote" and self._open:
            self._footnote = self._open[-1]
            self._footnote.footnotes.append("")
        elif tag == "p" and self._footnote is not None:
            self._footnote.footnotes.append("")
        elif tag == "sup":
            self._sup += 1
            if (cell := self._cell()) is not None:
                cell.sups.append("")
        elif tag == "br":
            self.handle_data(" ")
        elif tag in _SENATE_ROLES and (cell := self._cell()) is not None and cell.role is None:
            cell.role = tag

    def handle_endtag(self, tag: str) -> None:
        if tag == "tr" and self._open:
            self.rows.append(self._open.pop())
        elif tag == "sup" and self._sup:
            self._sup -= 1
        elif tag == "footnote":
            self._footnote = None

    def close(self) -> None:
        super().close()
        while self._open:
            self.rows.append(self._open.pop())

    def handle_data(self, data: str) -> None:
        if self._footnote is not None:
            self._footnote.footnotes[-1] += data
        elif (cell := self._cell()) is not None:
            if self._sup and cell.sups:
                cell.sups[-1] += data
            else:
                cell.text += data


def _rows(body: bytes, max_bytes: int, label: str) -> list[_Row]:
    parser = _Rows()
    text = decode_html_page(body, max_bytes, label=label, cap=MAX_PAGE_BYTES, error_type=PartyDivisionError)
    feed_html(parser, text, label=label, error_type=PartyDivisionError)
    return parser.rows


def _long_date(text: str, label: str) -> date:
    match = _LONG_DATE.fullmatch(" ".join(text.split()))
    if match is None or match[1].lower() not in _MONTHS:
        raise PartyDivisionError(f"{label}: {text!r} is not a date")
    return date(int(match[3]), _MONTHS[match[1].lower()], int(match[2]))


def _slash_date(text: str, label: str) -> date:
    match = _SLASH_DATE.fullmatch(text.strip())
    if match is None:
        raise PartyDivisionError(f"{label}: {text!r} is not a M/D/YYYY date")
    return date(int(match[3]), int(match[1]), int(match[2]))


def _effective(stated: str, opens: date, label: str) -> date:
    """When a division row's state holds: the session's opening for a blank or ``--`` cell, else the last date stated.

    A cell can state two dates (``12/14/1819; 12/22/1819``) or a span (``6/23/1868–7/25/1868``) for changes the row
    shows together; the row's counts hold only once the last of them happened.
    """
    if stated.strip("- ") == "":
        return opens
    dates = _SLASH_DATE.findall(stated)
    if not dates or _SLASH_DATE.sub("", stated).strip(" ;–-") != "":
        raise PartyDivisionError(f"{label}: {stated!r} is not one or more M/D/YYYY dates")
    month, day, year = dates[-1]
    return date(int(year), int(month), int(day))


def _congress(text: str, label: str) -> int:
    match = _ORDINAL.match(text.strip())
    if match is None:
        raise PartyDivisionError(f"{label}: {text!r} names no Congress")
    return int(match[1])


def _count(text: str, label: str) -> int:
    match = re.match(r"(\d+)\b", text.strip())
    if match is None:
        raise PartyDivisionError(f"{label}: {text!r} is not a count")
    return int(match[1])


def _optional_int(text: str) -> int | None:
    return int(text) if text.isdigit() else None


def _footnote_text(footnotes: list[str]) -> tuple[str, ...]:
    """One entry per numbered note; the Senate page prints several in one paragraph, split by ``<br>``."""
    notes = (" ".join(note.split()) for note in footnotes)
    return tuple(part for note in notes if note for part in re.split(r"\s+(?=\d+\.\s)", note))


@dataclass(frozen=True, slots=True)
class Session:
    """One session as a chamber's history page states it; ``adjourned`` is ``None`` while it is open."""

    chamber: str
    congress: int
    #: "1", "2", ...; the Senate's other sessions keep their words: "special", "1 special", "1 (e)", "executive".
    session: str
    begins: date
    adjourned: date | None
    calendar_days: int | None = None
    legislative_days: int | None = None


@dataclass(frozen=True, slots=True)
class HouseDivision:
    """One Congress's row of the House page: the two named parties of its era in page order, seats as elected."""

    congress: int
    congress_label: str
    seats: int
    parties: tuple[tuple[str, int], tuple[str, int]]
    other: str
    delegates: str
    footnotes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class SenatePeriod:
    """One dated (or session-opening) division row: ``parties`` in the page's order, majority first."""

    session: str
    session_begins: date
    session_ends: date | None
    #: The date cell as printed (blank, ``--``, one date, two dates or a span); ``effective_from`` reads it.
    effective_stated: str
    effective_from: date
    parties: tuple[tuple[str, int], tuple[str, int]]
    other: str
    vacancies: int | None
    total: int


@dataclass(frozen=True, slots=True)
class SenateCongress:
    congress: int
    term_begins: date
    term_ends: date
    majority: str
    minority: str
    periods: tuple[SenatePeriod, ...]
    footnotes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class PartyControl:
    """One chamber's division from ``effective_from``.

    ``[effective_from, effective_to]`` is a closed interval of days: ``effective_to`` is the day before the next row
    of the same Congress and chamber takes effect, so within a Congress every day has exactly one row; the last row
    ends on the Congress's last day as the Senate page prints its term, and is ``None`` for the current Congress.
    Across Congresses the printed terms decide: since 1935 a term ends at noon on the day the next begins (both
    print January 3), so that one day belongs to both Congresses' last and first rows.
    """

    chamber: str
    congress: int
    effective_from: date
    effective_to: date | None
    majority_party: str
    majority_seats: int
    minority_party: str
    minority_seats: int
    other: str
    vacancies: int | None
    total_seats: int
    majority_basis: str
    source_url: str


def parse_house_session_dates(body: bytes, *, max_bytes: int = DEFAULT_MAX_BYTES) -> tuple[Session, ...]:
    """Every House session; a blank Congress cell continues the Congress above it."""
    label = "House session dates"
    sessions: list[Session] = []
    congress: int | None = None
    for row in _rows(body, max_bytes, label):
        cells = [cell.value for cell in row.cells]
        if len(cells) != 7 or cells[0] == "Congress":
            continue
        if cells[0]:
            congress = _congress(cells[0], label)
        if congress is None or not cells[1].isdigit():
            raise PartyDivisionError(f"{label}: row {cells[:3]} names no Congress and session")
        sessions.append(
            Session(
                "house",
                congress,
                cells[1],
                _long_date(cells[2], label),
                _long_date(cells[3], label) if cells[3] else None,
                _optional_int(cells[4]),
                _optional_int(cells[5]),
            )
        )
    if not sessions:
        raise PartyDivisionError(f"{label}: the page lists no session")
    return tuple(sessions)


def _house_footnote(footnotes: dict[str, str], mark: str, label: str) -> str:
    if mark not in footnotes:
        raise PartyDivisionError(f"{label}: footnote {mark!r} is marked but not printed")
    return footnotes[mark]


def parse_house_party_divisions(body: bytes, *, max_bytes: int = DEFAULT_MAX_BYTES) -> tuple[HouseDivision, ...]:
    """Every Congress row; each era's header row renames the two party columns that follow it."""
    label = "House party divisions"
    rows = _rows(body, max_bytes, label)
    parties: tuple[str, str] | None = None
    divisions: list[HouseDivision] = []
    footnotes: dict[str, str] = {}
    for paragraph in re.findall(r"<p><sup>(\d+)</sup>\s*(.*?)</p>", body.decode("utf-8"), flags=re.DOTALL):
        footnotes[paragraph[0]] = " ".join(re.sub(r"<[^>]+>", " ", paragraph[1]).split())
    for row in rows:
        cells = [cell.value for cell in row.cells]
        if len(cells) != 6:
            continue
        if cells[0] == "Congress (Years)":
            parties = (cells[2], cells[3])
            continue
        if parties is None:
            raise PartyDivisionError(f"{label}: a Congress row precedes its party header")
        marks = [mark.strip() for cell in row.cells for mark in cell.sups if mark.strip()]
        divisions.append(
            HouseDivision(
                _congress(cells[0], label),
                cells[0],
                _count(cells[1], label),
                ((parties[0], _count(cells[2], label)), (parties[1], _count(cells[3], label))),
                cells[4],
                cells[5],
                tuple(_house_footnote(footnotes, mark, label) for mark in marks),
            )
        )
    if not divisions:
        raise PartyDivisionError(f"{label}: the page lists no Congress")
    return tuple(divisions)


def _session_label(stated: str) -> str:
    """``1st`` -> ``1``, ``First`` -> ``1``, ``1st (E)`` -> ``1 (e)``, ``Special Executive`` -> ``special executive``."""
    words = [_WORD_ORDINALS.get(word.lower(), word.lower()) for word in stated.split()]
    return " ".join(re.sub(r"^(\d+)(?:st|nd|rd|th)$", r"\1", word) for word in words)


def _session_header(text: str, label: str) -> tuple[str, date, date | None]:
    match = _SESSION_HEADER.match(text)
    if match is None or not match[1].strip():
        raise PartyDivisionError(f"{label}: {text!r} is not a session header")
    dates = _SLASH_DATE.findall(match[2])
    if not dates or len(dates) > 2:
        raise PartyDivisionError(f"{label}: {text!r} does not state one session's dates")
    begins, *rest = (date(int(y), int(m), int(d)) for m, d, y in dates)
    return _session_label(match[1]), begins, (rest[0] if rest else None)


def parse_senate_party_division(body: bytes, *, max_bytes: int = DEFAULT_MAX_BYTES) -> tuple[SenateCongress, ...]:
    """Every Congress with its sessions' division rows, in page order."""
    label = "Senate party division"
    congresses: list[SenateCongress] = []
    head: dict[str, str] | None = None
    periods: list[SenatePeriod] = []
    session: tuple[str, date, date | None, tuple[str, str]] | None = None

    def close(footnotes: tuple[str, ...]) -> None:
        nonlocal head, periods
        if head is None:
            return
        term = _SLASH_DATE.findall(head["date"])
        if len(term) != 2 or not periods:
            raise PartyDivisionError(f"{label}: {head['date']!r} has no term dates or no session rows")
        (m1, d1, y1), (m2, d2, y2) = term
        congresses.append(
            SenateCongress(
                _congress(head["date"], label),
                date(int(y1), int(m1), int(d1)),
                date(int(y2), int(m2), int(d2)),
                head["majority"],
                head["minority"],
                tuple(periods),
                footnotes,
            )
        )
        head, periods = None, []

    for row in _rows(body, max_bytes, label):
        roles = {cell.role: cell for cell in row.cells if cell.role}
        if "majority" in roles:
            close(())
            head = {role: cell.value for role, cell in roles.items()}
        elif "header" in roles:
            headers = [cell.value for cell in row.cells if cell.role == "header"]
            number, begins, ends = _session_header(headers[0], label)
            session = (number, begins, ends, (headers[1], headers[2]))
        elif "party1" in roles:
            if session is None or head is None:
                raise PartyDivisionError(f"{label}: a division row precedes its session header")
            number, begins, ends, names = session
            stated = roles["date"].value if "date" in roles else ""
            vacancies = roles["vacancies"].value if "vacancies" in roles else ""
            periods.append(
                SenatePeriod(
                    number,
                    begins,
                    ends,
                    stated,
                    _effective(stated, begins, label),
                    (
                        (names[0], _count(roles["party1"].value, label)),
                        (names[1], _count(roles["party2"].value, label)),
                    ),
                    roles["other_party"].value if "other_party" in roles else "",
                    _count(vacancies, label) if vacancies else None,
                    _count(roles["total"].value, label),
                )
            )
        elif row.footnotes and head is not None:
            close(_footnote_text(row.footnotes))
        elif row.classes == "fold" and head is not None:
            close(())
    close(())
    if not congresses:
        raise PartyDivisionError(f"{label}: the page lists no Congress")
    return tuple(congresses)


def senate_sessions(congresses: tuple[SenateCongress, ...]) -> tuple[Session, ...]:
    """The Senate's sessions as its division page dates them; a session split by a change is one session."""
    sessions: list[Session] = []
    for congress in congresses:
        # A numbered session split by a change of majority (117th, 1st) is one session; an unnumbered one
        # ("special", "executive") is keyed by its opening date, since a Congress can hold several.
        spans: dict[tuple[str, date | None], tuple[date, date | None]] = {}
        for period in congress.periods:
            key = (period.session, None if period.session.isdigit() else period.session_begins)
            start, _ = spans.get(key, (period.session_begins, None))
            spans[key] = (min(start, period.session_begins), period.session_ends)
        sessions.extend(
            Session("senate", congress.congress, name, start, end) for (name, _), (start, end) in spans.items()
        )
    return tuple(sessions)


def _house_majority(division: HouseDivision) -> tuple[int, str]:
    """The index of the majority party and the rule that chose it."""
    for note in division.footnotes:
        if (organized := _HOUSE_ORGANIZED.search(note)) is not None:
            names = [name for name, _ in division.parties]
            if organized[1] in names:
                return names.index(organized[1]), "house-footnote-organized"
    (_, first), (_, second) = division.parties
    if first == second:
        raise PartyDivisionError(f"House party divisions: the {division.congress} Congress is tied and states no rule")
    index = 0 if first > second else 1
    # Below half the seats the larger party need not have organized the House (the 65th's Democrats did with 214 to
    # 215): the row says so rather than presenting a plurality as the majority caucus.
    absolute = 2 * division.parties[index][1] > division.seats
    return index, "house-seats-as-elected" if absolute else "house-seats-plurality"


def party_control(house: tuple[HouseDivision, ...], senate: tuple[SenateCongress, ...]) -> tuple[PartyControl, ...]:
    """One row per chamber per change of division, with effective dates.

    House rows run for the Congress's term (the Senate page states the term dates both chambers share); Senate rows
    start at each dated change or session opening and end the day before the next begins, and consecutive rows
    stating the same division are one row. The current row's ``effective_to`` is ``None``.
    """
    terms = {congress.congress: (congress.term_begins, congress.term_ends) for congress in senate}
    current = max(terms) if terms else None
    rows: list[PartyControl] = []
    for division in house:
        if division.congress not in terms:
            raise PartyDivisionError(f"no term dates for the {division.congress} Congress")
        index, basis = _house_majority(division)
        (major, major_seats), (minor, minor_seats) = division.parties[index], division.parties[1 - index]
        begins, ends = terms[division.congress]
        rows.append(
            PartyControl(
                "house",
                division.congress,
                begins,
                None if division.congress == current else ends,
                major,
                major_seats,
                minor,
                minor_seats,
                division.other,
                None,
                division.seats,
                basis,
                HOUSE_PARTY_DIVISIONS_URL,
            )
        )
    for congress in senate:
        periods = sorted(congress.periods, key=lambda period: period.effective_from)
        kept: list[SenatePeriod] = []
        for period in periods:
            if kept and (kept[-1].parties, kept[-1].other, kept[-1].vacancies, kept[-1].total) == (
                period.parties,
                period.other,
                period.vacancies,
                period.total,
            ):
                continue
            kept.append(period)
        for position, period in enumerate(kept):
            if position + 1 < len(kept):
                end = kept[position + 1].effective_from - timedelta(days=1)
            else:
                end = None if congress.congress == current else congress.term_ends
            (major, major_seats), (minor, minor_seats) = period.parties
            major, minor = _PARTY_SPELLINGS.get(major, major), _PARTY_SPELLINGS.get(minor, minor)
            rows.append(
                PartyControl(
                    "senate",
                    congress.congress,
                    period.effective_from,
                    end,
                    major,
                    major_seats,
                    minor,
                    minor_seats,
                    period.other,
                    period.vacancies,
                    period.total,
                    "senate-listed-first",
                    SENATE_PARTY_DIVISION_URL,
                )
            )
    return tuple(rows)


@dataclass(frozen=True, slots=True)
class PartyDivisionBudget:
    max_requests: int
    max_bytes: int
    timeout_seconds: float
    min_request_interval_seconds: float

    def __post_init__(self) -> None:
        check_request_count(self.max_requests)
        check_byte_bound(self.max_bytes, "max_bytes", MAX_PAGE_BYTES)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


@dataclass(frozen=True, slots=True)
class PageAcquisition[Parsed]:
    parsed: Parsed
    capture: CapturedBodyResponse
    request_count: int


class PartyDivisionAcquirer(SourceAcquirer):
    """Keyless capture of the three history pages, one request each, parsed before the capture is returned."""

    def __init__(
        self,
        *,
        budget: PartyDivisionBudget,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if not isinstance(budget, PartyDivisionBudget):
            raise TypeError("budget must be a PartyDivisionBudget")
        self._budget = budget
        super().__init__(
            max_requests=budget.max_requests,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-party-divisions/1.0",
            label="House / Senate history party divisions",
            error_type=PartyDivisionError,
            context_key="party_division_acquisition",
            transport=transport,
            clock=clock,
            keyless=True,
        )

    def _page[Parsed](
        self, url: str, operation: str, parse: Callable[..., Parsed], max_bytes: int | None
    ) -> PageAcquisition[Parsed]:
        limit = narrow_byte_limit(self._budget.max_bytes, max_bytes)
        with named_challenge(url, error_type=PartyDivisionRefusedError, context_key=self.context_key):
            parsed, capture = self.capture_validated(
                url,
                media_types=MEDIA_TYPES,
                parse=lambda response, bound: parse(response.body, max_bytes=bound),
                max_bytes=limit,
                unavailable=PartyDivisionUnavailableError,
                context={"operation": operation, "url": url},
            )
        return PageAcquisition(parsed, capture, self.request_count)

    def acquire_house_session_dates(self, *, max_bytes: int | None = None) -> PageAcquisition[tuple[Session, ...]]:
        return self._page(HOUSE_SESSION_DATES_URL, "house-session-dates", parse_house_session_dates, max_bytes)

    def acquire_house_divisions(self, *, max_bytes: int | None = None) -> PageAcquisition[tuple[HouseDivision, ...]]:
        return self._page(HOUSE_PARTY_DIVISIONS_URL, "house-party-divisions", parse_house_party_divisions, max_bytes)

    def acquire_senate_division(self, *, max_bytes: int | None = None) -> PageAcquisition[tuple[SenateCongress, ...]]:
        return self._page(SENATE_PARTY_DIVISION_URL, "senate-party-division", parse_senate_party_division, max_bytes)


__all__ = [
    "DEFAULT_MAX_BYTES",
    "HOUSE_PARTY_DIVISIONS_URL",
    "HOUSE_SESSION_DATES_URL",
    "MAX_PAGE_BYTES",
    "MEDIA_TYPES",
    "SENATE_PARTY_DIVISION_URL",
    "HouseDivision",
    "PageAcquisition",
    "PartyControl",
    "PartyDivisionAcquirer",
    "PartyDivisionBudget",
    "PartyDivisionError",
    "PartyDivisionRefusedError",
    "PartyDivisionUnavailableError",
    "SenateCongress",
    "SenatePeriod",
    "Session",
    "parse_house_party_divisions",
    "parse_house_session_dates",
    "parse_senate_party_division",
    "party_control",
    "senate_sessions",
]
