"""Actual full-report and part URLs from the Secretary of the Senate's index.

This reads one observed index, not a complete history. The source's date
headings, GovInfo package links and PDF anchors establish their relationships;
filenames do not establish reporting dates or whether a file is a full report.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING
from urllib.parse import urlsplit

from spicy_docs.reading.html_index import HtmlIndexReader, children, descendants, literal_text
from spicy_docs.reading.markup_structure import Elem
from spicy_docs.sources.disbursements_index import DisbursementsReportLink, read_report_period
from spicy_docs.sources.disbursements_reports import DisbursementsReportSourceError, disbursements_report_locator
from spicy_docs.sources.govinfo.bodies import GovInfoBodySourceError, parse_package_id
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_final_url,
    check_request_count,
    check_timing,
    utc_now,
)

if TYPE_CHECKING:
    import httpx

SOURCE_URL = "https://www.senate.gov/legislative/common/generic/report_secsen.htm"
MAX_INDEX_BYTES = 1024 * 1024
_TITLE = "Report of the Secretary of the Senate"
_LABEL = "Senate disbursements index"


class SenateDisbursementsSourceError(ValueError):
    """The selected Senate listing does not establish its expected source shape."""


class SenateDisbursementsUnavailableError(SenateDisbursementsSourceError):
    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"{_LABEL} is unavailable (HTTP {capture.status_code})")
        self.capture = capture


_HTML = HtmlIndexReader(_LABEL, SenateDisbursementsSourceError)
_KINDS = {"Full Report": ("full", None), "Part I": ("part", 1), "Part II": ("part", 2)}


@dataclass(frozen=True, slots=True)
class SenateDisbursementsIndex:
    index_url: str
    source_sha256: str
    byte_size: int
    links: tuple[DisbursementsReportLink, ...]


def _govinfo_path(anchor: Elem) -> tuple[str, str]:
    url = _HTML.resolve(anchor, SOURCE_URL)
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc != "www.govinfo.gov" or parsed.query or parsed.fragment:
        raise SenateDisbursementsSourceError(f"{_LABEL} lacks an official GovInfo link")
    return url, parsed.path


def _package_link(anchor: Elem) -> tuple[str, str]:
    url, path = _govinfo_path(anchor)
    match = re.fullmatch(r"/app/details/([^/]+)(?:/([^/]+)/context)?", path)
    if match is None:
        raise SenateDisbursementsSourceError(f"{_LABEL} report heading lacks a GovInfo package link")
    package = match[1]
    try:
        identity = parse_package_id(package)
    except GovInfoBodySourceError as error:
        raise SenateDisbursementsSourceError(f"{_LABEL} has an invalid package identity") from error
    if identity.collection != "GPO-CDOC" or identity.document_type != "sdoc":
        raise SenateDisbursementsSourceError(f"{_LABEL} package is not a Senate document")
    if match[2] is not None and not re.fullmatch(re.escape(package) + r"-\d+", match[2]):
        raise SenateDisbursementsSourceError(f"{_LABEL} heading names a conflicting package granule")
    return url, package


def _pdf_link(anchor: Elem, package: str) -> str:
    url, _ = _govinfo_path(anchor)
    try:
        locator = disbursements_report_locator(url)
    except DisbursementsReportSourceError as error:
        raise SenateDisbursementsSourceError(f"{_LABEL} PDF conflicts with its stated report package") from error
    if locator.package_id != package:
        raise SenateDisbursementsSourceError(f"{_LABEL} PDF conflicts with its stated report package")
    return url


def parse_senate_disbursements_index(body: bytes, *, max_bytes: int = MAX_INDEX_BYTES) -> SenateDisbursementsIndex:
    """Read source-located PDF observations and literal date intervals offline.

    The publisher's retained page has broken footer markup outside its content.
    Only its explicit title, heading and ``full_story`` elements are folded;
    their grouping stays strict. Paths start at those elements, while byte
    coordinates address the complete original. All PDF anchors in the story
    must be consumed by a heading and its immediately following file group.
    """
    root = _HTML.tree(body, max_bytes, scopes=frozenset({"title", "h1", "full_story"}))
    title = _HTML.only(children(root, "title"), "page title")
    heading = _HTML.only(children(root, "h1"), "page heading")
    if _HTML.normal(_HTML.field(title)) != "U.S. Senate: " + _TITLE or _HTML.normal(_HTML.field(heading)) != _TITLE:
        raise SenateDisbursementsSourceError(f"{_LABEL} does not state the selected page identity")
    story = _HTML.only(children(root, "full_story"), "report story")
    if any(node.name in {"script", "iframe", "form"} for node in descendants(story)):
        raise SenateDisbursementsSourceError(f"{_LABEL} has an unexpected active report story")
    text = literal_text(story)
    if "semiannual" not in text or "Government Publishing Office" not in text:
        raise SenateDisbursementsSourceError(f"{_LABEL} lacks its report introduction")
    elements = [part for part in story.parts if isinstance(part, Elem)]
    links: list[DisbursementsReportLink] = []
    seen: dict[str, DisbursementsReportLink] = {}
    consumed: set[str] = set()
    group_number = 0
    for position, element in enumerate(elements):
        if element.name != "p" or "contentsubtitle" not in (element.attributes.get("class") or "").split():
            continue
        group_number += 1
        report = _HTML.only(list(descendants(element, "a")), "package anchor per report heading")
        report_url, package = _package_link(report)
        report_label, report_context = _HTML.field(report), _HTML.field(element)
        period = read_report_period(report_context, chamber="senate")
        if position + 1 >= len(elements) or elements[position + 1].name != "div":
            raise SenateDisbursementsSourceError(f"{_LABEL} report heading lacks its following file group")
        group = elements[position + 1]
        observed = set()
        for anchor in descendants(group, "a"):
            kind = _KINDS.get(_HTML.normal(_HTML.field(anchor)))
            if kind is None:
                raise SenateDisbursementsSourceError(f"{_LABEL} has an unsupported PDF link label")
            role, part = kind
            observed.add(kind)
            url = _pdf_link(anchor, package)
            prior = seen.get(url)
            if prior is not None and (prior.report_context, prior.package_id) != (report_context, package):
                raise SenateDisbursementsSourceError(f"{_LABEL} assigns one PDF to conflicting report contexts")
            link = DisbursementsReportLink(
                len(links) + 1,
                group_number,
                role,
                url,
                anchor.attributes.get("href") or "",
                _HTML.field(anchor),
                report_label,
                report_context,
                report_url,
                _HTML.field(group),
                anchor.path,
                anchor.byte_start,
                anchor.byte_end,
                period.period_start,
                period.period_end,
                period.period_issues,
                part_number=part,
                package_id=package,
                duplicate_of=prior.link_number if prior else None,
            )
            links.append(link)
            seen.setdefault(url, link)
            consumed.add(anchor.path)
        if observed != set(_KINDS.values()):
            raise SenateDisbursementsSourceError(f"{_LABEL} lacks a full report or advertised part")
    candidates = {node.path for node in descendants(story, "a") if _HTML.file_suffix(node, ".pdf")}
    if not links or consumed != candidates:
        raise SenateDisbursementsSourceError(f"{_LABEL} has empty or ungrouped PDF links")
    return SenateDisbursementsIndex(SOURCE_URL, "sha256:" + hashlib.sha256(body).hexdigest(), len(body), tuple(links))


@dataclass(frozen=True, slots=True)
class SenateDisbursementsIndexBudget:
    max_bytes: int = MAX_INDEX_BYTES
    max_requests: int = 3
    timeout_seconds: float = 45.0
    min_request_interval_seconds: float = 0.5

    def __post_init__(self) -> None:
        check_byte_bound(self.max_bytes, "max_bytes", MAX_INDEX_BYTES)
        check_request_count(self.max_requests)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


@dataclass(frozen=True, slots=True)
class SenateDisbursementsIndexAcquisition:
    index: SenateDisbursementsIndex
    capture: CapturedBodyResponse
    transport: str = "direct"
    provider_request_id: str | None = None


_DEFAULT_BUDGET = SenateDisbursementsIndexBudget()


class SenateDisbursementsIndexAcquirer(SourceAcquirer):
    """One page through the shared direct client or explicit public-site recovery."""

    def __init__(
        self,
        *,
        budget: SenateDisbursementsIndexBudget = _DEFAULT_BUDGET,
        recover_walls: bool = False,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if not isinstance(budget, SenateDisbursementsIndexBudget):
            raise TypeError("budget must be a SenateDisbursementsIndexBudget")
        if not isinstance(recover_walls, bool):
            raise TypeError("recover_walls must be a bool")
        self.budget = budget
        self.recover_walls = recover_walls
        super().__init__(
            max_requests=budget.max_requests,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-senate-disbursements/1.0",
            label=_LABEL,
            error_type=SenateDisbursementsSourceError,
            context_key="senate_disbursements_acquisition",
            keyless=True,
            transport=transport,
            clock=clock,
        )

    def acquire_index(self) -> SenateDisbursementsIndexAcquisition:
        """Capture the selected index only; following report URLs is a separate operation."""

        def parse(capture: CapturedBodyResponse, limit: int) -> SenateDisbursementsIndex:
            if capture.status_code != 200:
                raise SenateDisbursementsSourceError(f"{_LABEL} answered HTTP {capture.status_code}")
            check_final_url(
                capture.resolved_url,
                SOURCE_URL,
                error_type=SenateDisbursementsSourceError,
                message="Senate disbursements index final URL differs from the selected page",
            )
            return parse_senate_disbursements_index(capture.body, max_bytes=limit)

        request = {
            "media_types": ("text/html",),
            "parse": parse,
            "max_bytes": self.budget.max_bytes,
            "unavailable": SenateDisbursementsUnavailableError,
            "context": {"operation": "index", "url": SOURCE_URL},
        }
        if self.recover_walls:
            index, capture, answer = self.capture_walled(
                SOURCE_URL,
                **request,
                publisher_page=lambda body: _TITLE.encode() in body and b"GPO-CDOC-" in body,
            )
            return SenateDisbursementsIndexAcquisition(index, capture, answer.transport, answer.request_id)
        index, capture = self.capture_validated(SOURCE_URL, **request)
        return SenateDisbursementsIndexAcquisition(index, capture)
