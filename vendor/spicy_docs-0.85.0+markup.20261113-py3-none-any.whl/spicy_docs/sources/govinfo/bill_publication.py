"""Literal BILLS date evidence; package identity does not prove a body-version date."""

from __future__ import annotations

import re
from datetime import datetime

from spicy_docs.reading.json_input import load_decimal_json
from spicy_docs.sources.govinfo.bodies import (
    PACKAGE_BODY_FORMATS,
    GovInfoBodySourceError,
    package_body_locator,
    package_mods_locator,
    package_summary_locator,
    parse_package_id,
    validate_package_mods,
    validate_package_summary,
)
from spicy_docs.sources.govinfo.mods import RETAINED_MODS_MAX_ELEMENTS, parse_govinfo_mods
from spicy_docs.transport.captured import CapturedBodyResponse

PUBLICATION_LIMIT = (
    "Native issue, metadata-update and ingest dates are separate facts. Separate requests prove the same "
    "printing identity, not a common metadata/body snapshot or first online availability. No publication "
    "event or first-online time is inferred."
)
_MODS_DATES = (
    ("originInfo", "dateIssued"),
    ("originInfo", "dateCreated"),
    ("originInfo", "dateCaptured"),
    ("originInfo", "dateOther"),
    ("originInfo", "copyrightDate"),
    ("recordInfo", "recordCreationDate"),
    ("recordInfo", "recordChangeDate"),
    ("extension", "dateIngested"),
)


def _precision(value: str | None) -> str | None:
    if value is None:
        return None
    for pattern, name in (
        (r"\d{4}", "year"),
        (r"\d{4}-\d{2}", "month"),
        (r"\d{4}-\d{2}-\d{2}", "day"),
        (r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})?", "second"),
    ):
        if re.fullmatch(pattern, value):
            return name
    return "empty" if value == "" else "source_lexical"


def _capture(capture: CapturedBodyResponse) -> dict:
    return {
        "requested_url": capture.requested_url,
        "resolved_url": capture.resolved_url,
        "sha256": capture.sha256,
        "byte_size": capture.byte_size,
        "observed_at": capture.observed_at,
    }


def _instant(capture: CapturedBodyResponse) -> datetime:
    instant = datetime.fromisoformat(capture.observed_at)
    if instant.tzinfo is None:
        raise GovInfoBodySourceError("Bill metadata capture observation must include a timezone")
    return instant


def bill_publication_evidence(
    package_id: str,
    *,
    body_sha256: str,
    body_url: str,
    body_observed_at: str | None,
    summary_capture: CapturedBodyResponse,
    mods_capture: CapturedBodyResponse,
    closing_summary_capture: CapturedBodyResponse | None = None,
    max_metadata_bytes: int = 4 * 1024 * 1024,
) -> dict:
    """Read retained metadata for an exact printing without opening or extracting its body.

    The body digest and locator come from the already qualified version row.
    Even equal bracketing summaries cannot prove that MODS or body bytes were
    frozen together. A changed bracket is explicit and is never admitted by
    the metadata-only enrichment writer as a replacement for selected evidence.
    """
    identity = parse_package_id(package_id)
    if identity.collection != "BILLS":
        raise GovInfoBodySourceError("Bill publication evidence requires a BILLS printing")
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", body_sha256) or body_url not in {
        package_body_locator(identity, name) for name in PACKAGE_BODY_FORMATS
    }:
        raise GovInfoBodySourceError("Bill publication evidence body identity differs from the printing")
    captures = [summary_capture, mods_capture]
    if closing_summary_capture is not None:
        captures.append(closing_summary_capture)
    if any(capture.status_code != 200 for capture in captures):
        raise GovInfoBodySourceError("Bill publication evidence requires successful metadata captures")
    expected = [package_summary_locator(identity), package_mods_locator(identity), package_summary_locator(identity)]
    if any(capture.requested_url != locator for capture, locator in zip(captures, expected)):
        raise GovInfoBodySourceError("Bill metadata request differs from the printing")
    observations = [_instant(capture) for capture in captures]
    if closing_summary_capture is not None and not observations[0] <= observations[1] <= observations[2]:
        raise GovInfoBodySourceError("Bill metadata capture observations do not bracket MODS")
    summary = validate_package_summary(
        summary_capture.body, package=identity, final_url=summary_capture.resolved_url, max_bytes=max_metadata_bytes
    )
    validate_package_mods(
        mods_capture.body, package=identity, final_url=mods_capture.resolved_url, max_bytes=max_metadata_bytes
    )
    raw = load_decimal_json(summary_capture.body, source="BILLS summary", error_type=GovInfoBodySourceError)
    if not isinstance(raw, dict):
        raise GovInfoBodySourceError("BILLS summary is not an object")
    dates = []
    for field in ("dateIssued", "lastModified"):
        value = raw.get(field)
        if value is not None and not isinstance(value, str):
            raise GovInfoBodySourceError(f"BILLS summary {field} is not text or null")
        dates.append(
            {
                "field": "SUMMARY/" + field,
                "value": value,
                "state": "missing"
                if field not in raw
                else "null"
                if value is None
                else "empty"
                if value == ""
                else "value",
                "precision": _precision(value),
                "attributes": [],
                "locator": "/" + field,
                "source_sha256": summary_capture.sha256,
                "source_url": summary_capture.resolved_url,
                "observed_at": summary_capture.observed_at,
            }
        )
    mapped = parse_govinfo_mods(
        mods_capture.body, max_bytes=max_metadata_bytes, max_elements=RETAINED_MODS_MAX_ELEMENTS
    )
    for path in _MODS_DATES:
        for element in mapped.package.fields(*path):
            value = element.text
            dates.append(
                {
                    "field": "MODS/" + "/".join(path),
                    "value": value,
                    "state": "empty" if value == "" else "value",
                    "precision": _precision(value),
                    "attributes": [{"name": name, "value": value} for name, value in element.attributes],
                    "locator": "element-child-path:" + "/".join(map(str, element.path)),
                    "source_sha256": mods_capture.sha256,
                    "source_url": mods_capture.resolved_url,
                    "observed_at": mods_capture.observed_at,
                }
            )
    status = "separate_requests_unverified"
    if closing_summary_capture is not None:
        closing = validate_package_summary(
            closing_summary_capture.body,
            package=identity,
            final_url=closing_summary_capture.resolved_url,
            max_bytes=max_metadata_bytes,
        )
        # Byte equality protects more than the update clock: a publisher may
        # change metadata without moving that clock.
        status = (
            "summary_changed_during_acquisition"
            if summary_capture.sha256 != closing_summary_capture.sha256
            else "stable_summary_bracket_body_unverified"
        )
        if closing.last_modified != summary.last_modified:
            status = "summary_changed_during_acquisition"
    return {
        "status": status,
        "dates": dates,
        "evidence": {
            "package_id": package_id,
            "body_sha256": body_sha256,
            "body_url": body_url,
            "body_observed_at": body_observed_at,
            "captures": [_capture(capture) for capture in captures],
            "observed_at": max(captures, key=_instant).observed_at,
            "limit": PUBLICATION_LIMIT,
        },
    }
