"""Associate retained House OCR readings with measured source rows.

The caller retains originals, supplies correctly oriented rasters and runs its
chosen maintained extraction backends. Model text stays unplaced: this reader
links it to measured observations, preserving ties, disagreements and unread
rows. It never promotes an embedded OCR layer to native financial text.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from statistics import median

from spicy_docs.extraction import Box, Raster
from spicy_docs.extraction.model import Observation, Recognition
from spicy_docs.extraction.pages import crop
from spicy_docs.reading.house_disbursements_pdf import _clean
from spicy_docs.reading.ocr_observations import (
    OcrRegion as HouseOcrRegion,
)
from spicy_docs.reading.ocr_observations import (
    OcrView as HouseOcrView,
)
from spicy_docs.reading.ocr_observations import (
    box_coordinates as _coords,
)
from spicy_docs.reading.ocr_observations import (
    evidence_sha256 as _sha,
)
from spicy_docs.reading.ocr_observations import (
    validate_view_image,
)
from spicy_docs.reading.pdf_grid import visual_lines

RULE = "house-disbursement-ocr-page/2"
# Measured on pinned 2008 pages; see the source guide's bounded OCR evidence.
DEFAULT_MAX_REGION_PIXELS = 2_620_620
_NUMERIC = re.compile(r"-?\d[\d,. ]*\d\Z")
_POSTED = re.compile(r"\d{2}[-–]\d{2}(?:\s|$)")
_SERVICE = re.compile(r"\d{2}/\d{2}/\d{2}")
_AMOUNT = r"-?(?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2}"
_TAIL = re.compile(rf"((?:\s+{_AMOUNT}){{1,2}})\s*$")
_DETAIL = re.compile(
    r"^(\d{2}-\d{2})\s+([A-Z0-9]{2})\s+(\S+)\s*(.*?)\s+"
    r"(\d{2}/\d{2}/\d{2})\s+(\d{2}/\d{2}/\d{2})\s+(.*?)\s*$"
)
LITERAL_FIELDS = (
    "posting_date_literal",
    "data_source_literal",
    "voucher_literal",
    "payee_literal",
    "service_start_literal",
    "service_end_literal",
    "description_literal",
)
_CATEGORIES = {
    "TRAVEL",
    "RENT, COMMUNICATION, UTILITIES",
    "PRINTING AND REPRODUCTION",
    "OTHER SERVICES",
    "SUPPLIES AND MATERIALS",
    "EQUIPMENT",
    "PERSONNEL COMPENSATION",
    "PERSONNEL BENEFITS",
}


def _box(words):
    return Box(
        min(w["bbox"][0] for w in words),
        min(w["bbox"][1] for w in words),
        max(w["bbox"][2] for w in words),
        max(w["bbox"][3] for w in words),
    )


@dataclass(frozen=True)
class HouseOcrPlan:
    source_sha256: str
    source_page: int
    image: Raster
    geometry: Recognition | Observation
    lines: tuple[dict, ...]
    rows: tuple[dict, ...]
    columns: tuple[dict, ...]
    regions: tuple[HouseOcrRegion, ...]
    issues: tuple[str, ...]

    @property
    def image_sha256(self):
        return _sha(self.image.data)


def _grown_crop(image, box, words, max_pixels):
    # Pixel rounding and overlapping OCR boxes can expose a neighboring line.
    # Grow to complete measured blocks; any extra financial rows remain outside
    # the region's explicit selected row IDs and are not counted twice.
    while True:
        raster = crop(image, box)
        touched = [
            w for w in words if raster.box.intersects(Box(*w["bbox"])) and not raster.box.contains(Box(*w["bbox"]))
        ]
        if not touched:
            break
        for word in touched:
            box = box.union(Box(*word["bbox"]))
    if raster.width * raster.height > max_pixels:
        raise ValueError("Complete observed rows exceed the admitted OCR region size")
    return raster


def plan_house_disbursements_ocr(
    image: Raster,
    geometry: Recognition | Observation,
    *,
    source_sha256: str,
    source_page: int,
    max_region_pixels: int = DEFAULT_MAX_REGION_PIXELS,
) -> HouseOcrPlan:
    """Select source-layout bands from a full-page positioned OCR observation.

    Does not recognize, rotate, fetch or publish. Missing headers stay explicit;
    an unsupported layout raises instead of reporting an empty financial page.
    """
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", source_sha256) or source_page < 1:
        raise ValueError("An exact original SHA256 and positive physical page are required")
    if image.box != Box() or max_region_pixels < 1:
        raise ValueError("Supply a complete oriented page and a positive region pixel bound")
    words = []
    for index, block in enumerate(geometry.blocks, 1):
        if block.box is None:
            raise ValueError("House OCR layout requires measured text boxes")
        box = block.box
        words.append(
            {
                "index": index,
                "text": block.text,
                "bbox": _coords(box),
                "x": (box.x0 + box.x1) / 2,
                "y": (box.y0 + box.y1) / 2,
            }
        )
    if not words:
        raise ValueError("No positioned observations; financial content is unread")
    height = median(w["bbox"][3] - w["bbox"][1] for w in words)
    lines = [
        {"id": f"line-{n}", "blocks": group, "box": _coords(_box(group))}
        for n, group in enumerate(visual_lines(words, tolerance=height * 0.45), 1)
    ]
    description = [w for w in words if w["text"] == "DESCRIPTION"]
    money_header = [w for w in words if "YTD AMOUNT" in w["text"] and "QUARTERLY AMOUNT" in w["text"]]
    dates = [w for w in words if _SERVICE.fullmatch(w["text"])]
    if len(description) == 1:
        left = description[0]["bbox"][2]
    elif dates:
        left = max(w["bbox"][2] for w in dates)
    else:
        raise ValueError("No observed description header or service-date landmark")
    numeric = [
        w
        for w in words
        if w["bbox"][0] > left and _NUMERIC.fullmatch(w["text"]) and len(re.sub(r"\D", "", w["text"])) >= 3
    ]
    clusters = []
    for word in sorted(numeric, key=lambda w: w["bbox"][2]):
        if not clusters or word["bbox"][2] - clusters[-1][-1]["bbox"][2] > height * 0.75:
            clusters.append([])
        clusters[-1].append(word)
    clusters = [group for group in clusters if len(group) >= 3]
    if not 1 <= len(clusters) <= 2:
        raise ValueError("Unsupported observed money-column layout")
    roles = (
        ("ytd_amount", "quarterly_amount")
        if len(clusters) == 2 and len(money_header) == 1
        else ("unqualified_amount",) * len(clusters)
    )
    columns = tuple(
        {
            "role": role,
            "right_edge": median(w["bbox"][2] for w in group),
            "observation_indices": [w["index"] for w in group],
            "header_observation_indices": [w["index"] for w in money_header],
        }
        for role, group in zip(roles, clusters)
    )
    indexes = {index: n for n, col in enumerate(columns) for index in col["observation_indices"]}
    rows = []
    for line in lines:
        values = [w for w in line["blocks"] if w["index"] in indexes]
        if not values:
            continue
        if len({indexes[w["index"]] for w in values}) != len(values):
            raise ValueError("Several money observations occupy one source row and column")
        label = " ".join(w["text"] for w in line["blocks"] if w not in values)
        detail = any(_POSTED.match(w["text"]) for w in line["blocks"])
        kind = (
            "detail"
            if detail
            else ("summary" if len(values) == 2 else ("total" if "TOTAL" in label else "unclassified_financial"))
        )
        rows.append(
            {
                **line,
                "kind": kind,
                "label_or_row_literal": label,
                "money": [
                    {
                        "text": w["text"],
                        "block_index": w["index"],
                        "column": indexes[w["index"]],
                        "role": columns[indexes[w["index"]]]["role"],
                        "measured_box": w["bbox"],
                    }
                    for w in values
                ],
            }
        )
    if not rows:
        raise ValueError("No measured financial rows; source content remains unread")
    row_ids = {r["id"] for r in rows}
    if image.width * image.height <= max_region_pixels:
        regions = [HouseOcrRegion("full", image, tuple(r["id"] for r in rows))]
    else:
        first = next(i for i, line in enumerate(lines) if line["id"] in row_ids)
        header_bottom = max(
            (
                w["bbox"][3]
                for w in words
                if w["text"] in ("DATE", "DESCRIPTION", "PAYEE", "SERVICE DATES", "VOUCHER NO.") or w in money_header
            ),
            default=0,
        )
        leading = [line for line in lines[:first] if line["box"][1] > header_bottom]
        groups, pending, current = [], leading, []
        for line in lines[first:]:
            if line["id"] in row_ids:
                if pending and current:
                    groups.append(current)
                    current = []
                current.extend(pending)
                pending = []
                current.append(line)
            else:
                pending.append(line)
        if current:
            groups.append(current)
        table = _box(
            [w for row in rows for w in row["blocks"] if w["text"] != "E"]
            + [w for line in leading for w in line["blocks"]]
        )
        margin = height * image.height / image.width * 0.25
        x0, x1 = max(0, table.x0 - margin), min(1, table.x1 + margin)
        regions = []
        for group in groups:
            chunks, current = [], []
            for line in group:
                y0 = (current or [line])[0]["box"][1] - height * 0.22
                y1 = line["box"][3] + height * 0.22
                if current and (x1 - x0) * image.width * (y1 - y0) * image.height > max_region_pixels:
                    chunks.append(current)
                    current = []
                current.append(line)
            if current:
                chunks.append(current)
            for chunk in chunks:
                selected = tuple(line["id"] for line in chunk if line["id"] in row_ids)
                if not selected:
                    raise ValueError("Capacity split separated context from all financial rows")
                start, end = lines.index(chunk[0]), lines.index(chunk[-1])
                before = max((line["box"][3] for line in lines[:start]), default=0)
                after = min((line["box"][1] for line in lines[end + 1 :]), default=1)
                top = chunk[0]["box"][1] - min(height * 0.22, max(0, chunk[0]["box"][1] - before) * 0.4)
                bottom = chunk[-1]["box"][3] + min(height * 0.22, max(0, after - chunk[-1]["box"][3]) * 0.4)
                raster = _grown_crop(image, Box(x0, max(0, top), x1, min(1, bottom)), words, max_region_pixels)
                regions.append(HouseOcrRegion(f"band-{len(regions) + 1:02d}", raster, selected))
    if len(regions) > 64:
        raise ValueError("House OCR page exceeds the bounded region selection")
    issues = () if len(money_header) == 1 else ("source_amount_column_header_unread",)
    return HouseOcrPlan(
        source_sha256, source_page, image, geometry, tuple(lines), tuple(rows), columns, tuple(regions), issues
    )


def house_ocr_witness_region(plan: HouseOcrPlan, row_id: str, *, block_index: int | None = None) -> HouseOcrRegion:
    """Crop one observed row or field; refuse a second money occurrence in a row crop."""
    row = next((r for r in plan.rows if r["id"] == row_id), None)
    if row is None:
        raise ValueError("Unknown observed House row")
    selected = [w for w in row["blocks"] if block_index is None or w["index"] == block_index]
    if not selected:
        raise ValueError("Field observation does not belong to the selected row")
    box, image = _box(selected), plan.image
    requested = Box(
        max(0, box.x0 - 2 / image.width),
        max(0, box.y0 - 1 / image.height),
        min(1, box.x1 + 2 / image.width),
        min(1, box.y1 + 1 / image.height),
    )
    raster = crop(image, requested)
    money_rows = [r["id"] for r in plan.rows if any(raster.box.intersects(Box(*m["measured_box"])) for m in r["money"])]
    if (block_index is None and money_rows != [row_id]) or (block_index is not None and money_rows):
        raise ValueError("Targeted witness includes a competing monetary row")
    return HouseOcrRegion(f"witness-{row_id}-{block_index or 'row'}", raster, (row_id,), block_index)


def _normalized(text):
    return re.sub(r"[^A-Z0-9]", "", text.upper())


def _money_identity(text):
    return ("-" if text.startswith("-") else "") + re.sub(r"\D", "", text) if _NUMERIC.fullmatch(text) else None


def _parse_line(text):
    match = _TAIL.search(" " + text)
    if not match:
        return None
    amounts = re.findall(_AMOUNT, match[1])
    prefix = (" " + text)[: match.start()].strip()
    canonical = re.sub(r"^(\d{2})–(\d{2})\b", r"\1-\2", prefix)
    detail = _DETAIL.fullmatch(canonical)
    fields = dict(zip(LITERAL_FIELDS, detail.groups())) if detail else None
    changes = []
    if canonical != prefix:
        changes.append(
            {
                "field": "posting_date_literal",
                "rule": "printed-date-separator",
                "raw": prefix[:5],
                "value": canonical[:5],
            }
        )
    if fields:
        for name in ("payee_literal", "description_literal"):
            cleaned = _clean(fields[name])
            if cleaned != fields[name]:
                changes.append({"field": name, "rule": "printed-dot-leader", "raw": fields[name], "value": cleaned})
                fields[name] = cleaned
    kind = "detail" if fields else ("unparsed_detail" if _POSTED.match(prefix) else "summary_or_total")
    return {"kind": kind, "amounts": amounts, "prefix": prefix, "fields": fields, "display_cleanup": changes}


def _candidate(parsed, row):
    if [_money_identity(m["text"]) for m in row["money"]] != [_money_identity(m) for m in parsed["amounts"]]:
        return None
    anchors, raw = ["money_sign_and_digits_in_observed_column_order"], row["label_or_row_literal"]
    if parsed["kind"] == "detail":
        if row["kind"] != "detail" or not re.search(
            r"(?<!\d)" + re.escape(parsed["fields"]["posting_date_literal"]) + r"(?!\d)", raw
        ):
            return None
        anchors.append("posting_date_literal")
        for key in ("voucher_literal", "payee_literal", "description_literal"):
            value = parsed["fields"][key]
            if value and _normalized(value) in _normalized(raw):
                anchors.append(key)
        expected = Counter(parsed["fields"][k] for k in ("service_start_literal", "service_end_literal"))
        actual = Counter(_SERVICE.findall(raw))
        if all(actual[value] >= count for value, count in expected.items()):
            anchors.append("both_service_date_occurrences")
        if len(anchors) < 4:
            return None
    elif parsed["kind"] == "summary_or_total":
        if row["kind"] == "detail":
            return None
        if _normalized(parsed["prefix"]) == _normalized(raw):
            anchors.append("row_label_literal")
        elif len(parsed["amounts"]) != 2:
            common = set(re.findall(r"[A-Z]+", parsed["prefix"])) & set(re.findall(r"[A-Z]+", raw))
            if "TOTALS" not in common or len(common) < 3:
                return None
            anchors.append("three_shared_total_label_words_including_TOTALS")
        if len(parsed["amounts"]) == 2:
            anchors.extend(("left_money_observation", "right_money_observation"))
    else:
        return None
    return {"row_id": row["id"], "anchors": anchors}


def _category_readings(views, observed):
    """Reconcile a unique one-letter OCR disagreement with a retained heading.

    The region supplies the spatial bound; model line order supplies no position.
    Raw measured text and the unplaced model witness both remain in the result.
    See the original 2008 equipment heading and its independently reviewed rows.
    """
    result = {}
    for word in observed:
        if word["text"] in _CATEGORIES:
            continue
        text = _normalized(word["text"])
        candidates = [
            name
            for name in _CATEGORIES
            if len(text) == len(_normalized(name))
            and sum(a != b for a, b in zip(text, _normalized(name), strict=True)) == 1
        ]
        if len(candidates) != 1:
            continue
        (name,) = candidates
        witnesses = []
        for view in views:
            if view.region.field_block_index is not None or not view.region.raster.box.contains(Box(*word["bbox"])):
                continue
            competing = [
                other
                for other in observed
                if view.region.raster.box.contains(Box(*other["bbox"]))
                and len(_normalized(other["text"])) == len(_normalized(name))
                and sum(a != b for a, b in zip(_normalized(other["text"]), _normalized(name), strict=True)) <= 1
            ]
            if len(competing) != 1:
                continue
            headings = [(i, line) for i, line in enumerate(view.text.splitlines(), 1) if _clean(line) == name]
            if len(headings) == 1:
                ordinal, line = headings[0]
                witnesses.append(
                    {
                        "view_id": view.region.id,
                        "raw_line_ordinal": ordinal,
                        "raw_text": line,
                        "model_box": None,
                        "evidence": view.evidence,
                    }
                )
        # An unread probable category heading closes the previous category.
        # Carrying the prior value across it would hide the recognition gap.
        result[word["index"]] = (
            {
                "literal": name,
                "observed_literal": word["text"],
                "block_index": word["index"],
                "measured_box": word["bbox"],
                "reading_rule": "unique-known-category-in-measured-model-region",
                "model_heading_witnesses": witnesses,
            }
            if witnesses
            else None
        )
    return result


def _contexts(plan, views):
    financial = {r["id"] for r in plan.rows}
    column_left = min(m["measured_box"][0] for r in plan.rows for m in r["money"])
    observed = [
        word
        for line in plan.lines
        if line["id"] not in financial
        for word in line["blocks"]
        if word["bbox"][2] < column_left
    ]
    categories = _category_readings(views, observed)
    office = program = category = None
    category_unread = False
    contexts = {}
    rows = {row["id"]: row for row in plan.rows}
    for line in plan.lines:
        if line["id"] in financial:
            office_total = "OFFICE TOTALS" in rows[line["id"]]["label_or_row_literal"]
            issues = [] if office else ["source_account_context_unread"]
            if category_unread and not office_total:
                issues.append("source_category_context_unread")
            contexts[line["id"]] = {
                "office_heading": office,
                "program_heading": None if office_total else program,
                "nearest_program_heading": program,
                "row_scope": "office" if office_total else "enclosing_source_program",
                "program_heading_is_membership_claim": False,
                "category_heading": category,
                "issues": issues,
            }
            continue
        for word in line["blocks"]:
            if word["bbox"][2] >= column_left:
                continue
            witness = {"literal": word["text"], "block_index": word["index"], "measured_box": word["bbox"]}
            match = re.fullmatch(r"FISCAL YEAR (\d{4}) (.+)", word["text"])
            if match:
                office = {**witness, "funding_year_literal": match[1], "office_literal": match[2]}
                program = category = None
                category_unread = False
            elif word["text"] in _CATEGORIES:
                category = witness
                category_unread = False
            elif word["index"] in categories:
                category = categories[word["index"]]
                category_unread = category is None
            elif word["text"] == "MODULAR FURNITURE" or word["text"].startswith("LEADERSHIP "):
                program, category = witness, None
                category_unread = False
    return contexts


def _validate_view(plan, view):
    rows = {r["id"]: r for r in plan.rows}
    region = view.region
    if len(region.row_ids) != len(set(region.row_ids)) or not region.row_ids or not set(region.row_ids) <= rows.keys():
        raise ValueError("OCR view must name distinct measured source rows")
    validate_view_image(plan.image, view)
    if region.field_block_index is not None:
        if len(region.row_ids) != 1:
            raise ValueError("A field witness must belong to one measured row")
        found = [w for w in rows[region.row_ids[0]]["blocks"] if w["index"] == region.field_block_index]
        if len(found) != 1 or not region.raster.box.contains(Box(*found[0]["bbox"])):
            raise ValueError("Field witness does not enclose its stated observation")
    elif any(
        not region.raster.box.contains(Box(*m["measured_box"])) for key in region.row_ids for m in rows[key]["money"]
    ):
        raise ValueError("OCR view omits a selected row's measured money cell")


def read_house_disbursements_ocr(
    plan: HouseOcrPlan, views: tuple[HouseOcrView, ...], *, manual_transcriptions=()
) -> dict:
    """Associate views without order tie-breaking; apply only exactly bound manual evidence.

    A manual transcription must bind the original/page/image, measured row box,
    field-crop bytes, exact model response and independent review receipt. It is
    reported as ``manual_review`` and never counted as recognition accuracy.
    """
    if len({view.region.id for view in views}) != len(views):
        raise ValueError("OCR view identifiers must be distinct")
    for view in views:
        _validate_view(plan, view)
    indexed = {row["id"]: row for row in plan.rows}
    contexts = _contexts(plan, views)
    associations, unmatched_model, all_lines = [], [], []
    for view in views:
        if view.region.field_block_index is not None:
            continue
        for ordinal, text in enumerate(view.text.splitlines(), 1):
            parsed = _parse_line(text.strip())
            model = {
                "view_id": view.region.id,
                "raw_line_ordinal": ordinal,
                "raw_text": text,
                "model_box": None,
                "parsed": parsed,
                "evidence": view.evidence,
            }
            all_lines.append(model)
            if parsed is None:
                continue
            matches = [found for key in view.region.row_ids if (found := _candidate(parsed, indexed[key]))]
            winners = [
                match
                for match in matches
                if all(match is other or set(match["anchors"]) > set(other["anchors"]) for other in matches)
            ]
            if len(winners) != 1:
                unmatched_model.append(
                    {
                        **model,
                        "reason": "ambiguous_rows" if matches else "no_matching_measured_row",
                        "candidates": matches,
                    }
                )
                continue
            selected = winners[0]
            row = indexed[selected["row_id"]]
            associations.append(
                {
                    "source_row_id": row["id"],
                    "source_kind": row["kind"],
                    "source_measured_blocks": row["blocks"],
                    "source_row_union_box": row["box"],
                    "model": model,
                    "literal_fields": dict(parsed["fields"] or {}),
                    "money_cells": [
                        {
                            "source_column": m["column"],
                            "source_role": m["role"],
                            "measured_observation_index": m["block_index"],
                            "measured_box": m["measured_box"],
                            "measured_raw_text": m["text"],
                            "model_decimal_literal": value,
                            "model_geometry": None,
                        }
                        for m, value in zip(row["money"], parsed["amounts"])
                    ],
                    "context": contexts[row["id"]],
                    "association_witness": selected,
                    "alternative_candidates": matches,
                    "manual_transcriptions": [],
                    "status": "uniquely_associated_reading",
                }
            )
    counts = Counter(r["source_row_id"] for r in associations)
    duplicates = [key for key, count in counts.items() if count > 1]
    for row in associations:
        if row["source_row_id"] in duplicates:
            row["status"] = "refused_multiple_model_readings"
    accepted = {r["source_row_id"]: r for r in associations if counts[r["source_row_id"]] == 1}
    applied = set()
    for evidence in manual_transcriptions:
        row_id, field = evidence["row_id"], evidence["field"]
        if row_id not in accepted or field not in LITERAL_FIELDS or (row_id, field) in applied:
            raise ValueError("Manual transcription must target one accepted literal field once")
        row = accepted[row_id]
        witness = next((view for view in views if view.region.id == evidence["witness_view_id"]), None)
        if witness is None or witness.region.field_block_index is None or witness.region.row_ids != (row_id,):
            raise ValueError("Manual transcription lacks its measured field-crop witness")
        required = {
            "source_sha256": plan.source_sha256,
            "source_page": plan.source_page,
            "image_sha256": plan.image_sha256,
            "row_box": row["source_row_union_box"],
            "crop_sha256": witness.evidence["input_sha256"],
            "model_response_sha256": witness.evidence["response_text_sha256"],
            "original_ocr_text": witness.text,
            "before": row["literal_fields"].get(field),
            "method": "manual_review",
        }
        if any(evidence.get(key) != value for key, value in required.items()):
            raise ValueError("Manual transcription evidence differs from the retained source or OCR reading")
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", evidence.get("independent_review_sha256", "")) or not isinstance(
            evidence.get("after"), str
        ):
            raise ValueError("Manual transcription requires corrected text and an independent review pin")
        row["literal_fields"][field] = evidence["after"]
        row["manual_transcriptions"].append(dict(evidence))
        applied.add((row_id, field))
    return {
        "rule": RULE,
        "source_sha256": plan.source_sha256,
        "source_page": plan.source_page,
        "image_sha256": plan.image_sha256,
        "geometry": plan.geometry,
        "views": views,
        "associations": associations,
        "all_model_lines": all_lines,
        "unmatched_model_financial_lines": unmatched_model,
        "unmatched_source_financial_rows": [r for r in plan.rows if counts[r["id"]] != 1],
        "multiply_associated_source_rows": duplicates,
        "issues": list(plan.issues),
        "manual_transcription_count": len(applied),
        "qualification": "bounded_source_observations_not_publication",
    }
