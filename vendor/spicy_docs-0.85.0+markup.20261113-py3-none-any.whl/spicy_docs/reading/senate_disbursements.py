"""Stream full Senate PDF page readings with exact-money ledger observations.

The native seven-column ledger supports payroll without voucher/date cells,
signed entries, priced continuations and wrapped notes. Every page and native
word remains accounted for. Other grids and image pages are explicit pending
readings; a successful ledger page is not whole-report completeness.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from dataclasses import asdict
from datetime import date
from importlib.metadata import version
from importlib.resources import files
from itertools import pairwise

from spicy_docs.reading.disbursement_date_repairs import apply_date_repairs
from spicy_docs.reading.pdf_grid import display_words, label_words, literal, vertical_rules, visual_lines
from spicy_docs.reading.senate_payment_candidates import FIELDS
from spicy_docs.schemas.senate_expenditure_tables import funding_year_label, page_context, parse_amount

RULE = "senate-disbursement-pages/1"
MAX_BYTES = 128 * 1024 * 1024
MAX_PAGES = 10_000
MAX_WORDS_PER_PAGE = 10_000
_ANCHORS = ("DOCUMENT", "DATE", "PAYEE", "START", "END", "DESCRIPTION", "AMOUNT")
_DATES = ("date_posted", "service_start", "service_end")
_PAGE = re.compile(r"([A-Z]-(?:[0-9]+-)*)([0-9]+)\Z")
_DATE = re.compile(r"[0-9]{2}/[0-9]{2}/[0-9]{4}\Z")
_CONTEXT_FIELDS = ("office", "account_label", "funding_year", "funding_year_end", "appropriation_title")
_PAYROLL_TOTALS = frozenset(
    {
        "PERSONNEL COMP. FULL-TIME PERMANENT",
        "PERSONNEL COMPENSATION",
        "PERSONNEL BENEFITS",
        "OTHER PERSONNEL COMPENSATION",
        "RE-EMPLOYED ANNUITANTS",
        "REEMPLOYED ANNUITANT",
        "REEMPLOYED ANNUITANTS",
        "BENEFITS FOR NON SENATE/FORMER PERSONNEL",
        "WHEN ACTUALLY EMPLOYED (WAE)",
        "EMPLOYEE WITHHOLDINGS",
        "SPECIAL PERSONNEL SERVICES",
        "NET PAYROLL EXPENSES",
    }
)
_DATE_REPAIRS = json.loads(files("spicy_docs.reading").joinpath("senate_disbursements_corrections.json").read_text())
SOURCE_RESOURCES = ("senate_disbursements_context_corrections.json",)
_CONTEXT_REPAIRS = json.loads(files("spicy_docs.reading").joinpath(SOURCE_RESOURCES[0]).read_text())


def _indices(words):
    return sorted({index for word in words for index in word.get("word_indices", [word["index"]])})


def _apply_date_repairs(result, byte_size):
    """Apply only independent approvals bound to the complete PDF and literal row."""
    apply_date_repairs(
        result,
        byte_size,
        _DATE_REPAIRS,
        printed_page=result["context"]["printed_page"],
        date_fields=_DATES,
        service_fields=("service_start", "service_end"),
    )


def _apply_context_repairs(result, byte_size):
    """Attach independently reviewed image context only to exact continuation pages.

    The source image does not become a native-text reading, and the declaration
    cannot seed transaction groups or extend the normal context carry state.
    Each affected page must independently match its reviewed scope and rows.
    """
    for rule in _CONTEXT_REPAIRS:
        if (rule["source_sha256"], rule["source_page"]) != (result["source_sha256"], result["source_page"]):
            continue
        rows = result["records"]
        if (
            byte_size != rule["source_byte_size"]
            or result["status"] != "ledger_read"
            or result["context"]["printed_page"] != rule["printed_page"]
            or result["context"]["text_sha256"] != rule["native_text_sha256"]
            or result.get("context_basis") != "unresolved"
            or result.get("context_origin") is not None
            or {key: result["context"][key] for key in _CONTEXT_FIELDS} != rule["context_before"]
            or "office_context_unresolved" not in result["issues"]
            or len(rows) != rule["record_count"]
            or not rows
            or rows[0]["raw_fields"] != rule["first_raw_fields"]
            or rows[-1]["raw_fields"] != rule["last_raw_fields"]
        ):
            raise ValueError("Senate image context differs from its exact reviewed continuation page")
        result["context"].update(rule["context_after"])
        result["context_basis"] = "reviewed_image_section"
        result["context_origin"] = {
            **rule["context_after"],
            "origin_source_page": rule["image_origin"]["source_page"],
            "origin_word_indices": [],
            "source_kind": "reviewed_page_image",
            "repair": rule,
        }
        result["issues"].remove("office_context_unresolved")


def _date(value):
    if not _DATE.fullmatch(value):
        return None
    month, day, year = map(int, value.split("/"))
    try:
        return date(year, month, day).isoformat()
    except ValueError:
        return None


def _header(words, rules):
    """Use printed labels and enclosing rules, never fixed x offsets or font width."""
    candidates = []
    for origin in (word for word in words if word["text"] == "DOCUMENT"):
        anchors = []
        for label in _ANCHORS:
            found = [word for word in words if word["text"] == label and -3 < word["y"] - origin["y"] < 21]
            if len(found) != 1:
                break
            anchors.append(found[0])
        if len(anchors) != len(FIELDS):
            continue
        bands = {}
        bottoms = []
        for field, anchor in zip(FIELDS, anchors, strict=True):
            crossing = [rule for rule in rules if rule[1] < anchor["y"] < rule[2]]
            left = [rule for rule in crossing if rule[0] < anchor["x"]]
            right = [rule for rule in crossing if rule[0] > anchor["x"]]
            if not left or not right:
                break
            low, high = max(left), min(right)
            bands[field] = [low[0], high[0]]
            bottoms.append(min(low[2], high[2]))
        if len(bands) != len(FIELDS) or any(
            abs(bands[left][1] - bands[right][0]) > 0.5 for left, right in pairwise(FIELDS)
        ):
            continue
        lower = max(bottoms)
        edges = []
        for x in (bands[FIELDS[0]][0], bands[FIELDS[-1]][1]):
            # A continuation can contain only one subtotal. Its actual outer
            # border, not a minimum body height, establishes the table extent.
            found = [rule for rule in rules if abs(rule[0] - x) < 1 and rule[1] <= lower + 5 and rule[2] > lower + 0.5]
            if not found:
                break
            edges.append(max(found, key=lambda rule: rule[2] - rule[1]))
        if len(edges) != 2 or abs(edges[0][2] - edges[1][2]) > 2:
            continue
        candidates.append(
            {
                "bands": bands,
                "body_bbox": [
                    bands[FIELDS[0]][0],
                    max(lower, *(edge[1] for edge in edges)),
                    bands[FIELDS[-1]][1],
                    min(edge[2] for edge in edges),
                ],
                "anchor_word_indices": _indices(anchors),
                "header_y": origin["y"],
            }
        )
    return candidates[0] if len(candidates) == 1 else None


def _office_context(words, rules, header, context):
    """Read the left office block geometrically, then reuse the source context shaper.

    Older PDFs store Funding Year and the year as separate native text lines.
    The summary's own vertical divider bounds its office block, excluding money
    and adjacent summary labels before the established context reader is used.
    """
    funding = [
        word
        for word in words
        if word["text"].casefold() == "funding"
        and word["y"] < header["header_y"]
        and word["x"] < header["bands"]["service_start"][0]
    ]
    if len(funding) > 1:
        return {**context, **dict.fromkeys(_CONTEXT_FIELDS)}, [], True
    above = visual_lines([word for word in words if word["y"] < header["header_y"] - 3])
    headings = [line for line in above if literal(line) == "DETAILED AND SUMMARY STATEMENT OF EXPENDITURES"]
    if not funding and not headings:
        return context, [], False
    if funding:
        anchor = funding[0]
        borders = [
            rule[0]
            for rule in rules
            if rule[1] < anchor["y"] < rule[2] and anchor["x"] + 50 < rule[0] <= header["bands"]["service_start"][0] + 1
        ]
    else:
        borders = [
            rule[0]
            for rule in rules
            if rule[1] < header["header_y"] - 35
            and rule[2] > header["header_y"] - 10
            and header["bands"]["payee"][0] + 20 < rule[0] < header["bands"]["service_start"][0]
        ]
    if not borders:
        return {**context, **dict.fromkeys(_CONTEXT_FIELDS)}, [], True
    right = min(borders)
    left = header["body_bbox"][0] - 12
    heading_end = max((word["y"] for line in headings for word in line), default=-1) + 1
    selected = [
        word for word in words if left <= word["x"] < right and heading_end < word["y"] < header["header_y"] - 3
    ]
    lines = visual_lines(selected)
    texts = [literal(line) for line in lines if literal(line).strip(" -–−")]
    year = [index for index, text in enumerate(texts) if funding_year_label(text) is not None]
    if not funding and len(texts) >= 2 and texts[-1] == "EXPENSES OF INQUIRIES AND INVESTIGATIONS":
        # Older committee pages print a resolution/account label without a
        # Funding Year line. Preserve that absence and both printed labels.
        return (
            {
                **context,
                "office": texts[0],
                "account_label": " ".join(texts[1:-1]) or None,
                "funding_year": None,
                "funding_year_end": None,
                "appropriation_title": texts[-1],
            },
            _indices(selected),
            True,
        )
    if len(year) != 1 or year[0] == 0:
        return {**context, **dict.fromkeys(_CONTEXT_FIELDS)}, [], True
    text = "\n".join(["DETAILED AND SUMMARY STATEMENT OF EXPENDITURES", *texts, context["printed_page"] or ""])
    shaped = asdict(page_context(text))
    shaped["account_label"] = None
    return {**context, **{key: shaped[key] for key in _CONTEXT_FIELDS}}, _indices(selected), True


def _contiguous(previous, source_page, printed_page):
    if previous is None or previous["source_page"] + 1 != source_page:
        return False
    prior, current = _PAGE.fullmatch(previous["printed_page"] or ""), _PAGE.fullmatch(printed_page or "")
    return bool(prior and current and prior[1] == current[1] and int(current[2]) == int(prior[2]) + 1)


def _wrapped_payees(lines, cells, source_page):
    """Associate two name-only lines that bracket one centered priced row.

    Keep all three original lines and the amount line's literal empty payee.
    Both neighboring fragments, symmetric placement and a font-height bound
    are required; an unnamed component cannot inherit the preceding employee.
    """
    found = {}
    for index in range(1, len(lines) - 1):
        row = cells[index]
        if row["payee"] or not row["description"] or parse_amount(row["amount"]) is None:
            continue
        neighbors = (cells[index - 1], cells[index + 1])
        if not all(
            cell["payee"] and not any(value for key, value in cell.items() if key != "payee") for cell in neighbors
        ):
            continue
        before, middle, after = (lines[position][0]["y"] for position in (index - 1, index, index + 1))
        height = max(word["bbox"][3] - word["bbox"][1] for word in lines[index])
        if max(middle - before, after - middle) > height or abs((middle - before) - (after - middle)) > 1:
            continue
        found[index + 1] = {
            "rule": "centered-two-line-payee",
            "source_page": source_page,
            "source_lines": [index, index + 2],
            "word_indices": [word["index"] for position in (index - 1, index + 1) for word in lines[position]],
            "value": " ".join(cell["payee"] for cell in neighbors),
        }
    uses = Counter(number for origin in found.values() for number in origin["source_lines"])
    return {
        number: origin for number, origin in found.items() if all(uses[line] == 1 for line in origin["source_lines"])
    }


def _ledger(words, header, source_page, carried_group):
    x0, y0, x1, y1 = header["body_bbox"]
    selected = [word for word in words if x0 <= word["x"] <= x1 and y0 < word["y"] < y1]
    positioned = visual_lines(selected)
    cells = [
        {
            key: literal([word for word in line if band[0] <= word["x"] < band[1]])
            for key, band in header["bands"].items()
        }
        for line in positioned
    ]
    wrapped = _wrapped_payees(positioned, cells, source_page)
    fragments = {number for origin in wrapped.values() for number in origin["source_lines"]}
    lines, rows, groups = [], [], []
    current = last_transaction = None
    if carried_group is not None:
        current = {**carried_group, "notes": [], "note_word_indices": [], "rows": [], "carried": True}
        groups.append(current)
        last_transaction = current if current["values"]["document"] else None
    for number, line in enumerate(positioned, 1):
        fields = cells[number - 1]
        indices = [word["index"] for word in line]
        lines.append({"line": number, "word_indices": indices, "cells": fields})
        if number in fragments:
            lines[-1]["role"] = "payee_fragment"
            continue
        amount = parse_amount(fields["amount"])
        label = literal([word for word in line if word["x"] < header["bands"]["amount"][0]])
        if amount is None:
            # Descriptions can extend into the amount column because the body
            # has no internal rules. Retain every literal token as a group note.
            if current is not None and not any(
                fields[key] for key in ("document", "date_posted", "payee", "service_start", "service_end")
            ):
                current["notes"].append(literal(line))
                current["note_word_indices"].extend(indices)
                lines[-1]["role"] = "group_note"
            else:
                lines[-1]["role"] = "unassigned_text"
            continue
        nondate = any(fields[key] and _date(fields[key]) is None for key in ("service_start", "service_end"))
        anchor = bool(fields["document"] or fields["date_posted"] or fields["payee"] or number in wrapped)
        if anchor:
            current = {
                "source_page": source_page,
                "line": number,
                "values": {key: fields[key] for key in FIELDS[:5]},
                "word_indices": indices,
                "payee_origin": wrapped.get(number),
                "notes": [],
                "note_word_indices": [],
                "rows": [],
                "carried": False,
            }
            groups.append(current)
            if number in wrapped:
                current["values"]["payee"] = wrapped[number]["value"]
            kind = "transaction" if fields["document"] or fields["date_posted"] else "payroll"
            last_transaction = current if current["values"]["document"] else None
        elif label.upper() in _PAYROLL_TOTALS:
            current = last_transaction = None
            kind = "subtotal"
        elif nondate:
            # Category subtotals introduce no voucher. A subsequent priced
            # line can continue it; subtotal rows themselves inherit nothing.
            current = None
            kind = "subtotal"
        elif last_transaction is not None:
            current = last_transaction
            kind = "transaction"
        else:
            current = None
            kind = "unassigned_amount"
        resolved = dict(fields)
        if kind in {"transaction", "payroll"} and current is not None:
            resolved.update({key: value for key, value in current["values"].items() if not resolved[key]})
        issues = []
        normalized_dates = {}
        for key in _DATES:
            normalized_dates[key] = _date(resolved[key]) if resolved[key] else None
            if resolved[key] and normalized_dates[key] is None and kind != "subtotal":
                issues.append("invalid_" + key)
        if (
            normalized_dates["service_start"]
            and normalized_dates["service_end"]
            and normalized_dates["service_end"] < normalized_dates["service_start"]
        ):
            issues.append("reversed_service_dates")
        row = {
            "line": number,
            "row_kind": kind,
            "word_indices": indices,
            "raw_fields": fields,
            "document": resolved["document"] or None,
            "payee": resolved["payee"] or None,
            "payee_origin": current.get("payee_origin") if current is not None and not fields["payee"] else None,
            **normalized_dates,
            "description": label if kind == "subtotal" else fields["description"] or None,
            "amount": format(amount, ".2f"),
            "issues": issues,
            "repairs": [],
            "group_origin": {"source_page": current["source_page"], "line": current["line"]} if current else None,
        }
        if current is not None:
            current["rows"].append(row)
        rows.append(row)
        lines[-1]["role"] = kind
    for group in groups:
        for row in group["rows"]:
            row["group_notes"] = "\n".join(group["notes"]) or None
            row["group_note_word_indices"] = group["note_word_indices"]
    carry = (
        {key: last_transaction[key] for key in ("source_page", "line", "values", "word_indices", "payee_origin")}
        if last_transaction
        else None
    )
    return rows, lines, carry


def iter_senate_disbursements_pages(
    body: bytes, *, pages=None, source_page_numbers=None, report_period_start=None, report_period_end=None
):
    """Yield every selected physical page once, with records and explicit unread content.

    The default selects the entire PDF. An excerpt can supply its retained map
    of local page to original page; context never crosses a gap in that map.
    Native words are retained even on unsupported or image-bearing pages.
    """
    import pymupdf

    if not 0 < len(body) <= MAX_BYTES:
        raise ValueError("Senate PDF exceeds the source byte bound")
    if (report_period_start is None) != (report_period_end is None) or (
        report_period_start is not None
        and (
            type(report_period_start) is not date
            or type(report_period_end) is not date
            or report_period_end < report_period_start
        )
    ):
        raise ValueError("Senate date review requires both valid evidenced report-period dates")
    sha = "sha256:" + hashlib.sha256(body).hexdigest()
    backend_version = version("pymupdf")
    previous = carried_context = carried_group = None
    with pymupdf.open(stream=body, filetype="pdf") as document:
        if document.needs_pass or len(document) > MAX_PAGES:
            raise ValueError("Senate PDF is encrypted or exceeds the page bound")
        selected = list(range(1, len(document) + 1)) if pages is None else list(pages)
        if (
            not selected
            or selected != sorted(set(selected))
            or any(type(n) is not int or not 1 <= n <= len(document) for n in selected)
        ):
            raise ValueError("Select distinct ascending physical PDF pages")
        mapping = dict(source_page_numbers or {})
        if mapping and (
            set(mapping) != set(selected)
            or any(type(n) is not int or n < 1 for n in mapping.values())
            or len(set(mapping.values())) != len(mapping)
        ):
            raise ValueError("An excerpt page map must uniquely name every selected original page")
        for number in selected:
            page = document[number - 1]
            source_page = mapping.get(number, number)
            text = page.get_text()
            words = display_words(page)
            context = {**asdict(page_context(text)), "account_label": None}
            result = {
                "rule": RULE,
                "pymupdf_version": backend_version,
                "source_sha256": sha,
                "page": number,
                "source_page": source_page,
                "physical_pages": len(document),
                "rotation": page.rotation,
                "page_bbox": list(page.rect),
                "text": text,
                "words": words,
                "image_count": len(page.get_images()),
                "context": context,
                "records": [],
                "lines": [],
                "header": None,
                "issues": [],
            }
            header = None
            labels = words
            result["label_reading"] = "native_words"
            if len(words) <= MAX_WORDS_PER_PAGE:
                rules = vertical_rules(page)
                header = _header(words, rules)
                if header is None:
                    labels = label_words(page, words)
                    header = _header(labels, rules)
                    result["label_reading"] = "positioned_glyphs_without_exact_overprints"
            if header is None:
                result["status"] = (
                    "image_content_pending"
                    if result["image_count"] and len(words) < 30
                    else "non_ledger_content_pending"
                )
                if len(words) > MAX_WORDS_PER_PAGE:
                    result["issues"].append("native_word_bound_exceeded")
                result["outside_ledger_word_indices"] = list(range(len(words)))
                previous = carried_context = carried_group = None
                yield result
                continue
            printed = {
                word["text"]
                for word in words
                if _PAGE.fullmatch(word["text"])
                and (word["x"] < header["body_bbox"][0] or word["x"] > header["body_bbox"][2])
            }
            if len(printed) == 1:
                printed_page = next(iter(printed))
                if context["printed_page"] not in {None, printed_page}:
                    result["issues"].append("conflicting_printed_page_labels")
                    context["printed_page"] = None
                else:
                    context["printed_page"] = printed_page
            context, context_words, stated = _office_context(labels, rules, header, context)
            continuous = _contiguous(previous, source_page, context["printed_page"])
            if context["office"] and (
                context["funding_year"] or context["account_label"] or context["appropriation_title"]
            ):
                carried_context = {
                    **{key: context[key] for key in _CONTEXT_FIELDS},
                    "origin_source_page": source_page,
                    "origin_word_indices": context_words,
                }
                carried_group = None
                basis = "printed_on_page"
            elif continuous and not stated and carried_context is not None:
                context.update({key: carried_context[key] for key in _CONTEXT_FIELDS})
                basis = "contiguous_printed_section"
            else:
                carried_context = carried_group = None
                basis = "unresolved"
                result["issues"].append("office_context_unresolved")
            rows, lines, carried_group = _ledger(words, header, source_page, carried_group if continuous else None)
            used = {index for line in lines for index in line["word_indices"]}
            result.update(
                status="ledger_read",
                context=context,
                context_basis=basis,
                context_origin=carried_context,
                header=header,
                records=rows,
                lines=lines,
                outside_ledger_word_indices=[word["index"] for word in words if word["index"] not in used],
            )
            previous = {"source_page": source_page, "printed_page": context["printed_page"]}
            _apply_date_repairs(result, len(body))
            if report_period_start is not None:
                start, end = report_period_start.isoformat(), report_period_end.isoformat()
                result.update(report_period_start=start, report_period_end=end)
                for row in rows:
                    if row["date_posted"] and not start <= row["date_posted"] <= end:
                        row["issues"].append("posted_date_outside_report_period")
                    if any(row[key] and row[key] > end for key in ("service_start", "service_end")):
                        row["issues"].append("service_after_report_period")
            _apply_context_repairs(result, len(body))
            yield result
