"""Associate selected Senate image-ledger readings with measured money rows.

The seven printed column headings identify the ledger. Positioned observations
locate monetary occurrences; unplaced model lines must uniquely match their
literal witnesses. Summary amounts remain outside this ledger reading. See the
Senate source guide for the independently reviewed scope and remaining limits.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from datetime import date
from itertools import pairwise
from statistics import median

from spicy_docs.extraction import Box, Raster
from spicy_docs.extraction.model import Observation, Recognition
from spicy_docs.extraction.pages import crop
from spicy_docs.reading.ocr_observations import (
    OcrRegion,
    OcrView,
    box_coordinates,
    evidence_sha256,
    validate_view_image,
)
from spicy_docs.reading.pdf_grid import visual_lines

RULE = "senate-disbursement-ocr-page/1"
DEFAULT_MAX_REGION_PIXELS = 2_620_620
_MONEY = r"-?\$?(?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2}"
_DATE = r"\d{2}/\d{2}/?\d{4}"
_DETAIL = re.compile(rf"^(\S+)\s+({_DATE})\s+(.+?)\s+({_DATE})\s+({_DATE})\s+(.+?)\s+({_MONEY})$")
_FIELDS = ("document", "date_posted_literal", "payee", "service_start_literal", "service_end_literal", "description")
_HEADERS = ("DOCUMENT NO.", "DATE", "PAYEE NAME", "START", "END", "DESCRIPTION", "AMOUNT ($)")
_YEAR = re.compile(r"Funding Year\s+(\d{4})(?:\s*-\s*(\d{4}))?", re.IGNORECASE)


def _normalized(text):
    return re.sub(r"[^A-Z0-9]", "", text.upper())


def _box(words):
    return Box(
        min(w["bbox"][0] for w in words),
        min(w["bbox"][1] for w in words),
        max(w["bbox"][2] for w in words),
        max(w["bbox"][3] for w in words),
    )


def _region(image, words, identity, row_ids, max_pixels):
    box = _box(words)
    box = Box(
        max(0, box.x0 - 2 / image.width),
        max(0, box.y0 - 2 / image.height),
        min(1, box.x1 + 2 / image.width),
        min(1, box.y1 + 2 / image.height),
    )
    raster = crop(image, box)
    if raster.width * raster.height > max_pixels:
        raise ValueError("Complete observed Senate region exceeds the admitted OCR size")
    return OcrRegion(identity, raster, tuple(row_ids))


@dataclass(frozen=True)
class SenateOcrPlan:
    source_sha256: str
    source_page: int
    image: Raster
    geometry: Recognition | Observation
    rows: tuple[dict, ...]
    regions: tuple[OcrRegion, ...]
    header_blocks: tuple[dict, ...]
    context_blocks: tuple[dict, ...]
    other_blocks: tuple[dict, ...]
    ambiguous_row_blocks: tuple[dict, ...]

    @property
    def image_sha256(self):
        return evidence_sha256(self.image.data)


def plan_senate_disbursements_ocr(
    image: Raster,
    geometry: Recognition | Observation,
    *,
    source_sha256: str,
    source_page: int,
    max_region_pixels: int = DEFAULT_MAX_REGION_PIXELS,
) -> SenateOcrPlan:
    """Select an observed seven-column ledger and its local funding-year block.

    Does not recognize, fetch or inherit an account from another page. Unexpected
    headings, absent money geometry and oversized regions refuse explicitly.
    """
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", source_sha256) or source_page < 1:
        raise ValueError("An exact original SHA256 and positive physical page are required")
    if image.box != Box() or max_region_pixels < 1:
        raise ValueError("Supply a complete oriented page and a positive region pixel bound")
    words = []
    for index, block in enumerate(geometry.blocks, 1):
        if block.box is None:
            raise ValueError("Senate OCR layout requires measured text boxes")
        box = block.box
        words.append(
            {
                "index": index,
                "text": block.text,
                "bbox": box_coordinates(box),
                "x": (box.x0 + box.x1) / 2,
                "y": (box.y0 + box.y1) / 2,
            }
        )
    if not words:
        raise ValueError("No positioned observations; Senate financial content is unread")
    height = median(w["bbox"][3] - w["bbox"][1] for w in words)
    document = [w for w in words if w["text"] == _HEADERS[0]]
    if len(document) != 1:
        raise ValueError("Expected one observed Senate document-column header")
    top = document[0]["y"]
    headers = []
    for label in _HEADERS:
        found = [w for w in words if w["text"] == label and top - height < w["y"] < top + height * 3]
        if len(found) != 1:
            raise ValueError("Senate OCR column headings are absent or ambiguous")
        headers.extend(found)
    if [w["x"] for w in headers] != sorted(w["x"] for w in headers):
        raise ValueError("Unsupported observed Senate column order")
    bottom = max(w["bbox"][3] for w in headers)
    # A block must contain a complete amount; model text cannot invent its place.
    body = [w for w in words if w["y"] > bottom and headers[0]["bbox"][0] - height <= w["x"]]
    money = sorted(
        (w for w in body if w["x"] > headers[-2]["bbox"][2] and re.fullmatch(_MONEY, w["text"])),
        key=lambda w: w["y"],
    )
    if not money or len(money) > 200 or any(b["y"] - a["y"] < height * 0.3 for a, b in pairwise(money)):
        raise ValueError("Senate monetary rows are absent, overlapping or outside the bounded profile")
    right = max(w["bbox"][2] for w in money)
    body = [
        w
        for w in body
        if w["bbox"][0] <= right and money[0]["bbox"][1] - height < w["y"] <= money[-1]["bbox"][3] + height
    ]
    extra_money = [w for w in body if re.fullmatch(_MONEY, w["text"]) and w not in money]
    if extra_money:
        raise ValueError("Unassigned monetary observations occur outside the Senate amount column")
    rows = [{"id": f"money-{w['index']}", "money": w, "blocks": [], "ambiguous_block_indices": []} for w in money]
    ambiguous = []
    for word in body:
        distances = sorted((abs(word["y"] - m["y"]), i) for i, m in enumerate(money))
        _, nearest = distances[0]
        gaps = [abs(money[nearest]["y"] - money[i]["y"]) for i in (nearest - 1, nearest + 1) if 0 <= i < len(money)]
        gap = min(gaps, default=height)
        if word not in money and (
            word["bbox"][3] - word["bbox"][1] > gap * 1.8
            or (len(distances) > 1 and abs(distances[0][0] - distances[1][0]) < height * 0.02)
        ):
            ambiguous.append(word)
            for row in rows:
                if word["bbox"][1] <= row["money"]["y"] <= word["bbox"][3]:
                    row["ambiguous_block_indices"].append(word["index"])
        else:
            rows[nearest]["blocks"].append(word)
    for row in rows:
        row["blocks"].sort(key=lambda w: (w["x"], w["y"]))
        row["box"] = box_coordinates(_box(row["blocks"]))
        row["literal_witness"] = " ".join(w["text"] for w in row["blocks"])
    # The upper-left account block is bounded by the ledger payee heading's
    # right edge. Other summary cells remain inventoried and explicitly unread.
    context = [w for w in words if w["bbox"][2] < headers[2]["bbox"][2] and w["bbox"][3] < top - height]
    funding = [w for w in context if w["text"].casefold() == "funding year"]
    if len(funding) != 1:
        context = []
    regions = [_region(image, [*headers, *body], "ledger", [r["id"] for r in rows], max_region_pixels)]
    if context:
        regions.append(_region(image, context, "context", (), max_region_pixels))
    selected = {w["index"] for w in [*headers, *body, *context]}
    return SenateOcrPlan(
        source_sha256,
        source_page,
        image,
        geometry,
        tuple(rows),
        tuple(regions),
        tuple(headers),
        tuple(context),
        tuple(w for w in words if w["index"] not in selected),
        tuple(ambiguous),
    )


def _context(plan, views):
    readings = [view for view in views if view.region.id == "context"]
    if not plan.context_blocks or len(readings) != 1:
        return {"status": "unread", "issues": ["source_account_context_unread"]}
    view = readings[0]
    text = view.text.strip()
    matches = list(_YEAR.finditer(text))
    height = median(w["bbox"][3] - w["bbox"][1] for w in plan.context_blocks)
    measured = " ".join(
        w["text"] for line in visual_lines(list(plan.context_blocks), tolerance=height * 0.45) for w in line
    )
    # Agreement covers the complete local context, not just a matched office name.
    if len(matches) != 1 or _normalized(text) != _normalized(measured):
        return {"status": "unread", "issues": ["source_account_context_disagreement"], "model_text": text}
    year = matches[0]
    return {
        "status": "local_observed_context",
        "office_literal": " ".join(text[: year.start()].split()),
        "funding_year_start_literal": year[1],
        "funding_year_end_literal": year[2],
        "appropriation_title_literal": " ".join(text[year.end() :].split()),
        "measured_blocks": list(plan.context_blocks),
        "model_text": text,
        "evidence": view.evidence,
        "model_geometry": None,
        "issues": [],
    }


def _dates(fields, row):
    normalized, repairs = {}, []
    for field in ("date_posted_literal", "service_start_literal", "service_end_literal"):
        literal = fields[field]
        digits = re.sub(r"\D", "", literal)
        try:
            normalized[field] = date(int(digits[4:]), int(digits[:2]), int(digits[2:4])).isoformat()
        except ValueError:
            normalized[field] = None
        if len(literal) == 9 and normalized[field] is not None:
            witnesses = [w["index"] for w in row["blocks"] if w["text"] == literal]
            if not witnesses:
                normalized[field] = None
                continue
            repairs.append(
                {
                    "field": field,
                    "raw": literal,
                    "value": normalized[field],
                    "rule": "missing-year-date-separator",
                    "measured_observation_indices": witnesses,
                }
            )
    return normalized, repairs


def read_senate_disbursements_ocr(plan: SenateOcrPlan, views: tuple[OcrView, ...], *, manual_transcriptions=()) -> dict:
    """Associate each model line only through a unique measured source witness.

    Repeated amounts require independent document/date/text anchors. Model order
    never resolves a tie. Printed dates missing only a year separator normalize
    when the exact literal also has a measured observation; the literal survives.
    """
    if manual_transcriptions:
        raise ValueError("The bounded Senate profile has no qualified manual transcription path")
    expected = {r.id: r for r in plan.regions}
    if len({v.region.id for v in views}) != len(views):
        raise ValueError("OCR view identifiers must be distinct")
    for view in views:
        if view.region.id not in expected or view.region != expected[view.region.id]:
            raise ValueError("Senate OCR view differs from its measured source-region selection")
        validate_view_image(plan.image, view)
    context = _context(plan, views)
    rows = {row["id"]: row for row in plan.rows}
    associations, unmatched, all_lines = [], [], []
    for view in views:
        if not view.region.row_ids:
            continue
        for ordinal, text in enumerate(view.text.splitlines(), 1):
            match = _DETAIL.fullmatch(text.strip())
            model = {
                "view_id": view.region.id,
                "raw_line_ordinal": ordinal,
                "raw_text": text,
                "model_box": None,
                "evidence": view.evidence,
            }
            all_lines.append(model)
            if not match:
                if re.search(rf"{_MONEY}\s*$", text):
                    unmatched.append({**model, "reason": "unparsed_financial_line", "candidates": []})
                continue
            fields = dict(zip(_FIELDS, match.groups()[:-1], strict=True))
            amount = match[7].replace("$", "").replace(",", "")
            candidates = []
            for key in view.region.row_ids:
                row = rows[key]
                if row["money"]["text"].replace("$", "").replace(",", "") != amount:
                    continue
                observed = _normalized(row["literal_witness"])
                anchors = ["money_sign_and_digits"]
                for field in ("document", "date_posted_literal"):
                    if fields[field] in [w["text"] for w in row["blocks"]]:
                        anchors.append(field)
                for field in ("payee", "description"):
                    if _normalized(fields[field]) in observed:
                        anchors.append(field)
                expected_dates = Counter(fields[field] for field in ("service_start_literal", "service_end_literal"))
                actual_dates = Counter(re.findall(_DATE, row["literal_witness"]))
                # Do not spend one observed date twice for equal start/end cells.
                actual_dates[fields["date_posted_literal"]] -= 1
                if all(actual_dates[value] >= count for value, count in expected_dates.items()):
                    anchors.extend(("service_start_literal", "service_end_literal"))
                if "date_posted_literal" in anchors and len(anchors) >= 5:
                    candidates.append({"row_id": key, "anchors": anchors})
            winners = [
                candidate
                for candidate in candidates
                if all(candidate is other or set(candidate["anchors"]) > set(other["anchors"]) for other in candidates)
            ]
            if len(winners) != 1:
                unmatched.append(
                    {
                        **model,
                        "reason": "ambiguous_rows" if candidates else "no_matching_measured_row",
                        "candidates": candidates,
                    }
                )
                continue
            selected = winners[0]
            row = rows[selected["row_id"]]
            normalized_dates, date_normalizations = _dates(fields, row)
            associations.append(
                {
                    "source_row_id": row["id"],
                    "source_kind": "detail",
                    "source_measured_blocks": row["blocks"],
                    "source_row_union_box": row["box"],
                    "ambiguous_block_indices": row["ambiguous_block_indices"],
                    "model": model,
                    "literal_fields": fields,
                    "normalized_dates": normalized_dates,
                    "date_normalizations": date_normalizations,
                    "money_cells": [
                        {
                            "source_column": 7,
                            "source_role": "amount",
                            "measured_observation_index": row["money"]["index"],
                            "measured_box": row["money"]["bbox"],
                            "measured_raw_text": row["money"]["text"],
                            "model_decimal_literal": amount,
                            "model_geometry": None,
                        }
                    ],
                    "context": context,
                    "association_witness": selected,
                    "alternative_candidates": candidates,
                    "manual_transcriptions": [],
                    "status": "uniquely_associated_reading",
                }
            )
    counts = Counter(row["source_row_id"] for row in associations)
    duplicates = [key for key, count in counts.items() if count > 1]
    for row in associations:
        if counts[row["source_row_id"]] > 1:
            row["status"] = "refused_multiple_model_readings"
    return {
        "rule": RULE,
        "source_sha256": plan.source_sha256,
        "source_page": plan.source_page,
        "image_sha256": plan.image_sha256,
        "geometry": plan.geometry,
        "views": views,
        "associations": associations,
        "all_model_lines": all_lines,
        "unmatched_model_financial_lines": unmatched,
        "unmatched_source_financial_rows": [r for r in plan.rows if counts[r["id"]] != 1],
        "multiply_associated_source_rows": duplicates,
        "other_measured_blocks": list(plan.other_blocks),
        "ambiguous_row_blocks": list(plan.ambiguous_row_blocks),
        "issues": ["non_ledger_content_not_read", *context["issues"]],
        "manual_transcription_count": 0,
        "qualification": "bounded_source_observations_not_publication",
    }
