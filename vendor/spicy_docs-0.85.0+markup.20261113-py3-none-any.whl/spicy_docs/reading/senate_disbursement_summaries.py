"""Read native Senate financial summaries using maintained table geometry.

Ruled account cells can contain several funding years. Associate amounts with
their actual positioned year lines, preserving empty columns and repeated
summary labels. Header annotations are retained separately from financial rows.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from dataclasses import asdict, replace
from importlib.resources import files

from spicy_docs.extraction import DefaultReader, DocumentExtractor, NativeText, TableObservation
from spicy_docs.extraction.font_glyphs import map_line
from spicy_docs.reading.financial_lines import financial_lines
from spicy_docs.reading.financial_repairs import apply_reviewed_cells
from spicy_docs.reading.ocr_observations import (
    apply_reviewed_observation_fields,
    evidence_sha256,
    retained_structured_observation,
)
from spicy_docs.reading.pdf_grid import literal, visual_lines
from spicy_docs.reading.senate_disbursements import SOURCE_RESOURCES as LEDGER_SOURCE_RESOURCES
from spicy_docs.reading.senate_disbursements import iter_senate_disbursements_pages
from spicy_docs.schemas.senate_expenditure_tables import grid_kind, parse_amount, table_period

RULE = "senate-native-financial-summaries/1"
SOURCE_RESOURCES = (
    *LEDGER_SOURCE_RESOURCES,
    "senate_summary_font_corrections.json",
    "senate_financial_summaries_corrections.json",
)
_FONT_REPAIRS = json.loads(files("spicy_docs.reading").joinpath("senate_summary_font_corrections.json").read_text())
_AMOUNT_REPAIRS = json.loads(
    files("spicy_docs.reading").joinpath("senate_financial_summaries_corrections.json").read_text()
)
_FUNDING = re.compile(r"(?:\d{4}(?:\s*[-–]\s*\d{4})?|X(?:\s*\((?:NO-YEAR|REVOLVING)\))?)", re.IGNORECASE)
_APPROPRIATION_COLUMNS = {
    "appropriation_title": "APPROPRIATION TITLE",
    "appropriation_number": "NO.",
    "funds_available": "FUNDS AVAILABLE AS OF",
    "supplementals": "SUPPLEMENTALS",
    "transfers": "TRANSFERS",
    "rescissions_withdrawals": "RESCISSIONS/ WITHDRAWALS",
    "net_expenditures": "NET EXPENDITURES",
    "revolving_fund_receipts": "REVOLVING FUND RECEIPTS",
    "unexpended_balance": "UNEXPENDED BALANCE AS OF",
}
_OFFICE_COLUMNS = {
    "description": "DESCRIPTION",
    "net_funds_available": "NET FUNDS AVAILABLE AS",
    "period_net_expenditures": "NET EXPENDITURES FOR THE PERIOD OF",
    "total_funding_ytd": "TOTAL FUNDING YTD",
}

STRUCTURED_RULE = "senate-structured-financial-summaries/1"
_QUALIFIED_STATUSES = {"accepted_observation", "accepted_with_reviewed_corrections"}
_STRUCTURED_MONEY = re.compile(
    r"(?:-?\$?|\$-?)(?:\d{1,3}(?:,\d{3})+|\d+|)\.\d{2}|\((?:\d{1,3}(?:,\d{3})+|\d+)\.\d{2}\)"
)


def _structured_summary_rows(outcome, page):
    """Associate literal funding rows with observed same-page account headings."""
    if set(outcome) != {"page_label", "headings", "tables", "other_text", "uncertainties"}:
        raise ValueError("Unsupported structured Senate page fields")
    if outcome["uncertainties"] or outcome["other_text"] or not outcome["tables"]:
        raise ValueError("Structured Senate page contains unassigned or unread content")
    heading = " ".join(" ".join(outcome["headings"]).split())
    if heading != "SUMMARY OF TRANSACTIONS BY APPROPRIATIONS ($)":
        raise ValueError("Structured Senate summary title or currency is unsupported")
    grids, records = [], []
    roles = tuple(_APPROPRIATION_COLUMNS)
    money_roles = roles[2:]
    for table_index, source in enumerate(outcome["tables"]):
        if set(source) != {"title", "columns", "rows"} or source["title"]:
            raise ValueError("Unsupported structured Senate table title or fields")
        columns = source["columns"]
        if len(columns) != len(roles) or not source["rows"]:
            raise ValueError("Structured Senate table has missing columns or rows")
        grouped = [
            index for index, label in enumerate(columns) if " ".join(label.split()).startswith("FUNDING ADJUSTMENTS ")
        ]
        if grouped != [3, 4, 5]:
            raise ValueError("Structured Senate funding-adjustment group is missing or unassigned")
        for role, label in zip(roles, columns, strict=True):
            normalized = " ".join(label.split()).removeprefix("FUNDING ADJUSTMENTS ")
            expected = _APPROPRIATION_COLUMNS[role]
            if role in {"funds_available", "unexpended_balance"}:
                valid = normalized.startswith(expected + " ")
            else:
                valid = normalized == expected
            if not valid:
                raise ValueError("Structured Senate column order or role is unsupported")
        raw_rows = []
        for row in source["rows"]:
            if set(row) != {"context", "cells"} or len(row["cells"]) != len(roles):
                raise ValueError("Structured Senate row has missing or extra cells")
            if any(not isinstance(cell, str) for cell in row["cells"]):
                raise ValueError("Structured Senate null cell is unreadable, not blank")
            raw_rows.append(tuple(row["cells"]))
        cells = (tuple(columns), *raw_rows)
        observation = TableObservation(
            page,
            None,
            len(cells),
            len(roles),
            cells,
            tuple(tuple(None for _ in roles) for _ in cells),
            raw=source,
        )
        start, end = table_period(observation)
        if not start or not end or start > end:
            raise ValueError("Structured Senate summary requires its actual ordered header dates")
        grids.append(
            {
                "table": table_index,
                "grid_kind": "appropriation_summary",
                "period_start": start,
                "period_end": end,
                "observation": asdict(observation),
                "coordinate_basis": "structured response order; no source cell geometry",
                "column_groups": [
                    {
                        "literal": "FUNDING ADJUSTMENTS",
                        "columns": grouped,
                        "origin": "observed column-label prefixes",
                        "box": None,
                    }
                ],
                "headers": {
                    role: {"label": label, "column": index, "box": None}
                    for index, (role, label) in enumerate(zip(roles, columns, strict=True))
                },
            }
        )
        title = number = heading_row = heading_origin = None
        for row_index, row in enumerate(source["rows"]):
            label, account, *money = row["cells"]
            if (
                not account
                and not any(money)
                and re.fullmatch(r"0\d{3}", label)
                and isinstance(row["context"], str)
                and row["context"].strip()
                and not _FUNDING.fullmatch(row["context"].strip())
            ):
                title, number, heading_row = row["context"], label, row_index
                heading_origin = {
                    "row": row_index,
                    "account_column": 0,
                    "title_field": "context",
                    "reason": "Leading-zero account occupies the title cell; the same observed row explicitly supplies its title in context.",
                    "normalization": "account_in_title_cell_with_explicit_context",
                }
                continue
            is_total = label.strip().casefold() == "totals"
            funding = _FUNDING.fullmatch(label.strip()) is not None
            funding_literal = label
            funding_origin = {"row": row_index, "column": 0}
            combined = re.fullmatch(rf"(.+?)\s+({_FUNDING.pattern})", label, re.IGNORECASE)
            if account:
                if not re.fullmatch(r"\d{4}", account):
                    raise ValueError("Structured Senate account identifier is malformed")
                if not funding and not is_total and not any(money):
                    if label and row["context"] not in {"", label}:
                        raise ValueError("Structured Senate account context conflicts with its heading")
                    title, number, heading_row = label or row["context"] or None, account, row_index
                    heading_origin = {"row": row_index, "account_column": 1}
                    if label:
                        heading_origin["title_column"] = 0
                    elif row["context"]:
                        heading_origin["title_field"] = "context"
                    # A missing title may only be supplied by the immediately
                    # following funding row's explicit same-page context.
                    continue
                if funding and row["context"] and not _FUNDING.fullmatch(row["context"].strip()):
                    title, number, heading_row = row["context"], account, row_index
                    heading_origin = {"row": row_index, "account_column": 1, "title_field": "context"}
                elif combined and any(money):
                    title, funding_literal = combined.groups()
                    number, heading_row = account, row_index
                    heading_origin = {
                        "row": row_index,
                        "account_column": 1,
                        "title_column": 0,
                        "title_span": list(combined.span(1)),
                    }
                    funding_origin["span"] = list(combined.span(2))
                    funding = True
                else:
                    raise ValueError("Structured Senate combined heading/funding row is ambiguous")
            elif not is_total and not funding:
                raise ValueError("Structured Senate row is neither an account nor a funding occurrence")
            if title is None and number is not None and funding and row["context"] and heading_row == row_index - 1:
                if _FUNDING.fullmatch(row["context"].strip()):
                    raise ValueError("Structured Senate account title is a funding label")
                title = row["context"]
                if not isinstance(heading_origin, dict):
                    raise ValueError("Structured Senate pending account lacks its observed heading position")
                heading_origin = {**heading_origin, "title_row": row_index, "title_field": "context"}
            if not is_total and title is None:
                raise ValueError("Structured Senate funding row lacks an unambiguous account heading")
            if row["context"] not in {"", "TOTALS" if is_total else title}:
                raise ValueError("Structured Senate row context conflicts with its observed account")
            values = {}
            for role, raw in zip(money_roles, money, strict=True):
                if raw == "":
                    values[role] = None
                elif _STRUCTURED_MONEY.fullmatch(raw.strip()) is None or parse_amount(raw) is None:
                    raise ValueError("Structured Senate money cell has an invalid literal")
                else:
                    values[role] = str(parse_amount(raw))
            records.append(
                {
                    "table": table_index,
                    "row": row_index,
                    "grid_kind": "appropriation_summary",
                    "row_kind": "report_total" if is_total else "appropriation_funding_period",
                    "appropriation_title": label if is_total else title,
                    "appropriation_number": None if is_total else number,
                    "funding_year_literal": None if is_total else funding_literal,
                    "label": label if is_total else None,
                    "period_start": start,
                    "period_end": end,
                    "values": values,
                    "raw_fields": dict(zip(money_roles, money, strict=True)),
                    "source_origin": {
                        "method": "qualified_structured_observation",
                        "table": table_index,
                        "row": row_index,
                        "account_heading_row": None if is_total else heading_row,
                        "account_heading_origin": None if is_total else heading_origin,
                        "funding_origin": None if is_total else funding_origin,
                        "context_literal": row["context"],
                        "box": None,
                        "cells": {
                            role: {"table": table_index, "row": row_index, "column": index}
                            for index, role in enumerate(roles)
                            if role in money_roles
                        },
                    },
                    "issues": [],
                }
            )
    return grids, records


def _structured_counts(records):
    amounts = sum(value is not None for row in records for value in row["values"].values())
    return {"records": len(records), "amounts": amounts, "blanks": sum(len(row["values"]) for row in records) - amounts}


def _corrected_structured_rows(outcome, qualification):
    rules = qualification.get("corrections", [])
    if not isinstance(rules, list):
        raise TypeError("Structured observation corrections must be an explicit list")
    if (qualification["status"] == "accepted_with_reviewed_corrections") != bool(rules):
        raise ValueError("Structured correction status differs from its reviewed correction declarations")
    for rule in rules:
        if not isinstance(rule, dict) or not isinstance(rule.get("edits"), list):
            raise TypeError("Structured observation correction requires explicit field edits")
        for edit in rule.get("edits", []):
            path = edit.get("path") if isinstance(edit, dict) else None
            if not isinstance(path, list):
                raise TypeError("Structured observation correction requires an explicit field path")
            column = len(path) == 4 and path[0] == "tables" and path[2] == "columns" and path[3] in {3, 4, 5}
            title = len(path) == 6 and path[0] == "tables" and path[2] == "rows" and path[4:] == ["cells", 0]
            context = len(path) == 5 and path[0] == "tables" and path[2] == "rows" and path[4] == "context"
            if not (column or title or context or path == ["other_text"]):
                raise ValueError("Senate structured corrections cannot alter monetary cells or unreviewed fields")
    binding = {key: qualification[key] for key in ("source_sha256", "source_byte_size", "page")}
    binding.update(result_sha256=qualification["result"]["sha256"], image_sha256=qualification["image"]["sha256"])
    normalized, audit = apply_reviewed_observation_fields(outcome, binding=binding, corrections=rules)
    grids, records = _structured_summary_rows(normalized, qualification["page"])
    for grid in grids:
        grid["observation"]["raw"] = outcome["tables"][grid["table"]]
        grid["observation_basis"] = "normalized_observation" if audit else "structured_observation"
        edits = [
            edit for rule in audit for edit in rule["edits"] if edit["path"][:3] == ["tables", grid["table"], "columns"]
        ]
        if edits:
            grid["column_groups"][0]["origin"] = "source-qualified manual group association"
            grid["column_groups"][0]["correction_edits"] = edits
    for row in records:
        raw_context = outcome["tables"][row["table"]]["rows"][row["row"]]["context"]
        if raw_context != row["source_origin"]["context_literal"]:
            row["source_origin"]["normalized_context_literal"] = row["source_origin"]["context_literal"]
            row["source_origin"]["context_literal"] = raw_context
        title_origin = row["source_origin"]["account_heading_origin"] or {}
        title_row = title_origin.get("title_row", title_origin.get("row"))
        relevant = []
        for rule in audit:
            if any(
                edit["path"][:3] == ["tables", row["table"], "columns"]
                or (edit["path"][:3] == ["tables", row["table"], "rows"] and edit["path"][3] in {row["row"], title_row})
                for edit in rule["edits"]
            ):
                relevant.append(rule["id"])
        if relevant:
            row["source_origin"]["manual_correction_ids"] = relevant
    return normalized, audit, grids, records


def read_senate_summary_observation(result_bytes, image, *, qualification):
    """Interpret a retained, independently qualified structured page offline.

    Qualification declares exact input membership and reviewed scope. It is
    separate from transport/schema checks and does not make model geometry.
    The caller verifies the retained original and all declared review files.
    """
    if (
        qualification.get("schema") != "source-qualified-structured-summary/1"
        or qualification.get("status") not in _QUALIFIED_STATUSES
    ):
        raise ValueError("Structured Senate input has no accepted source observation qualification")
    if (
        not qualification.get("review_evidence")
        or qualification["page"] < 1
        or qualification["physical_pages"] < qualification["page"]
    ):
        raise ValueError("Structured Senate qualification lacks source review or page scope")
    for body, key in ((result_bytes, "result"), (image.data, "image")):
        identity = qualification[key]
        if identity["sha256"].removeprefix("sha256:") != hashlib.sha256(body).hexdigest() or identity["bytes"] != len(
            body
        ):
            raise ValueError("Structured Senate input differs from its qualified bytes")
    result = json.loads(result_bytes)
    metadata = result["metadata"]
    if metadata["source_sha256"].removeprefix("sha256:") != hashlib.sha256(image.data).hexdigest():
        raise ValueError("Structured Senate result names a different model input")
    geometry = metadata["geometry"]
    if (
        geometry["source_sha256"].removeprefix("sha256:") != qualification["source_sha256"].removeprefix("sha256:")
        or geometry["original_pdf_page"] != qualification["page"]
    ):
        raise ValueError("Structured Senate result names a different original page")
    outcome, config = retained_structured_observation(result, image)
    normalized, audit, grids, records = _corrected_structured_rows(outcome, qualification)
    counts = _structured_counts(records)
    if counts != qualification["counts"]:
        raise ValueError("Structured Senate output differs from independently qualified coverage")
    return {
        "rule": STRUCTURED_RULE,
        "reading_method": "qualified_structured_observation",
        "source_sha256": qualification["source_sha256"],
        "source_byte_size": qualification["source_byte_size"],
        "page": qualification["page"],
        "source_page": qualification["page"],
        "physical_pages": qualification["physical_pages"],
        "printed_page": outcome["page_label"],
        "context": {},
        "context_basis": None,
        "context_origin": None,
        "grids": grids,
        "records": records,
        "issues": [],
        "unrecognized_tables": [],
        "status": "summary_read_with_reviewed_observation_corrections"
        if audit
        else "summary_read_from_qualified_observation",
        "structured_observation": outcome,
        "normalized_observation": normalized,
        "observation_corrections": audit,
        "structured_provenance": {
            "qualification": qualification,
            "configuration": config,
            "input_metadata": metadata,
            "response_model_version": result["observations"][0]["raw"]["calls"][0]["response"].get("modelVersion"),
            "outcome_sha256": evidence_sha256(json.dumps(outcome, sort_keys=True, separators=(",", ":")).encode()),
            "geometry": None,
        },
    }


def validate_senate_structured_summary(page):
    """Recheck row/cell occurrence membership without accepting new model output."""
    if page.get("rule") != STRUCTURED_RULE or page.get("reading_method") != "qualified_structured_observation":
        raise ValueError("Unsupported structured Senate page rule")
    outcome = page["structured_observation"]
    provenance = page["structured_provenance"]
    actual = evidence_sha256(json.dumps(outcome, sort_keys=True, separators=(",", ":")).encode())
    if provenance["outcome_sha256"] != actual or provenance["geometry"] is not None:
        raise ValueError("Structured Senate observation identity or geometry changed")
    qualification = provenance["qualification"]
    if qualification["status"] not in _QUALIFIED_STATUSES or any(
        page[key] != qualification[key] for key in ("source_sha256", "source_byte_size", "page", "physical_pages")
    ):
        raise ValueError("Structured Senate page differs from its source qualification")
    normalized, audit, grids, records = _corrected_structured_rows(outcome, qualification)
    if set(page) != {
        "rule",
        "reading_method",
        "source_sha256",
        "source_byte_size",
        "page",
        "source_page",
        "physical_pages",
        "printed_page",
        "context",
        "context_basis",
        "context_origin",
        "grids",
        "records",
        "issues",
        "unrecognized_tables",
        "status",
        "structured_observation",
        "normalized_observation",
        "observation_corrections",
        "structured_provenance",
    } or any(
        page.get(key) != value
        for key, value in {
            "source_page": qualification["page"],
            "context": {},
            "context_basis": None,
            "context_origin": None,
            "issues": [],
            "unrecognized_tables": [],
            "status": "summary_read_with_reviewed_observation_corrections"
            if audit
            else "summary_read_from_qualified_observation",
        }.items()
    ):
        raise ValueError("Structured Senate page metadata or geometry differs from its qualified scope")
    if page["normalized_observation"] != normalized or page["observation_corrections"] != audit:
        raise ValueError("Structured Senate normalized observation differs from its exact reviewed corrections")
    counts = _structured_counts(records)
    if counts != qualification["counts"] or page["printed_page"] != outcome["page_label"]:
        raise ValueError("Structured Senate page changes qualified coverage or its printed page label")
    # JSON roundtrip aligns tuple/list serialization at the retained page boundary.
    if json.loads(json.dumps(page["grids"])) != json.loads(json.dumps(grids)) or page["records"] != records:
        raise ValueError("Structured Senate financial rows differ from their literal observation cells")


def _inside(words, box, width, height):
    if box is None:
        return []
    return [
        word
        for word in words
        if box.x0 * width <= word["x"] <= box.x1 * width and box.y0 * height <= word["y"] <= box.y1 * height
    ]


def _reviewed_font_words(body, reading):
    """Decode reviewed embedded fonts without replacing any original word."""
    rule = next(
        (
            rule
            for rule in _FONT_REPAIRS
            if rule["source_sha256"] == reading["source_sha256"] and reading["source_page"] in rule["source_pages"]
        ),
        None,
    )
    if rule is None:
        return reading["words"], None
    if len(body) != rule["source_byte_size"]:
        raise ValueError("Reviewed summary font source size differs")
    import pymupdf

    with pymupdf.open(stream=body, filetype="pdf") as document:
        page = document[reading["page"] - 1]
        specifications = {font["font"]: font for font in rule["fonts"]}
        verified = set()
        for font in page.get_fonts():
            name = re.sub(r"^[A-Z]{6}\+", "", font[3])
            if name not in specifications:
                continue
            expected = specifications[name]
            encoding_kind, encoding = document.xref_get_key(font[0], "Encoding")
            if encoding_kind != "xref":
                raise ValueError("Reviewed summary font encoding is unavailable")
            encoding_text = document.xref_object(int(encoding.split()[0]))
            if (
                "sha256:" + hashlib.sha256(document.extract_font(font[0])[3]).hexdigest()
                != expected["font_bytes"]["sha256"]
                or "sha256:" + hashlib.sha256(encoding_text.encode()).hexdigest()
                != expected["encoding_object_text_sha256"]
            ):
                raise ValueError("Reviewed summary embedded font or encoding differs")
            verified.add(name)
        if verified != set(specifications):
            raise ValueError("Reviewed summary embedded font is missing")
        blocks = page.get_text("dict", flags=pymupdf.TEXTFLAGS_DICT & ~pymupdf.TEXT_PRESERVE_IMAGES)["blocks"]
        native_words = page.get_text("words")
        mappings = {
            name: {raw: (printed, rule["id"]) for raw, printed in font["mapping"].items()}
            for name, font in specifications.items()
        }
        result, witnesses, tally = [], [], Counter()
        for word, native in zip(reading["words"], native_words, strict=True):
            if word["text"] != native[4] or word["native_bbox"] != list(native[:4]):
                raise ValueError("Reviewed summary native word identity differs")
            line = blocks[native[5]]["lines"][native[6]]
            x, y = (native[0] + native[2]) / 2, (native[1] + native[3]) / 2
            names = {
                span["font"]
                for span in line["spans"]
                if span["bbox"][0] <= x <= span["bbox"][2] and span["bbox"][1] <= y <= span["bbox"][3]
            }
            if len(names) != 1:
                raise ValueError("Reviewed summary word has ambiguous font geometry")
            name = names.pop()
            if name not in specifications:
                result.append(word)
                continue
            if any(not char.isspace() and char not in mappings[name] for char in word["text"]):
                raise ValueError("Reviewed summary font contains an unreviewed character")
            decoded = map_line([{"font": name, "text": word["text"]}], tally, mappings=mappings)
            result.append({**word, "text": decoded})
            witnesses.append({"word_index": word["index"], "font": name, "native_text": word["text"], "text": decoded})
    return result, {"id": rule["id"], "rule": rule, "words": witnesses}


def _decoded_tables(observations, words, width, height):
    """Keep measured cells and read their text from the separately decoded words."""
    return tuple(
        replace(
            table,
            cells=tuple(
                tuple(
                    "\n".join(literal(line) for line in visual_lines(_inside(words, box, width, height)))
                    if box is not None
                    else cell
                    for cell, box in zip(cells, boxes, strict=True)
                )
                for cells, boxes in zip(table.cells, table.cell_boxes, strict=True)
            ),
        )
        for table in observations
    )


def _hidden_native_words(extracted, words):
    """Retain zero-opacity text spans separately from what the original renders."""
    hidden = [
        {key: span[key] for key in ("font", "text", "bbox", "alpha", "char_flags") if key in span}
        for observation in extracted.content.observations
        for block in observation.raw.get("blocks", [])
        for line in block.get("lines", [])
        for span in line["spans"]
        if span.get("alpha") == 0 and span["text"].strip()
    ]
    if not hidden:
        return None
    indices = []
    for word in words:
        x0, y0, x1, y1 = word["native_bbox"]
        x, y = (x0 + x1) / 2, (y0 + y1) / 2
        if any(span["bbox"][0] <= x <= span["bbox"][2] and span["bbox"][1] <= y <= span["bbox"][3] for span in hidden):
            indices.append(word["index"])
    return {"basis": "native_span_alpha_zero", "word_indices": indices, "spans": hidden}


def _headers(table, roles):
    found = {}
    header_row = -1
    for row, (cells, boxes) in enumerate(zip(table.cells, table.cell_boxes, strict=True)):
        for column, (cell, box) in enumerate(zip(cells, boxes, strict=True)):
            if not cell or box is None:
                continue
            text = " ".join(cell.upper().split())
            for role, label in roles.items():
                if text.startswith(label):
                    found[role] = {"row": row, "column": column, "label": cell, "box": box}
                    header_row = max(header_row, row)
        if set(found) == set(roles):
            return found, header_row
    return {}, None


def _money_rows(words, headers, monetary_roles, width):
    for line_number, line in enumerate(financial_lines(words), 1):
        values = dict.fromkeys(monetary_roles)
        raw = dict.fromkeys(monetary_roles)
        money_indices = set()
        money_readings = []
        issues = []
        for field in monetary_roles:
            box = headers[field]["box"]
            selected = [word for word in line if box.x0 * width <= word["x"] <= box.x1 * width]
            # One printed amount can span native words ("131,882," "706.04").
            # Join only within this ruled column and positioned line; two
            # complete amounts cannot pass the single-amount grammar.
            joined = parse_amount("".join(word["text"] for word in selected))
            if len(selected) > 1 and joined is not None:
                indices = [word["index"] for word in selected]
                money_indices.update(indices)
                raw[field] = literal(selected)
                values[field] = format(joined, ".2f")
                money_readings.append(
                    {
                        "field": field,
                        "source_word_indices": indices,
                        "literal": raw[field],
                        "value": values[field],
                        "method": "native_fragments_within_ruled_money_cell",
                    }
                )
                continue
            amounts = [(word, parse_amount(word["text"])) for word in selected]
            amounts = [(word, value) for word, value in amounts if value is not None]
            if not amounts:
                continue
            money_indices.update(word["index"] for word, _ in amounts)
            raw[field] = literal([word for word, _ in amounts])
            if len(amounts) == 1:
                values[field] = format(amounts[0][1], ".2f")
            else:
                issues.append("multiple_amounts_in_" + field)
        if money_indices:
            row = {
                "line": line_number,
                "values": values,
                "raw_fields": raw,
                "label": literal([word for word in line if word["index"] not in money_indices]),
                "word_indices": [word["index"] for word in line],
                "money_word_indices": sorted(money_indices),
                "issues": issues,
            }
            if money_readings:
                row["money_readings"] = money_readings
            yield row


def _appropriation(table, words, width, height):
    headers, last_header = _headers(table, _APPROPRIATION_COLUMNS)
    if not headers:
        return [], None, []
    records = []
    body_indices = set()
    money_roles = tuple(_APPROPRIATION_COLUMNS)[2:]
    for row_number in range(last_header + 1, table.row_count):
        boxes = table.cell_boxes[row_number]
        title_words = _inside(words, boxes[headers["appropriation_title"]["column"]], width, height)
        title_lines = visual_lines(title_words)
        title = " ".join(literal(line) for line in title_lines if not _FUNDING.fullmatch(literal(line)))
        number = table.cells[row_number][headers["appropriation_number"]["column"]]
        selected = {word["index"]: word for box in boxes for word in _inside(words, box, width, height)}
        body_indices.update(selected)
        for row in _money_rows(list(selected.values()), headers, money_roles, width):
            year = row.pop("label")
            is_total = title.casefold() == "totals"
            if not is_total and not _FUNDING.fullmatch(year):
                row["issues"].append("funding_year_line_unresolved")
            row.update(
                ruled_row=row_number,
                row_kind="report_total" if is_total else "appropriation_funding_period",
                appropriation_title=title,
                appropriation_number=number or None,
                funding_year_literal=None if is_total else year,
                label=title if is_total else None,
            )
            records.append(row)
    return records, headers, sorted(body_indices)


def office_summary_kind(label):
    """Keep office components, organization totals and closing balances distinct."""
    label = label.upper()
    if label.startswith("UNEXPENDED BALANCE AS OF"):
        return "unexpended_balance"
    return "organization_total" if label == "ORGANIZATION TOTALS" else "component"


def _office(table, words, width, height):
    headers, header_row = _headers(table, _OFFICE_COLUMNS)
    if not headers or header_row + 1 >= table.row_count:
        return [], None, []
    body = table.cell_boxes[header_row + 1][headers["description"]["column"]]
    selected = _inside(words, body, width, height)
    records = []
    for row in _money_rows(selected, headers, tuple(_OFFICE_COLUMNS)[1:], width):
        label = row["label"].upper()
        if not label:
            row["issues"].append("summary_label_unresolved")
        row.update(ruled_row=header_row + 1, row_kind=office_summary_kind(label))
        records.append(row)
    return records, headers, [word["index"] for word in selected]


def iter_senate_summary_pages(body: bytes, *, pages=None, source_page_numbers=None):
    """Yield selected original-page summaries, raw words, grids and explicit gaps.

    The maintained native ledger reader supplies source identity and office
    context; its ledger records remain a separate interpretation. Native table
    observations supply ruled cells without rewriting source words.
    """
    readings = iter_senate_disbursements_pages(body, pages=pages, source_page_numbers=source_page_numbers)
    tables = DocumentExtractor(NativeText(), tables=True, max_input_bytes=512 * 1024**2).extract(
        body, media_type="application/pdf", pages=pages
    )
    try:
        for reading, extracted in zip(readings, tables, strict=True):
            width, height = reading["page_bbox"][2:]
            words, font_reading = _reviewed_font_words(body, reading)
            result = {
                "rule": RULE,
                **{
                    key: reading.get(key)
                    for key in (
                        "source_sha256",
                        "page",
                        "source_page",
                        "physical_pages",
                        "page_bbox",
                        "image_count",
                        "words",
                        "text",
                        "context",
                        "context_basis",
                        "context_origin",
                    )
                },
                "grids": [],
                "records": [],
                "issues": [],
                "unrecognized_tables": [],
            }
            observations = extracted.tables
            if hidden := _hidden_native_words(extracted, reading["words"]):
                result["invisible_native_text"] = hidden
            if font_reading:
                result["font_reading"] = {
                    **font_reading,
                    "initial_observations": [asdict(table) for table in observations],
                }
                observations = _decoded_tables(observations, words, width, height)
            # Filled backgrounds distort the 2021 October summary grid, while
            # later reports draw real borders as filled rectangles. Retry only
            # an unrecognized appropriation grid with the maintained strict
            # detector, and retain both observations when it recovers the roles.
            if any(
                "APPROPRIATION TITLE" in " ".join((cell or "").upper().split())
                for table in observations
                for row in table.cells
                for cell in row
            ) and not any(_headers(table, _APPROPRIATION_COLUMNS)[0] for table in observations):
                (retry,) = DocumentExtractor(
                    NativeText(),
                    reader=DefaultReader(table_strategy="lines_strict"),
                    tables=True,
                    max_input_bytes=512 * 1024**2,
                ).extract(body, media_type="application/pdf", pages=[reading["page"]])
                if any(_headers(table, _APPROPRIATION_COLUMNS)[0] for table in retry.tables):
                    result["table_reading"] = {
                        "method": "lines_strict_after_unrecognized_appropriation_grid",
                        "initial_observations": [asdict(table) for table in observations],
                    }
                    observations = retry.tables
            for ordinal, table in enumerate(observations):
                kind = grid_kind(table)
                if kind == "appropriation_summary":
                    records, headers, body_indices = _appropriation(table, words, width, height)
                else:
                    records, headers, body_indices = _office(table, words, width, height)
                    kind = "office_summary"
                if not headers:
                    result["unrecognized_tables"].append({"table": ordinal, "observation": asdict(table)})
                    continue
                start, end = table_period(table)
                header_words = {
                    word["index"]: word
                    for header in headers.values()
                    for word in _inside(words, header["box"], width, height)
                }
                result["grids"].append(
                    {
                        "table": ordinal,
                        "grid_kind": kind,
                        "period_start": start,
                        "period_end": end,
                        "observation": asdict(table),
                        "headers": {key: {**value, "box": asdict(value["box"])} for key, value in headers.items()},
                        "body_word_indices": body_indices,
                        "header_money_annotations": [
                            word for word in header_words.values() if parse_amount(word["text"]) is not None
                        ],
                    }
                )
                result["records"].extend(
                    {"table": ordinal, "grid_kind": kind, "period_start": start, "period_end": end, **row}
                    for row in records
                )
                assigned = {index for row in records for index in row["money_word_indices"]}
                unassigned = [
                    index
                    for index in body_indices
                    if parse_amount(words[index]["text"]) is not None and index not in assigned
                ]
                result["grids"][-1]["unassigned_money_word_indices"] = unassigned
                if unassigned:
                    result["issues"].append("unassigned_summary_amount")
            apply_reviewed_cells(result, len(body), _AMOUNT_REPAIRS, chamber="Senate")
            result["status"] = (
                "summary_read_with_image_content_pending"
                if result["grids"] and reading["image_count"]
                else "summary_read"
                if result["grids"]
                else "image_content_pending"
                if reading["image_count"]
                else "no_recognized_summary"
            )
            yield result
    finally:
        readings.close()
        close_tables = getattr(tables, "close", None)
        if callable(close_tables):
            close_tables()
