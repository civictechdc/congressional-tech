"""Read source-reviewed Senate office summaries from retained model observations.

The caller replays the capture through the shared observation validator first.
Source review separately binds field roles and every amount or blank occurrence.
Native geometry and ledger payments are never inferred from a summary grid.
"""

import json
from copy import deepcopy
from dataclasses import asdict

from spicy_docs.extraction import TableObservation
from spicy_docs.reading.ocr_observations import reviewed_observation
from spicy_docs.reading.senate_disbursement_summaries import (
    _OFFICE_COLUMNS,
    _STRUCTURED_MONEY,
    _structured_counts,
    office_summary_kind,
)
from spicy_docs.schemas.senate_expenditure_tables import page_context, parse_amount, table_period

RULE = "senate-office-reviewed-observation/1"
METHOD = "reviewed_structured_summary"
QUALIFICATION = "reviewed-senate-office-summary/1"
STATUS = "reviewed_fields_with_unresolved_text_or_context"
_LEDGER_COLUMNS = (
    "DOCUMENT NO.",
    "DATE POSTED",
    "PAYEE NAME",
    "OBLIGATION/SERVICE DATES START",
    "OBLIGATION/SERVICE DATES END",
    "DESCRIPTION",
    "AMOUNT ($)",
)


def _table(page, source):
    cells = (tuple(source["columns"]), *(tuple(row["cells"]) for row in source["rows"]))
    width = len(source["columns"])
    return TableObservation(
        page, None, len(cells), width, cells, tuple(tuple(None for _ in range(width)) for _ in cells), raw=source
    )


def _context(outcome, qualification):
    fields = qualification["context_fields"]
    names = ("section_heading", "office", "funding_label", "appropriation_title")
    if set(fields) != set(names):
        raise ValueError("Senate office summary requires reviewed context field roles")
    values, positions = {}, []
    for name in names:
        field, index = fields[name]
        if field not in {"headings", "other_text"} or type(index) is not int or index < 0:
            raise ValueError("Senate office context must name an observed text occurrence")
        value = outcome[field][index]
        if not isinstance(value, str) or not value.strip():
            raise ValueError("Senate office context field is blank or unreadable")
        values[name] = value
        positions.append((field, index))
    if len(set(positions)) != len(positions):
        raise ValueError("Senate office context repeats a text occurrence")
    # Roles are independently reviewed; this order feeds the existing context
    # reader and is not a claim about model or original-page coordinates.
    context = page_context("\n".join([*(values[name] for name in names), outcome["page_label"]]))
    if (
        context.section_heading != "DETAILED AND SUMMARY STATEMENT OF EXPENDITURES"
        or context.office != values["office"]
        or context.appropriation_title != values["appropriation_title"]
        or context.funding_year is None
        or context.printed_page != outcome["page_label"]
    ):
        raise ValueError("Senate office context is inconsistent with its observed fields")
    return {
        "office": context.office,
        "account_label": None,
        "funding_year": context.funding_year,
        "funding_year_end": context.funding_year_end,
        "appropriation_title": context.appropriation_title,
    }


def _row_contexts(outcome, qualification, context):
    """Link model context text to already reviewed source-field occurrences."""
    allowed = {"", context["office"]}
    declarations = qualification.get("row_context_fields", [])
    if type(declarations) is not list:
        raise ValueError("Senate row context references must be a list")
    for declaration in declarations:
        if type(declaration) is not dict or set(declaration) != {"fields", "separator"}:
            raise ValueError("Senate row context must reference reviewed fields")
        names = declaration["fields"]
        if (
            type(names) is not list
            or not names
            or any(
                type(name) is not str or name not in {"office", "funding_label", "appropriation_title"}
                for name in names
            )
            or len(set(names)) != len(names)
            or declaration["separator"] != ("" if len(names) == 1 else "; ")
        ):
            raise ValueError("Senate row context field roles or separator are invalid")
        values = []
        for name in names:
            field, index = qualification["context_fields"][name]
            values.append(outcome[field][index])
        allowed.add(declaration["separator"].join(values))
    return allowed


def _unreviewed_ledger(source, declaration):
    """Account for an observed ledger without interpreting its unreviewed cells."""
    if (
        set(declaration) != {"table", "role", "reason"}
        or not isinstance(declaration["reason"], str)
        or not declaration["reason"].strip()
    ):
        raise ValueError("Unreviewed Senate ledger requires an explicit reason and table role")
    if (
        source["title"] != ""
        or type(source["columns"]) is not list
        or tuple(source["columns"]) != _LEDGER_COLUMNS
        or type(source["rows"]) is not list
        or not source["rows"]
    ):
        raise ValueError("Unreviewed Senate ledger must be a nonempty observed ledger grid")
    for row in source["rows"]:
        if (
            type(row) is not dict
            or set(row) != {"context", "cells"}
            or not isinstance(row["context"], str)
            or type(row["cells"]) is not list
            or len(row["cells"]) != len(_LEDGER_COLUMNS)
            or any(cell is not None and not isinstance(cell, str) for cell in row["cells"])
        ):
            raise ValueError("Unreviewed Senate ledger row has an unsupported observed shape")
    return {
        "table": declaration["table"],
        "status": "nonempty_unreviewed",
        "reason": declaration["reason"],
        "observed_rows": len(source["rows"]),
        "source_qualified_rows": 0,
        "complete_source_row_count": None,
        "observation_field": ["structured_observation", "tables", declaration["table"]],
    }


def _rows(outcome, qualification, context):
    selected = qualification["table_roles"]
    funding_field, funding_index = qualification["context_fields"]["funding_label"]
    funding_literal = outcome[funding_field][funding_index].split(None, 2)[2]
    row_contexts = _row_contexts(outcome, qualification, context)
    if any(type(item["table"]) is not int for item in selected) or [item["table"] for item in selected] != list(
        range(len(outcome["tables"]))
    ):
        raise ValueError("Senate office review omits, repeats or reorders an observed table")
    roles = tuple(_OFFICE_COLUMNS)
    money_roles = roles[1:]
    expected_period = (qualification["report_period_start"], qualification["report_period_end"])
    if not expected_period[0] <= expected_period[1]:
        raise ValueError("Senate office report period is reversed")
    grids, records, empty, unreviewed = [], [], [], []
    for item, source in zip(selected, outcome["tables"], strict=True):
        table_index, kind = item["table"], item["role"]
        if set(source) != {"title", "columns", "rows"}:
            raise ValueError("Unsupported Senate office table fields")
        title_field = item.get("title_field")
        if source["title"]:
            heading_field, heading_index = qualification["context_fields"]["section_heading"]
            if (
                kind != "office_summary"
                or type(title_field) is not list
                or len(title_field) != 2
                or type(title_field[1]) is not int
                or title_field != [heading_field, heading_index]
                or source["title"] != outcome[heading_field][heading_index]
            ):
                raise ValueError("Senate office table title lacks its reviewed section-heading occurrence")
        elif title_field is not None:
            raise ValueError("Senate office table title reference names a blank title")
        if kind == "observed_empty_ledger":
            if tuple(source["columns"]) != _LEDGER_COLUMNS or source["rows"]:
                raise ValueError("Senate ledger is not an observed empty grid")
            empty.append({"table": table_index, "status": "observed_empty", "observation": deepcopy(source)})
            continue
        if kind == "unreviewed_ledger":
            unreviewed.append(_unreviewed_ledger(source, item))
            continue
        if kind != "office_summary" or len(source["columns"]) != len(roles) or not source["rows"]:
            raise ValueError("Unsupported or empty Senate office summary grid")
        columns = source["columns"]
        if columns[0] != "DESCRIPTION" or columns[3] != "TOTAL FUNDING YTD ($)":
            raise ValueError("Senate office summary column roles or currency differ")
        if any(
            not columns[index].startswith(_OFFICE_COLUMNS[role] + " ") or not columns[index].endswith(" ($)")
            for index, role in enumerate(roles)
            if index in {1, 2}
        ):
            raise ValueError("Senate office summary lacks its dated currency headers")
        header = _table(qualification["page"], {**source, "rows": []})
        if table_period(header) != expected_period:
            raise ValueError("Senate summary dates differ from the reviewed reporting period")
        for index, wanted in ((1, (expected_period[0], None)), (2, expected_period)):
            one = _table(qualification["page"], {"columns": [columns[index]], "rows": [], "title": ""})
            if table_period(one) != wanted:
                raise ValueError("Senate summary headers state conflicting reporting dates")
        for row_index, row in enumerate(source["rows"]):
            if (
                set(row) != {"context", "cells"}
                or len(row["cells"]) != len(roles)
                or any(not isinstance(cell, str) for cell in row["cells"])
                or row["context"] not in row_contexts
            ):
                raise ValueError("Senate summary row is unreadable or conflicts with its office")
            label, *money = row["cells"]
            if not label.strip():
                raise ValueError("Senate summary row lacks its printed label")
            row_kind = office_summary_kind(label)
            if row_kind == "unexpended_balance":
                closing = _table(qualification["page"], {"columns": [label], "rows": [], "title": ""})
                if table_period(closing) != (None, expected_period[1]):
                    raise ValueError("Senate closing balance date differs from the reporting period")
            values = {}
            for role, raw in zip(money_roles, money, strict=True):
                if raw == "":
                    values[role] = None
                elif _STRUCTURED_MONEY.fullmatch(raw.strip()) is None or parse_amount(raw) is None:
                    raise ValueError("Senate summary money cell is not an exact monetary literal")
                else:
                    values[role] = str(parse_amount(raw))
            records.append(
                {
                    "table": table_index,
                    "row": row_index,
                    "grid_kind": "organization_detail",
                    "row_kind": row_kind,
                    "label": label,
                    "appropriation_title": context["appropriation_title"],
                    "appropriation_number": None,
                    "funding_year_literal": funding_literal,
                    "period_start": expected_period[0],
                    "period_end": expected_period[1],
                    "values": values,
                    "raw_fields": dict(zip(money_roles, money, strict=True)),
                    "issues": [],
                    "source_origin": {
                        "method": "reviewed_structured_observation",
                        "table": table_index,
                        "row": row_index,
                        "context_literal": row["context"],
                        "box": None,
                        "cells": {
                            role: {"table": table_index, "row": row_index, "column": index}
                            for index, role in enumerate(roles)
                            if index
                        },
                    },
                }
            )
        grids.append(
            {
                "table": table_index,
                "grid_kind": "organization_detail",
                "period_start": expected_period[0],
                "period_end": expected_period[1],
                "observation": json.loads(json.dumps(asdict(_table(qualification["page"], source)))),
                "coordinate_basis": "structured response order; no source cell geometry",
            }
        )
    if not records or _structured_counts(records) != qualification["counts"]:
        raise ValueError("Senate office summary differs from its reviewed row/cell coverage")
    return grids, records, empty, unreviewed


def read_senate_office_observation(outcome, *, binding, qualification, configuration):
    """Normalize source-reviewed office fields after shared offline capture replay."""
    if set(outcome) != {"page_label", "headings", "tables", "other_text", "uncertainties"}:
        raise ValueError("Unsupported structured Senate office fields")
    for rule in qualification.get("corrections", []):
        for edit in rule["edits"]:
            path = edit["path"]
            allowed = (
                path == ["page_label"]
                or len(path) == 4
                and path[0] == "tables"
                and path[2] == "columns"
                or len(path) == 6
                and path[0] == "tables"
                and path[2] == "rows"
                and path[4:] == ["cells", 0]
            )
            if not allowed:
                raise ValueError("Senate office corrections cannot alter monetary cells or unrelated fields")
    normalized, audit = reviewed_observation(
        outcome, binding=binding, qualification=qualification, schema=QUALIFICATION, status=STATUS
    )
    context = _context(normalized, qualification)
    grids, records, empty, unreviewed = _rows(normalized, qualification, context)
    for ledger in unreviewed:
        # Summary review supplies no authority to change a ledger's fields.
        # Refer to the retained observation rather than copy its data again.
        index = ledger["table"]
        if normalized["tables"][index] != outcome["tables"][index]:
            raise ValueError("Unreviewed Senate ledger fields cannot be corrected")
    for grid in grids:
        grid["observation"]["raw"] = deepcopy(outcome["tables"][grid["table"]])
        grid["observation_basis"] = "normalized_observation" if audit else "structured_observation"
    page = {
        "rule": RULE,
        "reading_method": METHOD,
        "source_sha256": binding["source_sha256"],
        "source_byte_size": binding["source_byte_size"],
        "page": binding["page"],
        "source_page": binding["page"],
        "physical_pages": qualification["physical_pages"],
        "printed_page": normalized["page_label"],
        "context": context,
        "context_basis": "independent_source_field_review",
        "context_origin": deepcopy(qualification["context_fields"]),
        "records": records,
        "grids": grids,
        "empty_ledgers": empty,
        "issues": ["text_not_fully_source_qualified"],
        "status": STATUS,
        "structured_observation": deepcopy(outcome),
        "normalized_observation": normalized,
        "observation_corrections": audit,
        "structured_provenance": {
            "qualification": deepcopy(qualification),
            "binding": deepcopy(binding),
            "configuration": deepcopy(configuration),
            "geometry": None,
        },
    }
    if unreviewed:
        page["unreviewed_ledgers"] = unreviewed
        page["issues"].append("unreviewed_ledger_present")
    return page


def validate_senate_office_observation(page):
    """Reconstruct every source field; the host separately replays capture bytes."""
    provenance = page["structured_provenance"]
    expected = read_senate_office_observation(
        page["structured_observation"],
        binding=provenance["binding"],
        qualification=provenance["qualification"],
        configuration=provenance["configuration"],
    )
    if page != expected:
        raise ValueError("Senate office summary differs from its retained observation and reviewed fields")
