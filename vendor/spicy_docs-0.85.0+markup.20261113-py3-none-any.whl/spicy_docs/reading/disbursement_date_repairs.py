"""Apply reviewed date corrections only to their exact retained source rows.

Source readers choose date fields and supply independently approved rules.
This module owns the common identity checks and audit record; it neither
infers a correction nor changes a raw field, amount or source occurrence.
"""

from __future__ import annotations

from datetime import date


def apply_date_repairs(
    page,
    byte_size,
    rules,
    *,
    printed_page,
    date_fields,
    service_fields,
):
    """Match original bytes, page, literal cells and any declared row context."""
    for rule in rules:
        if (rule["source_sha256"], rule["source_page"]) != (page["source_sha256"], page["source_page"]):
            continue
        matches = [
            row
            for row in page["records"]
            if row["raw_fields"] == rule["raw_fields"] and ("line" not in rule or row["line"] == rule["line"])
        ]
        if byte_size != rule["source_byte_size"] or len(matches) != 1 or printed_page != rule["printed_page"]:
            raise ValueError("Disbursement date repair differs from its exact reviewed source row")
        row = matches[0]
        if "group_origin" in rule and row["group_origin"] != rule["group_origin"]:
            raise ValueError("Disbursement date repair differs from its reviewed voucher continuation")
        if any(row.get(key) != value for key, value in rule.get("row_context", {}).items()):
            raise ValueError("Disbursement date repair differs from its reviewed account context")
        resolved = []
        for change in rule["changes"]:
            field = change["field"]
            if field not in date_fields:
                raise ValueError("Disbursement date repair may change only declared date fields")
            if row["raw_fields"][field] != change["raw_before"]:
                raise ValueError("Disbursement date repair original field differs")
            if "normalized_before" in change and row[field] != change["normalized_before"]:
                raise ValueError("Disbursement date repair differs from its reviewed prior date")
            if date.fromisoformat(change["normalized_after"]).isoformat() != change["normalized_after"]:
                raise ValueError("Disbursement date repair requires a canonical ISO date")
            row[field] = change["normalized_after"]
            issue = "invalid_" + field
            if issue in row["issues"]:
                row["issues"].remove(issue)
                resolved.append(issue)
        start, end = (row[field] for field in service_fields)
        if "reversed_service_dates" in row["issues"] and start and end and start <= end:
            row["issues"].remove("reversed_service_dates")
            resolved.append("reversed_service_dates")
        row["repairs"].append({**rule, "resolved_issues": resolved})
