"""Pinned ``LibraryOfCongress/api.congress.gov`` documentation digests and reviewed issue limits.

Offline by default: :func:`load_upstream_pin` validates the packaged ``upstream_pin.json``
against ``LIST_ROUTES`` without making network calls. Run ``python -m
spicy_docs.sources.congress.upstream_pin --live`` on demand to compare the pinned Git blob
SHAs against ``LibraryOfCongress/api.congress.gov`` via ``gh api`` (exiting ``0`` when
unchanged and ``2`` when upstream ``ChangeLog.md`` or endpoint docs move).
"""

from __future__ import annotations

import argparse
import base64
import binascii
import json
import re
import subprocess
from collections.abc import Callable, Mapping, Sequence
from importlib.resources import files
from pathlib import Path
from typing import Any

from spicy_docs.sources.congress.listing import LIST_ROUTES

CONGRESS_API_UPSTREAM_REPO = "LibraryOfCongress/api.congress.gov"
CONGRESS_API_CHANGELOG_BLOB_SHA = "dc22db035ba18c3d4603555c0dbf0b93b93d259f"
CONGRESS_API_CHANGELOG_COMMIT_SHA = "bf9417c07d1a49cc211cba71756f4bd367561642"

_SHA1_HEX_RE = re.compile(r"^[0-9a-f]{40}$")
_DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")


class CongressUpstreamPinError(ValueError):
    """Malformed upstream pin or invalid live GitHub API payload."""


def validate_upstream_pin(pin: Any) -> dict[str, Any]:
    """Validate pin schema, Git blob digests, reviewed issue entries, and route names offline."""
    if not isinstance(pin, dict):
        raise CongressUpstreamPinError("upstream pin must be a JSON object")
    repo = pin.get("repo")
    if not isinstance(repo, str) or "/" not in repo or repo != repo.strip():
        raise CongressUpstreamPinError("upstream pin requires repo as 'owner/name'")
    reviewed_at = pin.get("reviewed_at")
    if not isinstance(reviewed_at, str) or _DATE_RE.fullmatch(reviewed_at) is None:
        raise CongressUpstreamPinError("upstream pin requires ISO date reviewed_at")

    changelog = pin.get("changelog")
    if not isinstance(changelog, dict):
        raise CongressUpstreamPinError("upstream pin requires changelog object")
    for field in ("path", "blob_sha", "latest_commit_sha", "latest_commit_date", "latest_heading"):
        value = changelog.get(field)
        if not isinstance(value, str) or not value.strip():
            raise CongressUpstreamPinError(f"changelog missing nonempty {field}")
    if _SHA1_HEX_RE.fullmatch(changelog["blob_sha"]) is None:
        raise CongressUpstreamPinError("invalid changelog blob_sha")
    if _SHA1_HEX_RE.fullmatch(changelog["latest_commit_sha"]) is None:
        raise CongressUpstreamPinError("invalid changelog latest_commit_sha")
    if not changelog["latest_heading"].startswith("# "):
        raise CongressUpstreamPinError("changelog latest_heading must start with '# '")
    cl_bytes = changelog.get("bytes")
    if type(cl_bytes) is not int or cl_bytes <= 0:
        raise CongressUpstreamPinError("changelog bytes must be a positive integer")

    docs = pin.get("docs")
    if not isinstance(docs, dict) or not docs:
        raise CongressUpstreamPinError("upstream pin requires nonempty docs map")
    for doc_path, meta in docs.items():
        if not isinstance(doc_path, str) or not doc_path.strip() or not isinstance(meta, dict):
            raise CongressUpstreamPinError(f"invalid doc pin entry: {doc_path!r}")
        if _SHA1_HEX_RE.fullmatch(str(meta.get("blob_sha", ""))) is None:
            raise CongressUpstreamPinError(f"invalid doc blob_sha for {doc_path}")
        doc_bytes = meta.get("bytes")
        if type(doc_bytes) is not int or doc_bytes <= 0:
            raise CongressUpstreamPinError(f"invalid doc bytes for {doc_path}")

    issues = pin.get("reviewed_issues")
    if not isinstance(issues, list) or not issues:
        raise CongressUpstreamPinError("upstream pin requires nonempty reviewed_issues list")
    seen_numbers: set[int] = set()
    for index, entry in enumerate(issues):
        if not isinstance(entry, dict):
            raise CongressUpstreamPinError(f"reviewed_issues[{index}] must be an object")
        number = entry.get("number")
        if type(number) is not int or number <= 0:
            raise CongressUpstreamPinError(f"reviewed_issues[{index}] requires positive integer number")
        if number in seen_numbers:
            raise CongressUpstreamPinError(f"reviewed_issues repeats issue #{number}")
        seen_numbers.add(number)
        for text_field in ("state", "title", "impact"):
            val = entry.get(text_field)
            if not isinstance(val, str) or not val.strip():
                raise CongressUpstreamPinError(f"reviewed_issues[{index}] missing {text_field}")
        if entry["state"] not in {"open", "closed"}:
            raise CongressUpstreamPinError(f"reviewed_issues[{index}] state must be 'open' or 'closed'")
        routes = entry.get("affected_routes")
        if not isinstance(routes, list) or not routes or any(not isinstance(r, str) for r in routes):
            raise CongressUpstreamPinError(f"reviewed_issues[{index}] requires nonempty affected_routes list")
        unknown_routes = [r for r in routes if r not in LIST_ROUTES]
        if unknown_routes:
            raise CongressUpstreamPinError(
                f"reviewed_issues[{index}] (#{number}) names unknown LIST_ROUTES: {unknown_routes}"
            )
    return pin


def load_upstream_pin(pin_path: Path | None = None) -> dict[str, Any]:
    """Load and validate ``upstream_pin.json`` from package resources or an explicit path."""
    if pin_path is None:
        raw = files("spicy_docs.sources.congress").joinpath("upstream_pin.json").read_text(encoding="utf-8")
    else:
        raw = pin_path.read_text(encoding="utf-8")
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as error:
        raise CongressUpstreamPinError(f"upstream pin is not valid JSON: {error}") from error
    return validate_upstream_pin(parsed)


def extract_new_changelog_sections(markdown_text: str, known_heading: str) -> tuple[list[str], bool]:
    """Return top-level ``# ...`` sections preceding ``known_heading`` plus whether ``known_heading`` was found."""
    sections: list[str] = []
    current: list[str] = []
    target = known_heading.strip()
    for line in markdown_text.splitlines():
        if line.startswith("# "):
            if line.strip() == target:
                if current:
                    sections.append("\n".join(current))
                return sections, True
            if current:
                sections.append("\n".join(current))
            current = [line]
        elif current:
            current.append(line)
    if current:
        sections.append("\n".join(current))
    return sections, False


def fetch_github_contents_json(api_path: str, *, timeout_seconds: float = 30.0) -> dict[str, Any]:
    """Read-only GitHub Contents lookup via ``gh api``."""
    out = subprocess.check_output(["gh", "api", api_path], text=True, timeout=timeout_seconds)
    try:
        parsed = json.loads(out)
    except json.JSONDecodeError as error:
        raise CongressUpstreamPinError(f"gh api {api_path} returned invalid JSON: {error}") from error
    if not isinstance(parsed, dict) or not isinstance(parsed.get("sha"), str):
        raise CongressUpstreamPinError(f"gh api {api_path} response missing string 'sha'")
    return parsed


def check_live_upstream_pin(
    pin: Mapping[str, Any],
    *,
    fetch: Callable[[str], Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Compare pinned Git blob SHAs against live ``LibraryOfCongress/api.congress.gov`` contents."""
    validated = validate_upstream_pin(dict(pin))
    reader = fetch_github_contents_json if fetch is None else fetch
    repo = validated["repo"]
    drifted: list[dict[str, Any]] = []

    cl = validated["changelog"]
    cl_live = reader(f"repos/{repo}/contents/{cl['path']}")
    live_cl_sha = cl_live.get("sha")
    if not isinstance(live_cl_sha, str) or _SHA1_HEX_RE.fullmatch(live_cl_sha) is None:
        raise CongressUpstreamPinError(f"live changelog response missing valid sha: {live_cl_sha!r}")
    if live_cl_sha != cl["blob_sha"]:
        raw_b64 = cl_live.get("content")
        text = ""
        if isinstance(raw_b64, str) and raw_b64.strip():
            try:
                text = base64.b64decode(raw_b64).decode("utf-8", "replace")
            except (binascii.Error, ValueError) as error:
                raise CongressUpstreamPinError(f"live changelog base64 decode failed: {error}") from error
        new_sections, found_known_heading = extract_new_changelog_sections(text, cl["latest_heading"])
        drifted.append(
            {
                "path": cl["path"],
                "pinned_sha": cl["blob_sha"],
                "live_sha": live_cl_sha,
                "known_heading_found": found_known_heading,
                "new_sections": new_sections,
            }
        )

    for doc_path, meta in validated["docs"].items():
        live_doc = reader(f"repos/{repo}/contents/{doc_path}")
        live_doc_sha = live_doc.get("sha")
        if not isinstance(live_doc_sha, str) or _SHA1_HEX_RE.fullmatch(live_doc_sha) is None:
            raise CongressUpstreamPinError(f"live {doc_path} response missing valid sha: {live_doc_sha!r}")
        if live_doc_sha != meta["blob_sha"]:
            drifted.append(
                {
                    "path": doc_path,
                    "pinned_sha": meta["blob_sha"],
                    "live_sha": live_doc_sha,
                }
            )

    return {
        "repo": repo,
        "up_to_date": not drifted,
        "drifted": drifted,
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pin", type=Path, help="Optional path to upstream_pin.json (defaults to packaged pin)")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--offline", action="store_true", help="Validate packaged pin offline (default; no network)")
    mode.add_argument("--live", action="store_true", help="Compare pinned blob SHAs against live GitHub repository")
    args = parser.parse_args(argv)

    pin = load_upstream_pin(args.pin)
    if args.offline or not args.live:
        print(
            json.dumps(
                {
                    "repo": pin["repo"],
                    "reviewed_at": pin["reviewed_at"],
                    "changelog_blob_sha": pin["changelog"]["blob_sha"],
                    "changelog_latest_commit_sha": pin["changelog"]["latest_commit_sha"],
                    "reviewed_issues": [item["number"] for item in pin["reviewed_issues"]],
                },
                indent=2,
            )
        )
        return 0

    status = check_live_upstream_pin(pin)
    print(json.dumps(status, indent=2))
    return 0 if status["up_to_date"] else 2


__all__ = [
    "CONGRESS_API_CHANGELOG_BLOB_SHA",
    "CONGRESS_API_CHANGELOG_COMMIT_SHA",
    "CONGRESS_API_UPSTREAM_REPO",
    "CongressUpstreamPinError",
    "check_live_upstream_pin",
    "extract_new_changelog_sections",
    "fetch_github_contents_json",
    "load_upstream_pin",
    "main",
    "validate_upstream_pin",
]


if __name__ == "__main__":
    raise SystemExit(main())
