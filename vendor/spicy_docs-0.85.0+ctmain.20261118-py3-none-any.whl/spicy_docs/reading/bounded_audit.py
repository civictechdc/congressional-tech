"""Stdlib-only bounded PDF/XML inspection and visual-review audit builders."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any
from xml.parsers import expat

from spicy_docs.reading.pdf_bytes import check_pdf_bytes, linearized_length, terminal_xref_offset
from spicy_docs.reading.xml import scan_xml
from spicy_docs.sources.contracts import (
    BoundedLimits,
    LocatorSpan,
    ReaderFinding,
    VisualReviewAudit,
    canonical_sha256,
)

_PDF_PAGE_OBJECT = re.compile(rb"/Type\s*/Page(?![A-Za-z])")


class AuditInspectionError(ValueError):
    """Raised when an inspection request's own bounds are invalid."""


@dataclass(frozen=True, slots=True)
class XmlStructureInspection:
    """Bounded structural inspection of an XML body with separate byte/text/XPath coordinates."""

    outcome: str
    root_tag: str | None
    element_count: int
    max_depth_observed: int
    decoded_char_count: int
    sample_xpaths: tuple[str, ...]
    findings: tuple[ReaderFinding, ...]
    limits: BoundedLimits


@dataclass(frozen=True, slots=True)
class PdfStructureInspection:
    """Bounded inspection and optional extraction summary of a PDF artifact."""

    outcome: str
    page_count_estimate: int | None
    pages_reviewed: tuple[int, ...]
    linearized_length: int | None
    terminal_xref_offset: int | None
    extracted_text: str | None
    findings: tuple[ReaderFinding, ...]
    limits: BoundedLimits


def inspect_xml_bytes(
    data: bytes,
    *,
    uri: str,
    max_bytes: int,
    max_elements: int = 100_000,
    max_depth: int = 256,
    max_findings: int = 128,
    allow_external_doctype: bool = False,
    reviewed_at: str | None = None,
) -> tuple[XmlStructureInspection, VisualReviewAudit]:
    """Scan XML bytes safely, separating raw byte size from XPath positions and decoded char counts."""
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or max_bytes <= 0:
        raise AuditInspectionError("max_bytes must be a positive integer")
    if isinstance(max_elements, bool) or not isinstance(max_elements, int) or max_elements <= 0:
        raise AuditInspectionError("max_elements must be a positive integer")
    if isinstance(max_findings, bool) or not isinstance(max_findings, int) or max_findings <= 0:
        raise AuditInspectionError("max_findings must be a positive integer")

    source_sha = canonical_sha256(data)
    stack: list[int] = []
    child_counts: list[int] = []
    root_tag: str | None = None
    element_count = 0
    max_depth_observed = 0
    text_chunks: list[str] = []
    decoded_chars = 0
    sample_xpaths: list[str] = []
    findings: list[ReaderFinding] = []
    truncated = False

    class _ScanFailure(ValueError):
        pass

    def _add_finding(code: str, severity: str, message: str, *, locator: LocatorSpan | None = None) -> None:
        if len(findings) < max_findings:
            findings.append(ReaderFinding(code=code, severity=severity, message=message, locator=locator))  # type: ignore[arg-type]

    def on_start(tag: str, _attrs: dict[str, str]) -> None:
        nonlocal root_tag, element_count, max_depth_observed, truncated
        element_count += 1
        if element_count > max_elements:
            truncated = True
            _add_finding("XML-ELEMENT-LIMIT", "warning", f"XML element count exceeded max_elements={max_elements}")
            raise _ScanFailure("element limit exceeded")
        if not child_counts:
            root_tag = tag
            stack.append(1)
        else:
            child_counts[-1] += 1
            stack.append(child_counts[-1])
        child_counts.append(0)
        max_depth_observed = max(max_depth_observed, len(stack))
        if len(sample_xpaths) < 16:
            sample_xpaths.append("".join(f"/*[{idx}]" for idx in stack))

    def on_end(_tag: str) -> None:
        if stack:
            stack.pop()
        if child_counts:
            child_counts.pop()

    def on_data(value: str) -> None:
        nonlocal decoded_chars
        decoded_chars += len(value)
        text_chunks.append(value)

    outcome = "retained"
    if not data:
        outcome = "incomplete"
        _add_finding("XML-EMPTY-BYTES", "error", "XML response body is empty")
    else:
        try:
            scan_xml(
                data,
                start=on_start,
                end=on_end,
                data=on_data,
                max_bytes=max_bytes,
                max_depth=max_depth,
                allow_external_doctype=allow_external_doctype,
                error_type=_ScanFailure,
                label="XML source document",
            )
            if element_count == 0:
                outcome = "empty"
                _add_finding("XML-NO-ELEMENTS", "info", "XML contains no elements")
            elif decoded_chars == 0 or not "".join(text_chunks).strip():
                _add_finding(
                    "XML-EMPTY-TEXT",
                    "info",
                    "XML parsed validly with whitespace-only or empty character data",
                    locator=LocatorSpan(locator_kind="xml_xpath", uri=uri, source_xpath="/*[1]"),
                )
        except _ScanFailure as exc:
            msg = str(exc)
            cause = exc.__cause__
            cause_msg = str(cause) if cause is not None else ""
            is_truncated_xml = truncated or (
                isinstance(cause, expat.ExpatError)
                and (
                    "no element found" in cause_msg
                    or "unclosed token" in cause_msg
                    or "unclosed CDATA" in cause_msg
                    or (bool(stack) and "mismatched tag" not in cause_msg)
                )
            )
            if is_truncated_xml:
                outcome = "incomplete"
                if not any(f.code == "XML-ELEMENT-LIMIT" for f in findings):
                    _add_finding("XML-TRUNCATED", "error", f"{msg}: {cause_msg}".rstrip(": "))
            else:
                outcome = "failed"
                _add_finding("XML-INVALID", "error", f"{msg}: {cause_msg}".rstrip(": "))

    text_joined = "".join(text_chunks)
    text_sha = canonical_sha256(text_joined.encode("utf-8")) if outcome in ("retained", "empty") else None
    limits = BoundedLimits(
        max_bytes=max_bytes,
        max_records=max_elements,
        max_depth=max_depth,
        truncated=truncated,
    )
    primary_locator = (
        LocatorSpan(locator_kind="xml_xpath", uri=uri, source_xpath=sample_xpaths[0])
        if sample_xpaths
        else LocatorSpan(locator_kind="raw_bytes", uri=uri, byte_offset=0, byte_length=len(data))
    )
    inspection = XmlStructureInspection(
        outcome=outcome,
        root_tag=root_tag,
        element_count=element_count,
        max_depth_observed=max_depth_observed,
        decoded_char_count=decoded_chars,
        sample_xpaths=tuple(sample_xpaths),
        findings=tuple(findings),
        limits=limits,
    )
    audit = VisualReviewAudit(
        source_sha256=source_sha,
        locator=primary_locator,
        rendition="xml",
        extraction_method="scan_xml",
        findings=tuple(findings),
        limits=limits,
        pages_reviewed=(),
        text_sha256=text_sha,
        reviewed_at=reviewed_at,
        truncated=truncated,
    )
    return inspection, audit


def inspect_pdf_bytes(
    data: bytes,
    *,
    uri: str,
    max_bytes: int,
    pages: Sequence[int] | None = None,
    extractor: Any | None = None,
    max_pages: int = 64,
    max_findings: int = 128,
    reviewed_at: str | None = None,
) -> tuple[PdfStructureInspection, VisualReviewAudit]:
    """Check PDF completeness and extract bounded page/visual-review telemetry."""
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or max_bytes <= 0:
        raise AuditInspectionError("max_bytes must be a positive integer")
    if isinstance(max_pages, bool) or not isinstance(max_pages, int) or max_pages <= 0:
        raise AuditInspectionError("max_pages must be a positive integer")
    if isinstance(max_findings, bool) or not isinstance(max_findings, int) or max_findings <= 0:
        raise AuditInspectionError("max_findings must be a positive integer")

    source_sha = canonical_sha256(data)
    findings: list[ReaderFinding] = []
    truncated = False

    def _add(code: str, severity: str, message: str, *, locator: LocatorSpan | None = None) -> None:
        if len(findings) < max_findings:
            findings.append(ReaderFinding(code=code, severity=severity, message=message, locator=locator))  # type: ignore[arg-type]

    if not data:
        _add("PDF-EMPTY-BYTES", "error", "PDF byte payload is empty")
        limits = BoundedLimits(max_bytes=max_bytes, max_pages=max_pages, truncated=False)
        loc = LocatorSpan(locator_kind="raw_bytes", uri=uri, byte_offset=0, byte_length=0)
        return (
            PdfStructureInspection("incomplete", None, (), None, None, None, tuple(findings), limits),
            VisualReviewAudit(
                source_sha, loc, "pdf", "pdf-bytes-check", tuple(findings), limits, (), None, reviewed_at, False
            ),
        )

    if len(data) > max_bytes:
        _add("PDF-BYTE-LIMIT", "error", f"PDF length {len(data)} exceeds max_bytes={max_bytes}")
        limits = BoundedLimits(max_bytes=max_bytes, max_pages=max_pages, truncated=True)
        loc = LocatorSpan(locator_kind="raw_bytes", uri=uri, byte_offset=0, byte_length=len(data))
        return (
            PdfStructureInspection("failed", None, (), None, None, None, tuple(findings), limits),
            VisualReviewAudit(
                source_sha, loc, "pdf", "pdf-bytes-check", tuple(findings), limits, (), None, reviewed_at, True
            ),
        )

    class _PdfStructError(ValueError):
        pass

    outcome = "retained"
    declared_len: int | None = None
    xref_off: int | None = None
    try:
        check_pdf_bytes(data, error_type=_PdfStructError, label="PDF document")
        declared_len = linearized_length(data)
        xref_off = terminal_xref_offset(data)
        if declared_len is not None and declared_len != len(data):
            raise _PdfStructError(f"PDF linearized length {declared_len} disagrees with captured {len(data)} bytes")
    except _PdfStructError as exc:
        msg = str(exc)
        is_pdf_prefix = data.lstrip().startswith(b"%PDF-")
        outcome = "incomplete" if is_pdf_prefix else "failed"
        _add(
            "PDF-TRUNCATED" if is_pdf_prefix else "PDF-INVALID-HEADER",
            "error",
            msg,
            locator=LocatorSpan(locator_kind="raw_bytes", uri=uri, byte_offset=0, byte_length=len(data)),
        )
        limits = BoundedLimits(max_bytes=max_bytes, max_pages=max_pages, truncated=False)
        loc = LocatorSpan(locator_kind="raw_bytes", uri=uri, byte_offset=0, byte_length=len(data))
        return (
            PdfStructureInspection(outcome, None, (), declared_len, xref_off, None, tuple(findings), limits),
            VisualReviewAudit(
                source_sha, loc, "pdf", "pdf-bytes-check", tuple(findings), limits, (), None, reviewed_at, False
            ),
        )

    page_estimate = max(len(_PDF_PAGE_OBJECT.findall(data)), 1 if b"/Pages" in data or b"/Page" in data else 0)
    extracted_chunks: list[str] = []
    pages_reviewed: list[int] = []
    extraction_method = "pdf-bytes-check"

    if extractor is not None:
        extraction_method = type(extractor).__name__
        selected_pages = tuple(pages) if pages is not None else None
        if selected_pages is not None and len(selected_pages) > max_pages:
            selected_pages = selected_pages[:max_pages]
            truncated = True
            _add("PDF-PAGE-LIMIT", "warning", f"Selected pages truncated to max_pages={max_pages}")
        raw_results = extractor.extract(data, media_type="application/pdf", pages=selected_pages)
        for index, page_result in enumerate(raw_results, start=1):
            if len(pages_reviewed) >= max_pages:
                truncated = True
                _add("PDF-PAGE-LIMIT", "warning", f"Page extraction truncated at max_pages={max_pages}")
                break
            meta = getattr(page_result, "metadata", {}) or {}
            page_no = int(meta.get("page", index))
            pages_reviewed.append(page_no)
            page_text = getattr(page_result, "text", "") or ""
            extracted_chunks.append(page_text)
            if not page_text.strip():
                _add(
                    "PDF-BLANK-PAGE-TEXT",
                    "warning",
                    f"Extracted page {page_no} has empty native text; visual review/OCR candidate",
                    locator=LocatorSpan(locator_kind="pdf_page", uri=uri, page_number=page_no),
                )
            content = getattr(page_result, "content", None)
            if content is not None:
                for obs in getattr(content, "observations", ()):
                    for issue in getattr(obs, "issues", ()):
                        _add(
                            str(getattr(issue, "code", "EXTRACTION-ISSUE")),
                            "warning",
                            str(getattr(issue, "message", str(issue))),
                            locator=LocatorSpan(locator_kind="pdf_page", uri=uri, page_number=page_no),
                        )
    else:
        default_limit = min(page_estimate, max_pages) if page_estimate > 0 else 0
        if pages is not None:
            requested = tuple(pages)
            if len(requested) > max_pages:
                truncated = True
                _add("PDF-PAGE-LIMIT", "warning", f"Requested pages truncated to max_pages={max_pages}")
            pages_reviewed = list(requested[:max_pages])
        elif default_limit > 0:
            if page_estimate > max_pages:
                truncated = True
                _add("PDF-PAGE-LIMIT", "warning", f"Estimated {page_estimate} pages exceeds max_pages={max_pages}")
            pages_reviewed = list(range(1, default_limit + 1))

    if page_estimate == 0 and not pages_reviewed:
        outcome = "empty"
        _add("PDF-NO-PAGES", "warning", "Valid PDF structure declares zero pages")

    extracted_text = "\n".join(extracted_chunks) if extracted_chunks else None
    text_sha = canonical_sha256(extracted_text.encode("utf-8")) if extracted_text is not None else None
    first_page = pages_reviewed[0] if pages_reviewed else None
    primary_locator: LocatorSpan = (
        LocatorSpan(locator_kind="pdf_page", uri=uri, page_number=first_page)
        if first_page is not None
        else LocatorSpan(locator_kind="raw_bytes", uri=uri, byte_offset=0, byte_length=len(data))
    )
    limits = BoundedLimits(max_bytes=max_bytes, max_pages=max_pages, truncated=truncated)
    inspection = PdfStructureInspection(
        outcome=outcome,
        page_count_estimate=page_estimate,
        pages_reviewed=tuple(pages_reviewed),
        linearized_length=declared_len,
        terminal_xref_offset=xref_off,
        extracted_text=extracted_text,
        findings=tuple(findings),
        limits=limits,
    )
    audit = VisualReviewAudit(
        source_sha256=source_sha,
        locator=primary_locator,
        rendition="pdf",
        extraction_method=extraction_method,
        findings=tuple(findings),
        limits=limits,
        pages_reviewed=tuple(pages_reviewed),
        text_sha256=text_sha,
        reviewed_at=reviewed_at,
        truncated=truncated,
    )
    return inspection, audit


def build_visual_review_audit(
    *,
    source_bytes: bytes,
    uri: str,
    rendition: str,
    extraction_method: str,
    locator: LocatorSpan | Mapping[str, Any],
    findings: Sequence[ReaderFinding] = (),
    limits: BoundedLimits | None = None,
    pages_reviewed: Sequence[int] = (),
    extracted_text: str | None = None,
    reviewed_at: str | None = None,
    truncated: bool = False,
) -> VisualReviewAudit:
    """Construct a canonical VisualReviewAudit binding extracted observations back to immutable input bytes."""
    return VisualReviewAudit(
        source_sha256=canonical_sha256(source_bytes),
        locator=locator,
        rendition=rendition,
        extraction_method=extraction_method,
        findings=tuple(findings),
        limits=limits or BoundedLimits(truncated=truncated),
        pages_reviewed=tuple(pages_reviewed),
        text_sha256=canonical_sha256(extracted_text.encode("utf-8")) if extracted_text is not None else None,
        reviewed_at=reviewed_at,
        truncated=truncated,
    )


__all__ = [
    "AuditInspectionError",
    "PdfStructureInspection",
    "XmlStructureInspection",
    "build_visual_review_audit",
    "inspect_pdf_bytes",
    "inspect_xml_bytes",
]
