"""House Clerk ``MemberData.xml`` and Senate ``cvc_member_data.xml``: the current committee assignments.

Congress.gov is the roster of record for identity and history; these two
chamber files add exactly what it does not carry -- which member sits on which
committee today and, for the Senate, the LIS id beside the bioguide (the LIS
crosswalk itself stays ``sources/legislators.py``, so nothing here builds a
second one). :func:`parse_house_member_data` checks the file's stated
``congress-num``/``session`` against the caller's before reading any member,
treats ``<committee rank=""/>`` as "no assignment" (counted and skipped, never
refused), and keeps leadership strings verbatim; the Senate file states no
Congress, so :func:`parse_senate_cvc` proves only its root, its update date and
that every senator carries both ids, and a row built from it says
``congress_basis = "caller"``. :func:`house_system_code` and
:func:`senate_system_code` are the measured ``systemCode`` joins to
Congress.gov's own codes.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import TYPE_CHECKING
from xml.etree.ElementTree import Element

from spicy_docs.reading.rss import child_text, single_child
from spicy_docs.reading.xml import parse_xml
from spicy_docs.transport.captured import CapturedBodyResponse
from spicy_docs.transport.source_acquirer import (
    SourceAcquirer,
    check_byte_bound,
    check_request_count,
    check_timing,
    named_challenge,
    narrow_byte_limit,
    utc_now,
)

if TYPE_CHECKING:
    from datetime import datetime

    import httpx

HOUSE_MEMBER_DATA_URL = "https://clerk.house.gov/xml/lists/MemberData.xml"
SENATE_CVC_URL = "https://www.senate.gov/legislative/LIS_MEMBER/cvc_member_data.xml"
MEDIA_TYPES = ("text/xml", "application/xml")

# Measured 2026-09-19: MemberData.xml 556,936 bytes, cvc_member_data.xml 67,618 bytes.
DEFAULT_MAX_HOUSE_BYTES = 4 * 1024**2
DEFAULT_MAX_SENATE_BYTES = 1 * 1024**2
MAX_ROSTER_BYTES = 16 * 1024**2

_HOUSE_INFO_FIELDS = (
    "namelist",
    "lastname",
    "firstname",
    "middlename",
    "sort-name",
    "suffix",
    "courtesy",
    "prior-congress",
    "official-name",
    "formal-name",
    "party",
    "caucus",
    "district",
    "townname",
    "office-building",
    "office-room",
    "office-zip",
    "office-zip-suffix",
    "phone",
)


class CommitteeRosterError(ValueError):
    """The response cannot establish a chamber roster file."""


class CommitteeRosterUnavailableError(CommitteeRosterError):
    def __init__(self, capture: CapturedBodyResponse) -> None:
        super().__init__(f"chamber roster source answered HTTP {capture.status_code}")
        self.capture = capture


class CommitteeRosterRefusedError(CommitteeRosterError):
    """A keyless route answered 401/403; there is no credential here to reject."""

    def __init__(self, url: str) -> None:
        super().__init__(f"chamber roster source refused access to {url}; no credential exists to reject")
        self.url = url


class CommitteeRosterIdentityError(CommitteeRosterError):
    """The House file states another Congress or session than the caller requested."""

    def __init__(self, *, requested: tuple[int, int | None], stated: tuple[int, int | None]) -> None:
        super().__init__(f"MemberData.xml states congress/session {stated}, not the requested {requested}")
        self.requested = requested
        self.stated = stated


#: The two-letter House committee codes Congress.gov spells with the ``hl``
#: (select) prefix: every ``hl..00`` system code in its committee list
#: (``tests/fixtures/listings/congress-committee-codes-2026-09-26.json``, 29
#: codes, none of which recurs under ``hs``). A source that states only the
#: uppercase code, as docs.house.gov does (``IG00``), has no committee type to
#: hand :func:`house_system_code`; this set is that type, read from the
#: publisher that owns the spelling. The congressional-tech archive's four-code
#: set (``ig vc fd qj``) is a subset and misses six docs.house.gov folders
#: (``EF CN MH ZS ZI IJ``), so it is not copied. Joint codes and task forces
#: (``htzt00``) are neither ``hs`` nor ``hl`` and stay outside this rule.
HOUSE_SELECT_COMMITTEE_CODES = frozenset(
    [
        "bz",
        "cf",
        "cn",
        "cq",
        "eb",
        "ef",
        "et",
        "fd",
        "gw",
        "hk",
        "hn",
        "ie",
        "ig",
        "ij",
        "ir",
        "mh",
        "na",
        "oc",
        "qj",
        "rk",
        "se",
        "vc",
        "zc",
        "zd",
        "ze",
        "zf",
        "zg",
        "zi",
        "zs",
    ]
)

# The 119th Congress Clerk's names block and Congress.gov committee/119 agree
# on these three joint bodies. A changed Clerk name is a conflict, not a match.
_HOUSE_JOINT_119 = {
    "JL00": ("Joint Committee on the Library", "jslc00"),
    "JP00": ("Joint Committee on Printing", "jspr00"),
    "IT00": ("Joint Committee on Taxation", "jstx00"),
}


def house_committee_prefix(committee_type: str | None) -> str:
    """``hl`` for a select committee and its subcommittees, ``hs`` for every other House code."""
    return "hl" if committee_type == "select" else "hs"


def house_system_code(comcode: str, *, committee_type: str | None = None) -> str:
    """Derive the House prefix from native committee type, preserving raw codes elsewhere.

    Standing committees use ``hs``; a declared select committee and its
    subcommittees use ``hl``. Without roster context this retains the legacy
    standing-style spelling. Joint codes need a separate evidenced crosswalk;
    this helper does not establish those joins.
    """
    code = comcode.strip().lower()
    if not code:
        raise CommitteeRosterError("a House committee code cannot be empty")
    return code if code.startswith(("hs", "hl")) else f"{house_committee_prefix(committee_type)}{code}"


def senate_system_code(code: str) -> str:
    """``SPAG00`` -> ``spag00``: the map's ``cvc→committee`` rule; every file code already ends in ``00``."""
    value = code.strip().lower()
    if not value:
        raise CommitteeRosterError("a Senate committee code cannot be empty")
    return value if value.endswith("00") else f"{value}00"


@dataclass(frozen=True, slots=True)
class HouseAssignment:
    """One ``<committee>`` or ``<subcommittee>`` under a member's assignments."""

    code: str
    kind: str  # "committee" | "subcommittee"
    rank: str | None
    leadership: str | None

    @property
    def system_code(self) -> str:
        """Legacy spelling without type context; use ``HouseMemberData.system_code`` for rows."""
        return house_system_code(self.code)


@dataclass(frozen=True, slots=True)
class HouseMember:
    """One ``<member>`` seat. A vacancy has ``bioguide_id`` ``None`` and every name field empty."""

    state_district: str
    bioguide_id: str | None
    state_code: str | None
    state_name: str | None
    fields: Mapping[str, str | None]
    elected_date: str | None
    sworn_date: str | None
    assignments: tuple[HouseAssignment, ...]
    placeholder_assignments: int

    @property
    def vacant(self) -> bool:
        return self.bioguide_id is None


@dataclass(frozen=True, slots=True)
class HouseSubcommittee:
    code: str
    name: str
    majority: str | None
    minority: str | None
    attributes: Mapping[str, str]


@dataclass(frozen=True, slots=True)
class HouseCommittee:
    """One entry of the file's own ``<committees>`` block: the names the assignment codes resolve to."""

    code: str
    name: str
    type: str | None
    majority: str | None
    minority: str | None
    subcommittees: tuple[HouseSubcommittee, ...]
    attributes: Mapping[str, str]


@dataclass(frozen=True, slots=True)
class HouseMemberData:
    congress: int
    session: int | None
    congress_text: str | None
    publish_date: str | None
    majority: str | None
    minority: str | None
    clerk: str | None
    members: tuple[HouseMember, ...]
    committees: tuple[HouseCommittee, ...]
    committee_names: Mapping[str, str]
    parent_codes: Mapping[str, str]
    identity_basis: tuple[str, ...]

    @property
    def vacancies(self) -> int:
        return sum(1 for member in self.members if member.vacant)

    def system_code(self, code: str) -> str:
        """Use the roster's native context and the verified joint code pairs."""
        parent = self.parent_codes.get(code, code)
        committee = next((item for item in self.committees if item.code == parent), None)
        if self.congress == 119 and parent == code and committee is not None and committee.type == "joint":
            crosswalk = _HOUSE_JOINT_119.get(code)
            if crosswalk is not None and committee.name == crosswalk[0]:
                return crosswalk[1]
        return house_system_code(code, committee_type=None if committee is None else committee.type)

    def parent_system_code(self, code: str) -> str | None:
        """Derive the native subcommittee parent's code with the same roster context."""
        parent = self.parent_codes.get(code)
        return None if parent is None else self.system_code(parent)


@dataclass(frozen=True, slots=True)
class SenateCommitteeAssignment:
    code: str
    name: str
    position: str | None

    @property
    def system_code(self) -> str:
        return senate_system_code(self.code)


@dataclass(frozen=True, slots=True)
class Senator:
    lis_id: str
    bioguide_id: str
    prefix: str | None
    first: str | None
    last: str | None
    suffix: str | None
    party: str | None
    state: str | None
    home_town: str | None
    state_rank: str | None
    office: str | None
    leadership_position: str | None
    committees: tuple[SenateCommitteeAssignment, ...]


@dataclass(frozen=True, slots=True)
class SenateCvc:
    """The Senate file. It states an update date and no Congress; ``congress`` is therefore not a field."""

    last_update_date: str | None
    last_update_time: str | None
    senators: tuple[Senator, ...]
    identity_basis: tuple[str, ...] = ("root:native", "update-date:native")


def _text(element: Element, tag: str, label: str) -> str | None:
    return child_text(element, tag, error_type=CommitteeRosterError, label=label)


def _required(element: Element, tag: str, label: str) -> str:
    value = _text(element, tag, label)
    if value is None:
        raise CommitteeRosterError(f"{label} is missing <{tag}>")
    return value


def _int(value: str, label: str, field: str) -> int:
    try:
        return int(value)
    except ValueError:
        raise CommitteeRosterError(f"{label} {field} is not an integer: {value!r}") from None


def _read_house_assignments(element: Element | None, label: str) -> tuple[tuple[HouseAssignment, ...], int]:
    assignments: list[HouseAssignment] = []
    placeholders = 0
    for child in element if element is not None else ():
        if child.tag == "committee":
            code = child.get("comcode")
        elif child.tag == "subcommittee":
            code = child.get("subcomcode")
        else:
            raise CommitteeRosterError(f"{label} committee-assignments carries an unknown <{child.tag}>")
        if not code:
            # ``<committee rank=""/>``: the file's spelling of "no assignment",
            # on seven seated members -- nine placeholders in all, counting the
            # two vacancies (measured 2026-09-19).
            placeholders += 1
            continue
        assignments.append(HouseAssignment(code, child.tag, child.get("rank") or None, child.get("leadership") or None))
    return tuple(assignments), placeholders


def _read_house_member(element: Element, index: int) -> HouseMember:
    label = f"MemberData member {index}"
    state_district = _required(element, "statedistrict", label)
    info = single_child(element, "member-info", error_type=CommitteeRosterError, label=label)
    if info is None:
        raise CommitteeRosterError(f"{label} is missing <member-info>")
    bioguide = _text(info, "bioguideID", label)
    fields = {name: _text(info, name, label) for name in _HOUSE_INFO_FIELDS}
    state = single_child(info, "state", error_type=CommitteeRosterError, label=label)
    elected = single_child(info, "elected-date", error_type=CommitteeRosterError, label=label)
    sworn = single_child(info, "sworn-date", error_type=CommitteeRosterError, label=label)
    assignments, placeholders = _read_house_assignments(
        single_child(element, "committee-assignments", error_type=CommitteeRosterError, label=label), label
    )
    if bioguide is None and assignments:
        raise CommitteeRosterError(f"{label} is a vacancy that still lists committee assignments")
    return HouseMember(
        state_district=state_district,
        bioguide_id=bioguide,
        state_code=state.get("postal-code") if state is not None else None,
        state_name=_text(state, "state-fullname", label) if state is not None else None,
        fields=MappingProxyType(fields),
        elected_date=elected.get("date") if elected is not None else None,
        sworn_date=sworn.get("date") if sworn is not None else None,
        assignments=assignments,
        placeholder_assignments=placeholders,
    )


def _ratio(element: Element, label: str) -> tuple[str | None, str | None]:
    ratio = single_child(element, "ratio", error_type=CommitteeRosterError, label=label)
    if ratio is None:
        return None, None
    return _text(ratio, "majority", label), _text(ratio, "minority", label)


def _read_house_committee(element: Element, index: int) -> HouseCommittee:
    label = f"MemberData committees entry {index}"
    code = element.get("comcode")
    if not code:
        raise CommitteeRosterError(f"{label} is missing comcode")
    majority, minority = _ratio(element, label)
    subcommittees: list[HouseSubcommittee] = []
    for child in element.findall("subcommittee"):
        subcode = child.get("subcomcode")
        if not subcode:
            raise CommitteeRosterError(f"{label} has a subcommittee without subcomcode")
        sub_majority, sub_minority = _ratio(child, label)
        subcommittees.append(
            HouseSubcommittee(
                subcode,
                _required(child, "subcommittee-fullname", label),
                sub_majority,
                sub_minority,
                MappingProxyType(dict(child.attrib)),
            )
        )
    return HouseCommittee(
        code=code,
        name=_required(element, "committee-fullname", label),
        type=element.get("type"),
        majority=majority,
        minority=minority,
        subcommittees=tuple(subcommittees),
        attributes=MappingProxyType(dict(element.attrib)),
    )


def parse_house_member_data(body: bytes, *, congress: int, session: int | None = None) -> HouseMemberData:
    """Read the Clerk's ``MemberData.xml`` whole, proving its stated Congress (and session) first.

    A file with zero ``<member>`` elements refuses: the House has 435 voting
    seats and the file lists every seat, filled or vacant, so an empty
    roster is a bad file rather than a fact about the House.
    """
    label = "MemberData"
    root = parse_xml(body, max_bytes=len(body), error_type=CommitteeRosterError, label=label)
    if root.tag != "MemberData":
        raise CommitteeRosterError(f"{label} root must be <MemberData>, got <{root.tag}>")
    title = single_child(root, "title-info", error_type=CommitteeRosterError, label=label)
    if title is None:
        raise CommitteeRosterError(f"{label} is missing <title-info>")
    stated_congress = _int(_required(title, "congress-num", label), label, "congress-num")
    stated_session_text = _text(title, "session", label)
    stated_session = _int(stated_session_text, label, "session") if stated_session_text is not None else None
    if stated_congress != congress or (session is not None and stated_session != session):
        raise CommitteeRosterIdentityError(requested=(congress, session), stated=(stated_congress, stated_session))
    members_element = single_child(root, "members", error_type=CommitteeRosterError, label=label)
    if members_element is None:
        raise CommitteeRosterError(f"{label} is missing <members>")
    members = tuple(_read_house_member(el, i) for i, el in enumerate(members_element.findall("member")))
    if not members:
        raise CommitteeRosterError(f"{label} lists no members")
    committees_element = single_child(root, "committees", error_type=CommitteeRosterError, label=label)
    committees = tuple(
        _read_house_committee(el, i)
        for i, el in enumerate(committees_element.findall("committee") if committees_element is not None else ())
    )
    names: dict[str, str] = {}
    parents: dict[str, str] = {}
    for committee in committees:
        names[committee.code] = committee.name
        for sub in committee.subcommittees:
            names[sub.code] = sub.name
            parents[sub.code] = committee.code
    basis = ("congress:native",) + (("session:native",) if session is not None else ())
    return HouseMemberData(
        congress=stated_congress,
        session=stated_session,
        congress_text=_text(title, "congress-text", label),
        publish_date=root.get("publish-date"),
        majority=_text(title, "majority", label),
        minority=_text(title, "minority", label),
        clerk=_text(title, "clerk", label),
        members=members,
        committees=committees,
        committee_names=MappingProxyType(names),
        parent_codes=MappingProxyType(parents),
        identity_basis=basis,
    )


def _read_senator(element: Element, index: int) -> Senator:
    label = f"cvc senator {index}"
    lis = element.get("lis_member_id")
    if not lis:
        raise CommitteeRosterError(f"{label} is missing lis_member_id")
    bioguide = _text(element, "bioguideId", label)
    if bioguide is None:
        raise CommitteeRosterError(f"{label} is missing <bioguideId>")
    name = single_child(element, "name", error_type=CommitteeRosterError, label=label)
    committees_element = single_child(element, "committees", error_type=CommitteeRosterError, label=label)
    committees: list[SenateCommitteeAssignment] = []
    for child in committees_element if committees_element is not None else ():
        if child.tag != "committee":
            raise CommitteeRosterError(f"{label} committees carries an unknown <{child.tag}>")
        code = child.get("code")
        committee_name = (child.text or "").strip()
        if not code or not committee_name:
            raise CommitteeRosterError(f"{label} has a committee without a code or a name")
        committees.append(SenateCommitteeAssignment(code, committee_name, child.get("position") or None))
    return Senator(
        lis_id=lis,
        bioguide_id=bioguide,
        prefix=_text(name, "prefix", label) if name is not None else None,
        first=_text(name, "first", label) if name is not None else None,
        last=_text(name, "last", label) if name is not None else None,
        suffix=_text(name, "suffix", label) if name is not None else None,
        party=_text(element, "party", label),
        state=_text(element, "state", label),
        home_town=_text(element, "homeTown", label),
        state_rank=_text(element, "stateRank", label),
        office=_text(element, "office", label),
        leadership_position=_text(element, "leadership_position", label),
        committees=tuple(committees),
    )


def parse_senate_cvc(body: bytes) -> SenateCvc:
    """Read ``cvc_member_data.xml`` whole. It states an update date, never a Congress.

    Zero senators refuses; a repeated LIS id or bioguide refuses too, because
    the file promises one seat per senator and a duplicate would give one
    person two assignment rows under one key.
    """
    label = "cvc_member_data"
    root = parse_xml(body, max_bytes=len(body), error_type=CommitteeRosterError, label=label)
    if root.tag != "senators":
        raise CommitteeRosterError(f"{label} root must be <senators>, got <{root.tag}>")
    update = single_child(root, "lastUpdate", error_type=CommitteeRosterError, label=label)
    senators = tuple(_read_senator(el, i) for i, el in enumerate(root.findall("senator")))
    if not senators:
        raise CommitteeRosterError(f"{label} lists no senators")
    seen_lis: set[str] = set()
    seen_bioguide: set[str] = set()
    for senator in senators:
        if senator.lis_id in seen_lis or senator.bioguide_id in seen_bioguide:
            raise CommitteeRosterError(f"{label} repeats senator {senator.lis_id} / {senator.bioguide_id}")
        seen_lis.add(senator.lis_id)
        seen_bioguide.add(senator.bioguide_id)
    return SenateCvc(
        last_update_date=_text(update, "date", label) if update is not None else None,
        last_update_time=_text(update, "time", label) if update is not None else None,
        senators=senators,
    )


@dataclass(frozen=True, slots=True)
class CommitteeRosterBudget:
    max_requests: int
    max_bytes: int
    timeout_seconds: float
    min_request_interval_seconds: float

    def __post_init__(self) -> None:
        check_request_count(self.max_requests)
        check_byte_bound(self.max_bytes, "max_bytes", MAX_ROSTER_BYTES)
        check_timing(self.timeout_seconds, self.min_request_interval_seconds)


@dataclass(frozen=True, slots=True)
class HouseRosterAcquisition:
    roster: HouseMemberData
    capture: CapturedBodyResponse
    request_count: int
    budget: CommitteeRosterBudget


@dataclass(frozen=True, slots=True)
class SenateRosterAcquisition:
    roster: SenateCvc
    capture: CapturedBodyResponse
    request_count: int
    budget: CommitteeRosterBudget


class CommitteeRosterAcquirer(SourceAcquirer):
    """Keyless capture of either chamber's current roster file, one request each.

    Both hosts are keyless (data map Table C); ``named_challenge`` recasts a
    401/403 as ``CommitteeRosterRefusedError`` the way the votes and
    legislators acquirers do for this package's other keyless families.
    """

    def __init__(
        self,
        *,
        budget: CommitteeRosterBudget,
        transport: httpx.BaseTransport | None = None,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        if not isinstance(budget, CommitteeRosterBudget):
            raise TypeError("budget must be a CommitteeRosterBudget")
        self._budget = budget
        super().__init__(
            max_requests=budget.max_requests,
            timeout_seconds=budget.timeout_seconds,
            min_request_interval_seconds=budget.min_request_interval_seconds,
            user_agent="spicy-docs-committee-rosters/1.0",
            label="House Clerk / Senate committee roster",
            error_type=CommitteeRosterError,
            context_key="committee_roster_acquisition",
            transport=transport,
            clock=clock,
            keyless=True,
        )

    @property
    def budget(self) -> CommitteeRosterBudget:
        return self._budget

    def acquire_house(
        self, *, congress: int, session: int | None = None, max_bytes: int | None = None
    ) -> HouseRosterAcquisition:
        """Capture ``MemberData.xml`` and prove its stated Congress (and session) is the one requested."""
        url = HOUSE_MEMBER_DATA_URL
        with named_challenge(url, error_type=CommitteeRosterRefusedError, context_key=self.context_key):
            roster, capture = self.capture_validated(
                url,
                media_types=MEDIA_TYPES,
                parse=lambda response, _limit: parse_house_member_data(
                    response.body, congress=congress, session=session
                ),
                max_bytes=narrow_byte_limit(self.budget.max_bytes, max_bytes),
                unavailable=CommitteeRosterUnavailableError,
                context={"operation": "house-member-data", "congress": congress, "session": session, "url": url},
            )
        return HouseRosterAcquisition(roster, capture, self.request_count, self.budget)

    def acquire_senate(self, *, max_bytes: int | None = None) -> SenateRosterAcquisition:
        """Capture ``cvc_member_data.xml``. The file states no Congress, so none can be proved here."""
        url = SENATE_CVC_URL
        with named_challenge(url, error_type=CommitteeRosterRefusedError, context_key=self.context_key):
            roster, capture = self.capture_validated(
                url,
                media_types=MEDIA_TYPES,
                parse=lambda response, _limit: parse_senate_cvc(response.body),
                max_bytes=narrow_byte_limit(self.budget.max_bytes, max_bytes),
                unavailable=CommitteeRosterUnavailableError,
                context={"operation": "senate-cvc", "url": url},
            )
        return SenateRosterAcquisition(roster, capture, self.request_count, self.budget)


__all__ = [
    "DEFAULT_MAX_HOUSE_BYTES",
    "DEFAULT_MAX_SENATE_BYTES",
    "HOUSE_MEMBER_DATA_URL",
    "MAX_ROSTER_BYTES",
    "MEDIA_TYPES",
    "SENATE_CVC_URL",
    "CommitteeRosterAcquirer",
    "CommitteeRosterBudget",
    "CommitteeRosterError",
    "CommitteeRosterIdentityError",
    "CommitteeRosterRefusedError",
    "CommitteeRosterUnavailableError",
    "HouseAssignment",
    "HouseCommittee",
    "HouseMember",
    "HouseMemberData",
    "HouseRosterAcquisition",
    "HouseSubcommittee",
    "SenateCommitteeAssignment",
    "SenateCvc",
    "SenateRosterAcquisition",
    "Senator",
    "house_committee_prefix",
    "house_system_code",
    "parse_house_member_data",
    "parse_senate_cvc",
    "senate_system_code",
]
