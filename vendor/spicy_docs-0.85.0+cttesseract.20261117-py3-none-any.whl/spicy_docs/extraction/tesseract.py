"""Tesseract backport from SpicyDocs c5d5f2b; other OCR providers stay unchanged."""
from __future__ import annotations

import ctypes
import ctypes.util
import functools
import hashlib
import io
import os
import platform
import threading
import weakref
from pathlib import Path
from typing import Any

from .model import RAW_RGB, ExtractionError, Raster, Recognition, TextBlock
from .ocr import _box


def _rgb_samples(image: Raster) -> bytes:
    """The raster's unencoded RGB samples, decoding an encoded image once.

    An encoded image must have the pixel size the raster claims: its readers (a band's strip, libtesseract) take the
    claimed size, so a larger claim reads past the samples and a smaller one misreads them, both without an error.
    ``Raster`` checks ``RAW_RGB`` samples' length itself.
    """
    if image.media_type == RAW_RGB:
        return image.data
    from PIL import Image

    with Image.open(io.BytesIO(image.data)) as source:
        if source.size != (image.width, image.height):
            raise ValueError(
                f"raster claims {image.width}x{image.height} pixels, its image is {'x'.join(map(str, source.size))}"
            )
        return source.convert("RGB").tobytes()



#: Pinned models, ``(language, variant)`` to the SHA-256 and size of upstream's ``<language>.traineddata``. ``fast`` is
#: tessdata_fast 4.1.0, which Homebrew's tesseract formula installs and pins by this digest. ``best`` is tessdata_best's
#: file as copies on the measuring Mac hash it (congressional-tech ``pdf-text-configs-20261108`` measured the same
#: file); no package pins it, so check it against github.com/tesseract-ocr/tessdata_best when a download is allowed.
_TESSDATA = {
    ("eng", "best"): ("8280aed0782fe27257a68ea10fe7ef324ca0f8d85bd2fd145d1c2b560bcb66ba", 15_400_601),
    ("eng", "fast"): ("7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2", 4_113_088),
}
#: Page segmentation modes that return text from one loaded model: 0, 1 and 12 also need ``osd``; 2 only segments.
_TESSERACT_PSM = frozenset({3, 4, 5, 6, 7, 8, 9, 10, 11, 13})
_TEXTLINE, _LSTM_ONLY = 2, 1  # RIL_TEXTLINE; OEM_LSTM_ONLY, as both variants hold only LSTM networks
_P, _I = ctypes.c_void_p, ctypes.c_int
#: The C API calls used, as ``capi.h`` declares them: (argument types, return type).
_TESS_API = {
    "TessVersion": ([], ctypes.c_char_p),
    "TessBaseAPICreate": ([], _P),
    "TessBaseAPIDelete": ([_P], None),
    "TessBaseAPISetVariable": ([_P, ctypes.c_char_p, ctypes.c_char_p], _I),
    "TessBaseAPIInit5": ([_P, ctypes.c_char_p, _I, ctypes.c_char_p, _I, _P, _I, _P, _P, ctypes.c_size_t, _I], _I),
    "TessBaseAPISetPageSegMode": ([_P, _I], None),
    "TessBaseAPISetImage": ([_P, ctypes.c_char_p, _I, _I, _I, _I], None),
    "TessBaseAPIRecognize": ([_P, _P], _I),
    "TessBaseAPIClear": ([_P], None),
    "TessBaseAPIGetIterator": ([_P], _P),
    "TessResultIteratorGetPageIterator": ([_P], _P),
    "TessPageIteratorBoundingBox": ([_P, _I, *[ctypes.POINTER(_I)] * 4], _I),
    "TessResultIteratorGetUTF8Text": ([_P, _I], _P),
    "TessResultIteratorConfidence": ([_P, _I], ctypes.c_float),
    "TessResultIteratorNext": ([_P, _I], _I),
    "TessResultIteratorDelete": ([_P], None),
    "TessDeleteText": ([_P], None),
}


_TESS_LOCK = threading.Lock()


@functools.cache
def _load_libtesseract() -> tuple[ctypes.CDLL, dict[str, str | None]] | dict[str, str]:
    """The first candidate with every call in ``_TESS_API`` and its versions, else why each candidate failed.

    Candidates: the loader's search, Debian's soname, then Homebrew's ``/opt/homebrew``, which macOS's
    ``find_library`` skips. ``TessBaseAPIInit5`` (a model from memory) arrived in Tesseract 5, so a 4.x library is
    passed over. Cached, a failure included, and called under ``_TESS_LOCK``.
    """
    reasons = {}
    for name in dict.fromkeys(
        filter(
            None, (ctypes.util.find_library("tesseract"), "libtesseract.so.5", "/opt/homebrew/lib/libtesseract.dylib")
        )
    ):
        try:
            lib = ctypes.CDLL(name)
            for symbol, (arguments, result) in _TESS_API.items():
                function = getattr(lib, symbol)
                function.argtypes, function.restype = arguments, result
        except (OSError, AttributeError) as error:
            reasons[name] = str(error)
            continue
        # debug_file is one variable for the whole process: set once, tprintf notes (a resolution estimate, an empty
        # page) go nowhere instead of to stderr once a page.
        handle = lib.TessBaseAPICreate()
        lib.TessBaseAPISetVariable(handle, b"debug_file", os.devnull.encode())
        lib.TessBaseAPIDelete(handle)
        return lib, {"version": lib.TessVersion().decode(), "leptonica": _leptonica_version(lib)}
    return reasons


def _leptonica_version(lib) -> str | None:
    """Leptonica's own version call, reached through libtesseract's dependencies; it does the image processing."""
    try:
        read, free = lib.getLeptonicaVersion, lib.lept_free
    except AttributeError:
        return None
    read.restype, free.argtypes = _P, [_P]
    text = read()
    try:
        return ctypes.string_at(text).decode()
    finally:
        free(text)


def _libtesseract() -> tuple[ctypes.CDLL, dict[str, str | None]]:
    with _TESS_LOCK:
        found = _load_libtesseract()
    if isinstance(found, dict):
        raise ExtractionError(
            "Tesseract requires libtesseract 5 (Homebrew tesseract; Debian and Ubuntu libtesseract5)",
            details={"tried": found},
        )
    return found


def _tessdata(language: str, variant: str, directory: str | os.PathLike | None) -> tuple[bytes, dict[str, Any]]:
    """The pinned model's bytes, read once, and their identity; refuses a missing file or any other model."""
    directory = directory if directory is not None else os.environ.get("TESSDATA_PREFIX")
    name, origin = f"{language}.traineddata", f"github.com/tesseract-ocr/tessdata_{variant}"
    if not directory:
        raise ExtractionError(f"Tesseract {variant} needs {origin}'s {name}: pass tessdata_dir or set TESSDATA_PREFIX")
    path = Path(directory) / name
    try:
        data = path.read_bytes()
    except OSError as error:
        raise ExtractionError(
            f"Tesseract {variant} model {path} is unreadable ({error.strerror}); get {name} from {origin}",
            details={"path": str(path)},
        ) from None
    found = hashlib.sha256(data).hexdigest(), len(data)
    if found != _TESSDATA[language, variant]:
        other = [v for (lang, v), pin in _TESSDATA.items() if lang == language and pin == found]
        raise ExtractionError(
            f"{path} is not {origin}'s {name}" + (f" but tessdata_{other[0]}'s" if other else ""),
            details={
                "path": str(path),
                "sha256": found[0],
                "bytes": found[1],
                "expected": _TESSDATA[language, variant],
            },
        )
    return data, {"sha256": found[0], "bytes": found[1], "source": origin}


class _Tesseract:
    """One ``TessBaseAPI`` through libtesseract's C API, initialized once from the model's bytes, reused per raster.

    The bytes handed to ``TessBaseAPIInit5`` are the ones hashed, so the identity names exactly what was loaded.
    libtesseract allows one instance per thread, never one shared; ctypes releases the GIL during each call.
    """

    def __init__(self, lib, data: bytes, language: str, psm: int):
        self.lib, self.handle = lib, (handle := lib.TessBaseAPICreate())
        self.close = weakref.finalize(self, lib.TessBaseAPIDelete, handle)
        if lib.TessBaseAPIInit5(handle, data, len(data), language.encode(), _LSTM_ONLY, None, 0, None, None, 0, 0):
            self.close()
            raise ExtractionError("libtesseract refused the model", details={"language": language})
        lib.TessBaseAPISetPageSegMode(handle, psm)

    def __call__(self, image: Raster) -> list[tuple[str, float, list[int]]]:
        """Each text line as libtesseract gives it: text with its line ending, confidence 0-100, pixel box."""
        lib, handle, detections = self.lib, self.handle, []
        lib.TessBaseAPISetImage(handle, _rgb_samples(image), image.width, image.height, 3, image.width * 3)
        try:
            if lib.TessBaseAPIRecognize(handle, None):
                raise ExtractionError(
                    "Tesseract recognition failed", details={"width": image.width, "height": image.height}
                )
            if not (lines := lib.TessBaseAPIGetIterator(handle)):  # A page without text has no iterator.
                return detections
            try:
                page, edges = lib.TessResultIteratorGetPageIterator(lines), [ctypes.c_int() for _ in range(4)]
                while True:
                    if lib.TessPageIteratorBoundingBox(page, _TEXTLINE, *map(ctypes.byref, edges)):
                        text = lib.TessResultIteratorGetUTF8Text(lines, _TEXTLINE)
                        try:
                            decoded = ctypes.string_at(text).decode() if text else ""
                        finally:
                            lib.TessDeleteText(text)
                        confidence = lib.TessResultIteratorConfidence(lines, _TEXTLINE)
                        detections.append((decoded, confidence, [edge.value for edge in edges]))
                    if not lib.TessResultIteratorNext(lines, _TEXTLINE):
                        return detections
            finally:
                lib.TessResultIteratorDelete(lines)
        finally:
            lib.TessBaseAPIClear(handle)


class Tesseract:
    """Tesseract LSTM recognition in process through libtesseract's C API, one engine per instance reused per page.

    ``model`` names a pinned upstream model: ``fast`` (tessdata_fast, the default) or ``best`` (tessdata_best). It is
    ``<tessdata_dir>/<language>.traineddata``, with ``tessdata_dir`` defaulting to ``$TESSDATA_PREFIX`` (the directory
    holding the file, as Tesseract 4 and later read it); no other directory is searched, as installed models share the
    file name. The file is read once and must match the pin's SHA-256 and size, or the backend refuses with the path
    and the upstream repository; one variant never stands in for the other. The engine runs LSTM only, on the
    raster's RGB samples (an encoded raster is decoded once). ``fast`` is the default because ``best`` took 2.2 times
    as long on the pages below for no measured gain.

    Detections are text lines in image pixels, top-left origin, with libtesseract's 0-100 confidence; blocks carry
    normalized boxes and confidence divided by 100, as the other backends do. An injected ``engine`` is called with
    each raster and returns those detections. The identity adds the libtesseract and Leptonica versions, the host
    architecture and the model file's digest. It is a host's identity, not a portable one: libtesseract picks a SIMD
    dot-product kernel per CPU and does not say which (its ``dotproduct`` variable reads ``auto`` after init), and
    ``best`` is a float model, so compare a sample before treating two hosts' readings as one version.

    One instance per serial worker or thread; ``close()`` releases the engine, which a later page rebuilds. A
    libtesseract built with OpenMP, as Debian's usually is, adds threads inside each instance: set
    ``OMP_THREAD_LIMIT=1`` when running an instance per thread or process. Only macOS (Homebrew 5.5.4, no OpenMP)
    has been measured.

    There are no bands: whole-page Tesseract read 94% and 96% of the native characters on the two dense GPO pages
    where whole-page Vision read 32%. The resolution is libtesseract's estimate from the text; stating 200 dpi changed
    a few words on 2 of 10 pages, neither way closer to the native layer. Measured with ``fast`` on 30 archive pages
    (congressional-tech ``.cache/archive-release/investigations/tesseract-backend-20261111``). On forms, PSM 3 lost
    decimals and checkboxes in an earlier qualification (``docs/extraction/pdf-extraction-choices.md``).
    """

    def __init__(self, *, language="eng", model="fast", tessdata_dir=None, page_segmentation_mode=3, engine=None):
        if (language, model) not in _TESSDATA:
            raise ValueError(f"no pinned Tesseract model {model!r} for {language!r}; pinned: {sorted(_TESSDATA)}")
        if type(page_segmentation_mode) is not int or page_segmentation_mode not in _TESSERACT_PSM:
            raise ValueError(f"page_segmentation_mode must be one of {sorted(_TESSERACT_PSM)}")
        self.language, self.model, self.tessdata_dir, self.psm = language, model, tessdata_dir, page_segmentation_mode
        self.engine, self._injected, self._model_file, self._versions = engine, engine is not None, None, {}

    def configuration(self) -> dict[str, Any]:
        """Effective settings; library versions and the model file's identity once the engine is built."""
        return {
            "backend": "tesseract",
            "version": self._versions.get("version"),
            "leptonica": self._versions.get("leptonica"),
            "machine": platform.machine(),
            "language": self.language,
            "model": self.model,
            "model_file": self._model_file,
            "page_segmentation_mode": self.psm,
            "engine_mode": "lstm-only",
            "engine_injected": self._injected,
        }

    def require_reproducible_identity(self) -> dict[str, Any]:
        """The configuration a host keys a re-read on; refuses an injected engine, whose model is unknown."""
        if self._injected:
            raise ValueError("an injected Tesseract engine has no reproducible identity")
        self._engine()
        return self.configuration()

    def _engine(self):
        if self.engine is None:
            lib, versions = _libtesseract()  # A host without it is told so before any model is read.
            data, model_file = _tessdata(self.language, self.model, self.tessdata_dir)
            self.engine = _Tesseract(lib, data, self.language, self.psm)
            self._versions, self._model_file = versions, model_file
        return self.engine

    def recognize(self, image: Raster) -> Recognition:
        detections, width, height = self._engine()(image), image.width, image.height
        blocks = tuple(
            TextBlock(text.rstrip("\n"), _box(left / width, top / height, right / width, bottom / height), conf / 100)
            for text, conf, (left, top, right, bottom) in detections
            if text.strip()
        )
        raw = {"detections": detections, "coordinates": "image pixels; top-left origin; left, top, right, bottom"}
        return Recognition("\n".join(b.text for b in blocks), self.configuration(), raw, blocks)

    def close(self):
        if not self._injected and self.engine is not None:
            self.engine.close()
            self.engine, self._model_file, self._versions = None, None, {}

