from pathlib import Path
import json, os, platform, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
ENV=dict(os.environ, PATH=str(ROOT/'.venv/bin')+os.pathsep+os.environ['PATH'])
records=[]
def run(name, command, cwd=ROOT, timeout=1200):
    started=time.time()
    with (OUT/(name+'.log')).open('w') as log:
        log.write(json.dumps({'command':command,'cwd':str(cwd),'started':started})+'\n'); log.flush()
        try:
            result=subprocess.run(command,cwd=cwd,env=ENV,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
            code=result.returncode
        except subprocess.TimeoutExpired:
            code='timeout'
    value={'name':name,'command':command,'cwd':str(cwd),'seconds':time.time()-started,'exit_code':code}
    records.append(value); (OUT/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(value),flush=True)
    return code==0
if __name__=='__main__':
    if not run('production-offline',[str(ROOT/'.venv/bin/python'),'scripts/dev.py','test','production-offline']): sys.exit(1)
    if not run('active-experiment',[str(ROOT/'.venv/bin/python'),'scripts/dev.py','test','active-experiment-regression']): sys.exit(1)
    ENV['SOURCE_FETCH_BINARY']=str(ROOT/'packages/source-fetch/target/release/source-fetch')
    if not run('native-loopback',[str(ROOT/'.venv/bin/python'),'scripts/dev.py','test','native-loopback']): sys.exit(1)
    ENV.pop('SOURCE_FETCH_BINARY',None)
    if not run('npm-install',['npm','install','--workspace','apps/site','--workspace','viewer-data','--include-workspace-root','--no-audit','--no-fund']): sys.exit(1)
    run('npm-runtime',['npm','ls','--workspace','apps/site','--workspace','viewer-data','--depth=0'])
    if not run('explorer-tests',['npm','run','test:explorer','--workspace','apps/site']): sys.exit(1)
    if not run('explorer-types',['npm','run','check:explorer-types','--workspace','apps/site']): sys.exit(1)
    if not run('astro-check',['npx','--no-install','astro','check'],cwd=ROOT/'apps/site'): sys.exit(1)
    if not run('viewer-data',['npm','test','--workspace','viewer-data']): sys.exit(1)
    sys.path.insert(0,str(ROOT/'apps/site/scripts'))
    from filename_reviews import verify_directory
    descriptor=json.loads((ROOT/'apps/site/document-review-publication.json').read_text())
    source=Path('/Users/mikewolfd/Work/congressional-tech/output/filename-patterns-20261015/review-rebind-v2/public')
    verify_directory(source,descriptor['sha256'])
    target=ROOT/'apps/site/public/data/document-reviews'
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists(): target.symlink_to(source, target_is_directory=True)
    if target.resolve()!=source.resolve(): raise ValueError('Unexpected staged review directory')
    if not run('site-build',['npm','run','build','--workspace','apps/site']): sys.exit(1)
